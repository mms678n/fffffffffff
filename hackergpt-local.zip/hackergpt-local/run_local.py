#!/usr/bin/env python3
"""One-command local launcher for the HackerGPT bundle.

Edit local_config.json, then run: python run_local.py
The launcher bootstraps Python dependencies, starts FastAPI, serves the built React
frontend, and keeps the Agent URL aligned with the same public address.
"""
from __future__ import annotations
import json, os, secrets, subprocess, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CONFIG_PATH = ROOT / "local_config.json"
EXAMPLE_PATH = ROOT / "local_config.json.example"


def load_config():
    if not CONFIG_PATH.exists():
        CONFIG_PATH.write_text(EXAMPLE_PATH.read_text(), encoding="utf-8")
        print(f"Created {CONFIG_PATH.name}; edit it once, then run this file again.")
        raise SystemExit(0)
    data = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    data.setdefault("host", "0.0.0.0")
    data.setdefault("port", 5000)
    data.setdefault("admin_username", "local-admin")
    data.setdefault("admin_password", "change-this-local-password")
    data.setdefault("jwt_secret", secrets.token_urlsafe(48))
    data.setdefault("encryption_key", secrets.token_urlsafe(32))
    CONFIG_PATH.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return data


def bootstrap():
    required = ("fastapi", "uvicorn", "sqlalchemy", "aiosqlite")
    missing = []
    for name in required:
        try:
            __import__(name)
        except ImportError:
            missing.append(name)
    if missing:
        print("Installing Python dependencies:", ", ".join(missing))
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", str(ROOT / "backend" / "requirements.txt")])


def main():
    cfg = load_config()
    bootstrap()
    from cryptography.fernet import Fernet
    try:
        Fernet(str(cfg.get("encryption_key", "")).encode())
    except Exception:
        cfg["encryption_key"] = Fernet.generate_key().decode()
        CONFIG_PATH.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    env = os.environ.copy()
    env.update({
        "LOCAL_MODE": "1",
        "PYTHONPATH": str(ROOT / "backend"),
        "DATABASE_URL": f"sqlite+aiosqlite:///{ROOT / 'local_data.db'}",
        "PORT": str(cfg["port"]),
        "CORS_ORIGINS": cfg.get("cors_origins", "*"),
        "JWT_SECRET": cfg.get("jwt_secret") or secrets.token_urlsafe(48),
        "ENCRYPTION_KEY": cfg.get("encryption_key") or secrets.token_urlsafe(32),
        "ADMIN_USERNAME": cfg.get("admin_username", "local-admin"),
        "ADMIN_PASSWORD": cfg.get("admin_password", "change-this-local-password"),
        "OPENROUTER_API_KEY": cfg.get("openrouter_api_key", ""),
        "OPENROUTER_MODEL": cfg.get("openrouter_model", "openai/gpt-4o-mini"),
        "OPENROUTER_BASE_URL": "https://openrouter.ai/api/v1",
        "OPENROUTER_HTTP_REFERER": cfg.get("public_url", "http://localhost:5000"),
        "OPENROUTER_TITLE": "HackerGPT Local",
        "AGENT_DOWNLOAD_WINDOWS": cfg.get("agent_download_windows", ""),
        "AGENT_DOWNLOAD_LINUX": cfg.get("agent_download_linux", ""),
        "AGENT_DOWNLOAD_MACOS": cfg.get("agent_download_macos", ""),
        "HACKERGPT_SERVER": cfg.get("agent_server_url") or cfg.get("public_url", "http://localhost:5000"),
    })
    print(f"HackerGPT Local is starting on http://{cfg['host']}:{cfg['port']}")
    print(f"Agent server URL: {env['HACKERGPT_SERVER']}")
    subprocess.run([sys.executable, "-m", "uvicorn", "backend.server:app", "--host", str(cfg["host"]), "--port", str(cfg["port"])], cwd=ROOT, env=env, check=False)


if __name__ == "__main__":
    main()
