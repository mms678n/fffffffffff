"""HackerGPT Agent device endpoints tests."""
import os
import uuid
import secrets
import pytest
import requests

BASE = os.environ["REACT_APP_BACKEND_URL"].rstrip("/")
API = f"{BASE}/api"

ADMIN = {"username": "admin", "password": "admin123"}


def _hex(n):
    return secrets.token_hex(n).upper()


def _device_id():
    return f"HG-{_hex(4)}-{_hex(2)}"


def _secret():
    return secrets.token_hex(40)  # 80 chars


@pytest.fixture(scope="module")
def s():
    return requests.Session()


@pytest.fixture(scope="module")
def admin_h(s):
    r = s.post(f"{API}/auth/login", json=ADMIN, timeout=15)
    assert r.status_code == 200
    return {"Authorization": f"Bearer {r.json()['token']}"}


@pytest.fixture(scope="module")
def user_b_h(s):
    uname = f"TEST_userB_{uuid.uuid4().hex[:8]}"
    r = s.post(f"{API}/auth/register", json={"username": uname, "password": "pass1234"}, timeout=15)
    assert r.status_code == 200
    return {"Authorization": f"Bearer {r.json()['token']}"}


# ---------------- installer downloads ----------------
class TestAgentDownloads:
    @pytest.mark.parametrize("plat", ["linux", "windows", "macos"])
    def test_platform_download(self, s, plat):
        r = s.get(f"{API}/agent/download/{plat}", timeout=15)
        assert r.status_code == 200, r.text
        assert "attachment" in r.headers.get("Content-Disposition", "").lower()
        assert len(r.content) > 0

    def test_bundle(self, s):
        r = s.get(f"{API}/agent/bundle", timeout=20)
        assert r.status_code == 200, r.text
        assert "attachment" in r.headers.get("Content-Disposition", "").lower()
        # gzip magic bytes
        assert r.content[:2] == b"\x1f\x8b"

    def test_unknown_platform(self, s):
        r = s.get(f"{API}/agent/download/plan9", timeout=10)
        assert r.status_code == 404


# ---------------- device registration & isolation ----------------
class TestDevices:
    def test_register_list_delete_flow(self, s, admin_h):
        did = _device_id()
        sec = _secret()
        # register
        r = s.post(f"{API}/devices/register",
                   json={"device_id": did, "device_secret": sec},
                   headers=admin_h, timeout=15)
        assert r.status_code == 200, r.text
        data = r.json()
        assert data["device_id"] == did
        assert data["status"] == "offline"  # no agent connected
        db_id = data["id"]

        # list
        r2 = s.get(f"{API}/devices", headers=admin_h, timeout=15)
        assert r2.status_code == 200
        assert any(d["device_id"] == did for d in r2.json())

        # duplicate same user -> 409
        r3 = s.post(f"{API}/devices/register",
                    json={"device_id": did, "device_secret": sec},
                    headers=admin_h, timeout=15)
        assert r3.status_code == 409

        # delete
        r4 = s.delete(f"{API}/devices/{db_id}", headers=admin_h, timeout=15)
        assert r4.status_code == 200

        # verify removed
        r5 = s.get(f"{API}/devices", headers=admin_h, timeout=15)
        assert not any(d["device_id"] == did for d in r5.json())

    def test_lowercase_device_id_normalized(self, s, admin_h):
        did = _device_id().lower()
        r = s.post(f"{API}/devices/register",
                   json={"device_id": did, "device_secret": _secret()},
                   headers=admin_h, timeout=15)
        assert r.status_code == 200
        assert r.json()["device_id"] == did.upper()
        # cleanup
        s.delete(f"{API}/devices/{r.json()['id']}", headers=admin_h)

    def test_invalid_device_id_format(self, s, admin_h):
        r = s.post(f"{API}/devices/register",
                   json={"device_id": "abc", "device_secret": _secret()},
                   headers=admin_h, timeout=15)
        assert r.status_code == 400

    def test_short_secret_rejected(self, s, admin_h):
        r = s.post(f"{API}/devices/register",
                   json={"device_id": _device_id(), "device_secret": "short"},
                   headers=admin_h, timeout=15)
        assert r.status_code == 400

    def test_per_user_isolation(self, s, admin_h, user_b_h):
        did = _device_id()
        sec = _secret()
        # admin registers
        r = s.post(f"{API}/devices/register",
                   json={"device_id": did, "device_secret": sec},
                   headers=admin_h, timeout=15)
        assert r.status_code == 200
        admin_db_id = r.json()["id"]

        # userB registers same device_id -> 409 with proper message
        r2 = s.post(f"{API}/devices/register",
                    json={"device_id": did, "device_secret": sec},
                    headers=user_b_h, timeout=15)
        assert r2.status_code == 409
        assert "another account" in r2.json().get("detail", "").lower()

        # userB does NOT see it in listing
        r3 = s.get(f"{API}/devices", headers=user_b_h, timeout=15)
        assert not any(d["device_id"] == did for d in r3.json())

        # userB cannot delete it (returns 404 since not their device)
        r4 = s.delete(f"{API}/devices/{admin_db_id}", headers=user_b_h, timeout=15)
        assert r4.status_code == 404

        # cleanup by admin
        s.delete(f"{API}/devices/{admin_db_id}", headers=admin_h, timeout=15)

    def test_unauth_devices_forbidden(self, s):
        r = s.get(f"{API}/devices", timeout=10)
        assert r.status_code in (401, 403)
