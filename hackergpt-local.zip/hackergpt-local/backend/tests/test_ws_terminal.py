"""WebSocket terminal test."""
import os, json, time, uuid, asyncio
import pytest
import requests
try:
    import websockets
except ImportError:
    websockets = None

BASE = os.environ.get("REACT_APP_BACKEND_URL", "https://ai-server-control.preview.emergentagent.com").rstrip("/")
API = f"{BASE}/api"
WS_BASE = BASE.replace("https://", "wss://").replace("http://", "ws://")


@pytest.mark.skipif(websockets is None, reason="websockets not installed")
def test_ws_terminal_streams_shell():
    s = requests.Session()
    tok = s.post(f"{API}/auth/login", json={"username": "admin", "password": "admin123"}, timeout=15).json()["token"]
    h = {"Authorization": f"Bearer {tok}"}
    servers = s.get(f"{API}/servers", headers=h, timeout=10).json()
    demo = next((x for x in servers if x["host"] == "localhost"), None)
    if not demo:
        r = s.post(f"{API}/servers", json={
            "nickname": "Demo", "host": "localhost", "port": 22,
            "username": "demo", "password": "demo1234", "os": "Linux"
        }, headers=h, timeout=15)
        demo = r.json()
    sid = demo["id"]

    async def run():
        url = f"{WS_BASE}/api/ws/terminal/{sid}?token={tok}"
        async with websockets.connect(url, open_timeout=15) as ws:
            # send a command
            await ws.send(json.dumps({"type": "input", "data": "echo WSHELLO\n"}))
            got = ""
            for _ in range(30):
                try:
                    msg = await asyncio.wait_for(ws.recv(), timeout=3)
                    got += msg
                    if "WSHELLO" in got:
                        return got
                except asyncio.TimeoutError:
                    break
            return got

    result = asyncio.run(run())
    assert "WSHELLO" in result, f"result={result[:500]}"
