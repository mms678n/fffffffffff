"""HackerGPT backend API tests."""
import os
import time
import uuid
import json
import pytest
import requests

BASE = os.environ["REACT_APP_BACKEND_URL"].rstrip("/") if os.environ.get("REACT_APP_BACKEND_URL") else "https://ai-server-control.preview.emergentagent.com"
API = f"{BASE}/api"

ADMIN = {"username": "admin", "password": "admin123"}
DEMO_HOST = {"nickname": "Demo", "host": "localhost", "port": 22,
             "username": "demo", "password": "demo1234", "os": "Linux"}


# ---------------- fixtures ----------------
@pytest.fixture(scope="session")
def s():
    return requests.Session()


@pytest.fixture(scope="session")
def admin_token(s):
    r = s.post(f"{API}/auth/login", json=ADMIN, timeout=15)
    assert r.status_code == 200, r.text
    return r.json()["token"]


@pytest.fixture(scope="session")
def admin_h(admin_token):
    return {"Authorization": f"Bearer {admin_token}"}


# ---------------- auth ----------------
class TestAuth:
    def test_register_returns_token_and_recovery(self, s):
        uname = f"TEST_{uuid.uuid4().hex[:8]}"
        r = s.post(f"{API}/auth/register", json={"username": uname, "password": "pass1234"}, timeout=15)
        assert r.status_code == 200, r.text
        data = r.json()
        assert "token" in data and isinstance(data["token"], str)
        assert "recovery_code" in data and len(data["recovery_code"]) >= 8
        assert data["user"]["username"].lower() == uname.lower()
        # /me works
        me = s.get(f"{API}/auth/me", headers={"Authorization": f"Bearer {data['token']}"}, timeout=10)
        assert me.status_code == 200
        assert me.json()["username"].lower() == uname.lower()

    def test_admin_login(self, s):
        r = s.post(f"{API}/auth/login", json=ADMIN, timeout=15)
        assert r.status_code == 200
        assert r.json()["user"]["role"] == "admin"

    def test_login_invalid(self, s):
        r = s.post(f"{API}/auth/login", json={"username": "admin", "password": "wrong"}, timeout=15)
        assert r.status_code in (400, 401)

    def test_reset_password_flow(self, s):
        uname = f"TEST_{uuid.uuid4().hex[:8]}"
        r = s.post(f"{API}/auth/register", json={"username": uname, "password": "orig1234"}, timeout=15)
        assert r.status_code == 200
        rc = r.json()["recovery_code"]
        r2 = s.post(f"{API}/auth/reset-password",
                    json={"username": uname, "recovery_code": rc, "new_password": "new12345"}, timeout=15)
        assert r2.status_code == 200, r2.text
        # can login with new pw
        r3 = s.post(f"{API}/auth/login", json={"username": uname, "password": "new12345"}, timeout=15)
        assert r3.status_code == 200


# ---------------- dashboard ----------------
class TestDashboard:
    def test_stats(self, s, admin_h):
        r = s.get(f"{API}/dashboard/stats", headers=admin_h, timeout=15)
        assert r.status_code == 200
        data = r.json()
        for key in ("total_servers", "online_servers", "ai_messages"):
            assert key in data, f"missing {key}: {data}"


# ---------------- servers CRUD + SSH ----------------
@pytest.fixture(scope="session")
def demo_server(s, admin_h):
    # create server
    r = s.post(f"{API}/servers", json=DEMO_HOST, headers=admin_h, timeout=20)
    assert r.status_code == 200, r.text
    sid = r.json()["id"]
    yield sid
    # cleanup
    s.delete(f"{API}/servers/{sid}", headers=admin_h, timeout=15)


class TestServers:
    def test_list_servers(self, s, admin_h, demo_server):
        r = s.get(f"{API}/servers", headers=admin_h, timeout=10)
        assert r.status_code == 200
        assert any(x["id"] == demo_server for x in r.json())

    def test_ssh_test_connection(self, s, admin_h, demo_server):
        r = s.post(f"{API}/servers/{demo_server}/test", headers=admin_h, timeout=30)
        assert r.status_code == 200, r.text
        j = r.json()
        assert (j.get("ok") or j.get("success")) is True, r.text

    def test_ssh_connect_returns_info(self, s, admin_h, demo_server):
        r = s.post(f"{API}/servers/{demo_server}/connect", headers=admin_h, timeout=30)
        assert r.status_code == 200, r.text
        data = r.json()
        info = data.get("info") or data
        # server info should have some of these
        assert any(k in json.dumps(info).lower() for k in ("host", "cpu", "uptime", "os", "kernel")), info

    def test_exec_command(self, s, admin_h, demo_server):
        r = s.post(f"{API}/servers/{demo_server}/exec",
                   json={"command": "echo hello_hackergpt"}, headers=admin_h, timeout=30)
        assert r.status_code == 200, r.text
        assert "hello_hackergpt" in r.text

    def test_metrics(self, s, admin_h, demo_server):
        r = s.get(f"{API}/servers/{demo_server}/metrics", headers=admin_h, timeout=30)
        assert r.status_code == 200, r.text
        data = r.json()
        assert any(k in data for k in ("cpu", "ram", "memory", "disk")), data

    def test_files_browse(self, s, admin_h, demo_server):
        r = s.get(f"{API}/servers/{demo_server}/files",
                  params={"path": "/home/demo"}, headers=admin_h, timeout=30)
        assert r.status_code == 200, r.text
        data = r.json()
        entries = data.get("items", data if isinstance(data, list) else [])
        names = [e.get("name") for e in entries]
        assert "test.txt" in names, f"names={names} data={data}"

    def test_files_read_write(self, s, admin_h, demo_server):
        # write a file
        path = f"/home/demo/TEST_write_{uuid.uuid4().hex[:6]}.txt"
        r = s.post(f"{API}/servers/{demo_server}/files/write",
                   json={"path": path, "content": "hi from test"},
                   headers=admin_h, timeout=20)
        assert r.status_code == 200, r.text
        # read back
        r2 = s.get(f"{API}/servers/{demo_server}/files/read",
                   params={"path": path}, headers=admin_h, timeout=20)
        assert r2.status_code == 200
        # response could be json or plain
        assert "hi from test" in r2.text
        # cleanup
        s.post(f"{API}/servers/{demo_server}/files/delete",
               json={"path": path}, headers=admin_h, timeout=15)

    def test_files_mkdir_rename_delete(self, s, admin_h, demo_server):
        d1 = f"/home/demo/TEST_dir_{uuid.uuid4().hex[:6]}"
        d2 = d1 + "_renamed"
        r = s.post(f"{API}/servers/{demo_server}/files/mkdir",
                   json={"path": d1}, headers=admin_h, timeout=15)
        assert r.status_code == 200, r.text
        r = s.post(f"{API}/servers/{demo_server}/files/rename",
                   json={"path": d1, "new_path": d2}, headers=admin_h, timeout=15)
        assert r.status_code == 200, r.text
        r = s.post(f"{API}/servers/{demo_server}/files/delete",
                   json={"path": d2}, headers=admin_h, timeout=15)
        assert r.status_code == 200, r.text

    def test_docker_graceful(self, s, admin_h, demo_server):
        # docker not installed on host - should not 500
        r = s.get(f"{API}/servers/{demo_server}/docker/containers",
                  headers=admin_h, timeout=30)
        assert r.status_code in (200, 400, 404), r.text


# ---------------- logs & AI ----------------
class TestLogs:
    def test_logs(self, s, admin_h):
        r = s.get(f"{API}/logs", headers=admin_h, timeout=15)
        assert r.status_code == 200
        assert isinstance(r.json(), (list, dict))


class TestAI:
    def test_chat_streams(self, s, admin_h):
        # SSE stream - just check we start receiving content
        try:
            with s.post(f"{API}/ai/chat",
                        json={"message": "say hi in one word"},
                        headers=admin_h, stream=True, timeout=30) as r:
                assert r.status_code == 200, r.text
                chunks = 0
                content = ""
                for line in r.iter_lines(decode_unicode=True):
                    if line:
                        content += line + "\n"
                        chunks += 1
                    if chunks > 5:
                        break
                assert chunks > 0, "no stream chunks received"
        except requests.exceptions.ReadTimeout:
            pytest.fail("AI chat stream timed out")


# ---------------- admin ----------------
class TestAdmin:
    def test_admin_stats(self, s, admin_h):
        r = s.get(f"{API}/admin/stats", headers=admin_h, timeout=15)
        assert r.status_code == 200
        assert isinstance(r.json(), dict)

    def test_admin_users_list(self, s, admin_h):
        r = s.get(f"{API}/admin/users", headers=admin_h, timeout=15)
        assert r.status_code == 200
        assert isinstance(r.json(), list)

    def test_admin_logs(self, s, admin_h):
        r = s.get(f"{API}/admin/logs", headers=admin_h, timeout=15)
        assert r.status_code == 200

    def test_admin_change_plan_and_delete_user(self, s, admin_h):
        uname = f"TEST_{uuid.uuid4().hex[:8]}"
        r = s.post(f"{API}/auth/register", json={"username": uname, "password": "pass1234"}, timeout=15)
        uid = r.json()["user"]["id"]
        r2 = s.put(f"{API}/admin/users/{uid}/plan", params={"plan": "Pro"}, headers=admin_h, timeout=15)
        assert r2.status_code == 200, r2.text
        r3 = s.delete(f"{API}/admin/users/{uid}", headers=admin_h, timeout=15)
        assert r3.status_code == 200, r3.text

    def test_admin_endpoints_require_admin(self, s):
        # register a normal user
        uname = f"TEST_{uuid.uuid4().hex[:8]}"
        r = s.post(f"{API}/auth/register", json={"username": uname, "password": "pass1234"}, timeout=15)
        tok = r.json()["token"]
        r2 = s.get(f"{API}/admin/stats", headers={"Authorization": f"Bearer {tok}"}, timeout=15)
        assert r2.status_code in (401, 403)
