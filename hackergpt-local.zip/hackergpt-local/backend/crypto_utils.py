import os
from cryptography.fernet import Fernet

_fernet = Fernet(os.environ["ENCRYPTION_KEY"].encode())


def encrypt(value: str | None) -> str | None:
    if not value:
        return None
    return _fernet.encrypt(value.encode()).decode()


def decrypt(token: str | None) -> str | None:
    if not token:
        return None
    return _fernet.decrypt(token.encode()).decode()
