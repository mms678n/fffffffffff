"""Classify a shell command as read-only ('read') or system-modifying ('write').

'write' commands require explicit user confirmation before execution.
Unknown commands default to 'write' (safe-by-default)."""
import re

# Base binaries considered safe / read-only (info gathering only).
READ_ONLY = {
    # linux/unix
    "ls", "cat", "less", "more", "head", "tail", "tac", "nl", "df", "du", "free",
    "top", "htop", "ps", "pstree", "uptime", "whoami", "id", "who", "w", "last",
    "users", "groups", "uname", "hostname", "hostnamectl", "arch", "nproc",
    "lscpu", "lsblk", "lsusb", "lspci", "lsmod", "lsof", "ip", "ifconfig", "route",
    "netstat", "ss", "ping", "ping6", "traceroute", "tracepath", "dig", "nslookup",
    "host", "getent", "date", "cal", "env", "printenv", "echo", "pwd", "stat",
    "file", "wc", "grep", "egrep", "fgrep", "zgrep", "zcat", "cut", "sort", "uniq",
    "tr", "column", "readlink", "realpath", "basename", "dirname", "dmesg",
    "journalctl", "sensors", "vmstat", "iostat", "mpstat", "sar", "md5sum",
    "sha256sum", "sha1sum", "which", "whereis", "type", "command", "tree", "cksum",
    "getconf", "locale", "uptime", "ntpq", "timedatectl", "loginctl",
    # windows
    "dir", "tasklist", "systeminfo", "ipconfig", "type", "findstr", "ver", "vol",
    "whoami", "hostname", "sc", "netsh", "wmic", "reg", "where", "tree", "assoc",
    "ftype", "driverquery", "gpresult", "nslookup",
}

# Base commands that always modify the system.
DESTRUCTIVE_BASE = {
    # linux/unix
    "rm", "rmdir", "mv", "dd", "mkfs", "fdisk", "parted", "reboot", "shutdown",
    "halt", "poweroff", "init", "kill", "killall", "pkill", "chmod", "chown",
    "chgrp", "useradd", "userdel", "usermod", "groupadd", "groupdel", "passwd",
    "truncate", "tee", "ln", "mount", "umount", "swapon", "swapoff", "crontab",
    "ufw", "iptables", "nft", "firewall-cmd", "modprobe", "insmod", "rmmod",
    "sysctl", "setenforce", "visudo", "hostnamectl", "timedatectl", "make",
    "wget", "curl", "scp", "rsync", "unzip", "tar", "gunzip", "gzip",
    # windows
    "del", "erase", "rd", "format", "taskkill", "shutdown", "diskpart",
    "attrib", "icacls", "cacls", "takeown", "bcdedit", "rename", "move", "copy",
}

# Tools whose subcommands decide read vs write.
SUBCOMMAND_WRITE = {
    "systemctl": {"start", "stop", "restart", "reload", "reload-or-restart",
                  "enable", "disable", "mask", "unmask", "kill", "isolate",
                  "set-default", "daemon-reload", "edit", "set-property"},
    "service": {"start", "stop", "restart", "reload", "force-reload"},
    "docker": {"rm", "rmi", "stop", "start", "restart", "run", "exec", "kill",
               "pull", "push", "build", "prune", "create", "rename", "update",
               "commit", "load", "import", "system", "compose", "network",
               "volume", "tag", "save", "cp", "pause", "unpause"},
    "kubectl": {"delete", "apply", "create", "edit", "scale", "patch", "drain",
                "cordon", "uncordon", "replace", "rollout", "exec", "cp", "label",
                "annotate", "set"},
    "git": {"push", "reset", "clean", "rebase", "merge", "checkout", "commit",
            "rm", "clone", "pull", "fetch", "stash", "revert", "cherry-pick",
            "tag", "branch", "init", "add", "mv", "restore"},
    "apt": {"install", "remove", "purge", "upgrade", "full-upgrade",
            "autoremove", "update", "dist-upgrade"},
    "apt-get": {"install", "remove", "purge", "upgrade", "full-upgrade",
                "autoremove", "update", "dist-upgrade"},
    "dnf": {"install", "remove", "update", "upgrade", "erase", "autoremove",
            "downgrade", "reinstall"},
    "yum": {"install", "remove", "update", "upgrade", "erase", "autoremove",
            "downgrade", "reinstall"},
    "zypper": {"install", "remove", "update", "in", "rm", "up"},
    "pacman": {"-S", "-R", "-U", "-Syu"},
    "snap": {"install", "remove", "refresh", "revert"},
    "flatpak": {"install", "uninstall", "update"},
    "pip": {"install", "uninstall"},
    "pip3": {"install", "uninstall"},
    "npm": {"install", "uninstall", "update", "i", "ci", "rm", "remove"},
    "yarn": {"add", "remove", "install", "upgrade"},
    "brew": {"install", "uninstall", "upgrade", "remove", "reinstall"},
    "sc": {"stop", "start", "delete", "create", "config"},
    "net": {"stop", "start", "user", "localgroup"},
}

# Wrappers that should be skipped so we inspect the real command.
WRAPPERS = {"sudo", "doas", "env", "nohup", "time", "nice", "ionice", "stdbuf",
            "timeout", "xargs", "watch", "unbuffer"}


def _classify_segment(seg: str) -> str:
    seg = seg.strip()
    if not seg:
        return "read"
    # redirection to a file is a write (ignore 2>&1 style fd dups)
    if re.search(r"(?<![0-9&])>>?", seg):
        return "write"
    tokens = seg.split()
    # strip wrappers and inline VAR=val assignments
    while tokens:
        base = tokens[0].split("/")[-1]
        if base in WRAPPERS or re.match(r"^[A-Za-z_][A-Za-z0-9_]*=", tokens[0]):
            tokens = tokens[1:]
            continue
        break
    if not tokens:
        return "read"
    base = tokens[0].split("/")[-1].lower()

    if base in DESTRUCTIVE_BASE:
        return "write"
    # sed/perl/awk in-place editing modifies files
    if base in ("sed", "perl") and any(t.startswith("-i") or t == "--in-place" for t in tokens[1:]):
        return "write"
    if base == "find" and any(t in ("-delete", "-exec", "-execdir", "-ok") for t in tokens[1:]):
        return "write"
    if base in SUBCOMMAND_WRITE:
        sub = ""
        for t in tokens[1:]:
            if not t.startswith("-") or t in ("-S", "-R", "-U", "-Syu"):
                sub = t.lower()
                break
        return "write" if sub in SUBCOMMAND_WRITE[base] else "read"
    if base in READ_ONLY:
        return "read"
    # unknown command -> require confirmation
    return "write"


def classify(command: str) -> str:
    """Return 'write' if any part of the command modifies the system, else 'read'."""
    if not command or not command.strip():
        return "read"
    segments = re.split(r"&&|\|\||;|\||\n", command)
    for seg in segments:
        if _classify_segment(seg) == "write":
            return "write"
    return "read"


def label(kind: str) -> str:
    return "Modifies system" if kind == "write" else "Read-only"

PRIVILEGED_BASE = {
    "sudo", "doas", "su", "systemctl", "service", "apt", "apt-get", "dnf", "yum",
    "zypper", "pacman", "snap", "flatpak", "docker", "mount", "umount", "chown",
    "chmod", "chgrp", "useradd", "userdel", "usermod", "groupadd", "groupdel",
    "passwd", "iptables", "nft", "ufw", "firewall-cmd", "reboot", "shutdown", "poweroff",
    "sc", "netsh", "bcdedit", "diskpart", "takeown", "icacls",
}

def requires_elevation(command: str) -> bool:
    """Conservative check for commands that normally require OS elevation."""
    if not command or not command.strip():
        return False
    for segment in re.split(r"&&|\|\||;|\||\n", command):
        tokens = segment.strip().split()
        while tokens and (tokens[0] in WRAPPERS or re.match(r"^[A-Za-z_][A-Za-z0-9_]*=", tokens[0])):
            tokens.pop(0)
        if tokens and tokens[0].split("/")[-1].lower() in PRIVILEGED_BASE:
            return True
    return False
