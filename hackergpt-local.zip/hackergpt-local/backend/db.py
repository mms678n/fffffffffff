"""Small async document-store compatibility layer backed by the managed SQL database.

The existing API is document-shaped. Keeping this adapter lets the migration preserve
endpoint behavior while making storage durable in the platform-managed MySQL database.
"""
import copy
import os
import re
import secrets
from types import SimpleNamespace
from urllib.parse import urlparse, urlunparse

from sqlalchemy import JSON, Column, MetaData, String, Table, Text, select, text, update as sql_update, delete as sql_delete
from sqlalchemy.ext.asyncio import create_async_engine


def _dsn(value: str | None) -> str:
    value = (value or "sqlite+aiosqlite:///./hackergpt.db").strip()
    if value.startswith("mysql://"):
        return "mysql+aiomysql://" + value[len("mysql://"):]
    if value.startswith("mysql+pymysql://"):
        return "mysql+aiomysql://" + value[len("mysql+pymysql://"):]
    return value


def _get(doc, path):
    value = doc
    for part in path.split("."):
        if not isinstance(value, dict) or part not in value:
            return None
        value = value[part]
    return value


def _same(left, right):
    if hasattr(right, "binary"):
        right = str(right)
    return left == right or str(left) == str(right)


def _matches(doc, query):
    for key, expected in (query or {}).items():
        if key == "$or":
            if not any(_matches(doc, branch) for branch in expected):
                return False
            continue
        actual = _get(doc, "_id" if key == "_id" else key)
        if isinstance(expected, dict):
            for op, value in expected.items():
                if op == "$in" and not any(_same(actual, item) for item in value):
                    return False
                if op == "$ne" and _same(actual, value):
                    return False
                if op == "$exists" and ((actual is not None) != bool(value)):
                    return False
                if op == "$gte" and not (actual is not None and actual >= value):
                    return False
                if op == "$lte" and not (actual is not None and actual <= value):
                    return False
        elif not _same(actual, expected):
            return False
    return True


def _project(doc, projection):
    if not projection:
        return copy.deepcopy(doc)
    include = {k for k, v in projection.items() if v and k != "_id"}
    if not include:
        return copy.deepcopy(doc)
    result = {"_id": doc.get("_id")}
    for key in include:
        if key in doc:
            result[key] = copy.deepcopy(doc[key])
    return result


class Cursor:
    def __init__(self, collection, query, projection=None):
        self.collection = collection
        self.query = query or {}
        self.projection = projection
        self._sort = None
        self._limit = None
        self._docs = None

    async def _load(self):
        docs = [d for d in await self.collection._all() if _matches(d, self.query)]
        if self._sort:
            key, direction = self._sort
            docs.sort(key=lambda d: (_get(d, key) is None, _get(d, key)), reverse=direction < 0)
        if self._limit:
            docs = docs[: self._limit]
        self._docs = [_project(d, self.projection) for d in docs]
        return self._docs

    def sort(self, key, direction):
        self._sort = (key, direction)
        return self

    def limit(self, count):
        self._limit = count
        return self

    async def to_list(self, length=None):
        docs = await self._load()
        return docs if length is None else docs[:length]

    def __aiter__(self):
        return self._iterate()

    async def _iterate(self):
        for doc in await self._load():
            yield doc


class Collection:
    def __init__(self, store, name):
        self.store = store
        self.name = name

    async def _all(self):
        async with self.store.engine.connect() as conn:
            rows = (await conn.execute(select(self.store.documents.c.data).where(self.store.documents.c.collection == self.name))).scalars().all()
            return [copy.deepcopy(row) for row in rows]

    def find(self, query=None, projection=None):
        return Cursor(self, query, projection)

    async def find_one(self, query=None, projection=None):
        for doc in await self._all():
            if _matches(doc, query or {}):
                return _project(doc, projection)
        return None

    async def insert_one(self, doc):
        item = copy.deepcopy(doc)
        item.setdefault("_id", secrets.token_hex(12))
        async with self.store.engine.begin() as conn:
            await conn.execute(self.store.documents.insert().values(collection=self.name, doc_id=str(item["_id"]), data=item))
        return SimpleNamespace(inserted_id=item["_id"])

    async def _replace(self, doc):
        async with self.store.engine.begin() as conn:
            await conn.execute(sql_update(self.store.documents).where(
                (self.store.documents.c.collection == self.name) & (self.store.documents.c.doc_id == str(doc["_id"]))
            ).values(data=doc))

    async def update_one(self, query, update):
        doc = await self.find_one(query)
        if not doc:
            return SimpleNamespace(matched_count=0, modified_count=0)
        for key, value in (update.get("$set") or {}).items():
            doc[key] = copy.deepcopy(value)
        for key in (update.get("$unset") or {}):
            doc.pop(key, None)
        await self._replace(doc)
        return SimpleNamespace(matched_count=1, modified_count=1)

    async def update_many(self, query, update):
        docs = [d for d in await self._all() if _matches(d, query or {})]
        for doc in docs:
            for key, value in (update.get("$set") or {}).items():
                doc[key] = copy.deepcopy(value)
            await self._replace(doc)
        return SimpleNamespace(matched_count=len(docs), modified_count=len(docs))

    async def delete_one(self, query):
        doc = await self.find_one(query)
        if not doc:
            return SimpleNamespace(deleted_count=0)
        async with self.store.engine.begin() as conn:
            await conn.execute(sql_delete(self.store.documents).where(
                (self.store.documents.c.collection == self.name) & (self.store.documents.c.doc_id == str(doc["_id"]))
            ))
        return SimpleNamespace(deleted_count=1)

    async def delete_many(self, query):
        docs = [d for d in await self._all() if _matches(d, query or {})]
        async with self.store.engine.begin() as conn:
            for doc in docs:
                await conn.execute(sql_delete(self.store.documents).where(
                    (self.store.documents.c.collection == self.name) & (self.store.documents.c.doc_id == str(doc["_id"]))
                ))
        return SimpleNamespace(deleted_count=len(docs))

    async def count_documents(self, query=None):
        return sum(1 for d in await self._all() if _matches(d, query or {}))

    async def create_index(self, *args, **kwargs):
        return None


class SQLDatabase:
    def __init__(self, dsn=None):
        self.engine = create_async_engine(_dsn(dsn), pool_pre_ping=True)
        self.metadata = MetaData()
        self.documents = Table(
            "hackergpt_documents", self.metadata,
            Column("collection", String(80), primary_key=True),
            Column("doc_id", String(64), primary_key=True),
            Column("data", JSON, nullable=False),
        )

    def __getattr__(self, name):
        if name.startswith("_"):
            raise AttributeError(name)
        return Collection(self, name)

    async def init(self):
        async with self.engine.begin() as conn:
            await conn.run_sync(self.metadata.create_all)

    async def command(self, name):
        async with self.engine.connect() as conn:
            await conn.execute(text("SELECT 1"))
        return {"ok": 1}

    async def close(self):
        await self.engine.dispose()
