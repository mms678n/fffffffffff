from datetime import datetime, timezone
from typing import Annotated, Any, Optional
from bson import ObjectId
from pydantic import BaseModel, BeforeValidator, Field, ConfigDict


def _validate_object_id(v: Any) -> str:
    if isinstance(v, ObjectId):
        return str(v)
    return str(v)


PyObjectId = Annotated[str, BeforeValidator(_validate_object_id)]


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def iso_now() -> str:
    return utcnow().isoformat()


class BaseDocument(BaseModel):
    model_config = ConfigDict(populate_by_name=True, arbitrary_types_allowed=True)
    id: Optional[PyObjectId] = Field(default=None, alias="_id")

    @classmethod
    def from_mongo(cls, doc: dict):
        if not doc:
            return None
        return cls(**doc)

    def to_mongo(self) -> dict:
        data = self.model_dump(by_alias=True, exclude_none=True)
        data.pop("_id", None)
        return data


# ---------- API request/response schemas ----------

class RegisterInput(BaseModel):
    username: str
    password: str


class LoginInput(BaseModel):
    username: str
    password: str


class ResetPasswordInput(BaseModel):
    username: str
    recovery_code: str
    new_password: str


class ServerInput(BaseModel):
    nickname: str
    host: str
    port: int = 22
    username: str
    password: Optional[str] = None
    ssh_key: Optional[str] = None
    os: Optional[str] = "Linux"


class ExecInput(BaseModel):
    command: str


class ChatInput(BaseModel):
    session_id: Optional[str] = None
    server_id: Optional[str] = None
    message: str
    terminal_context: Optional[str] = None


class FileWriteInput(BaseModel):
    path: str
    content: str


class FileOpInput(BaseModel):
    path: str
    new_path: Optional[str] = None


class DeviceRegisterInput(BaseModel):
    device_id: str
    device_secret: str
    name: Optional[str] = None


class DeviceRenameInput(BaseModel):
    name: str


class DeviceRotateInput(BaseModel):
    device_secret: str


class DeviceIconInput(BaseModel):
    icon: str
