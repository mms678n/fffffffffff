import json
import os
from openai import AsyncOpenAI

_client = AsyncOpenAI(
    api_key=os.environ.get("OPENROUTER_API_KEY", ""),
    base_url=os.environ.get("OPENROUTER_BASE_URL", "https://openrouter.ai/api/v1"),
    default_headers={
        "HTTP-Referer": os.environ.get("OPENROUTER_HTTP_REFERER", "https://hackergpt.app"),
        "X-Title": os.environ.get("OPENROUTER_TITLE", "HackerGPT"),
    },
)
MODEL = os.environ.get("OPENROUTER_MODEL", "openai/gpt-4o-mini")

SYSTEM_PROMPT = """You are HackerGPT, an elite AI Linux/Unix server administrator embedded inside a real server management platform.

You are NOT a generic chatbot. You help the user operate REAL servers they own and have connected over SSH. You reason about system administration, DevOps, networking, Docker, security, logs and shell scripting.

RULES:
- Be concise, precise and professional. Use Markdown.
- When you propose shell commands to run, ALWAYS put them in fenced ```bash code blocks. Each runnable command block will get a "Run in terminal" button in the UI, so keep each block focused and runnable.
- For sensitive/destructive operations (rm -rf, reboot, shutdown, dd, mkfs, user/permission changes, package removal, firewall changes) clearly warn the user BEFORE the command and tell them to confirm.
- Explain WHAT a command does and WHY, then give the command.
- When the user shares command output or errors, analyze it and explain the fix.
- If a server is connected, tailor advice to its OS. If no server is connected, say so and give general guidance.
- Never invent fake output. Never claim you executed something you didn't.
"""


def build_context(server_info: dict | None, terminal_context: str | None) -> str:
    ctx = []
    if server_info:
        ctx.append(
            "CONNECTED SERVER:\n"
            f"- Hostname: {server_info.get('hostname')}\n"
            f"- OS: {server_info.get('os')}\n"
            f"- Arch: {server_info.get('arch')}\n"
            f"- CPU cores: {server_info.get('cpu_cores')}\n"
            f"- RAM(MB used/total): {server_info.get('ram')}\n"
            f"- Disk: {server_info.get('disk')}\n"
            f"- IP: {server_info.get('ip')}\n"
            f"- Uptime: {server_info.get('uptime')}"
        )
    else:
        ctx.append("No server is currently connected.")
    if terminal_context:
        ctx.append(f"RECENT TERMINAL OUTPUT:\n```\n{terminal_context[-3000:]}\n```")
    return "\n\n".join(ctx)


async def stream_chat(history: list[dict], server_info: dict | None, terminal_context: str | None):
    messages = [{"role": "system", "content": SYSTEM_PROMPT}]
    context = build_context(server_info, terminal_context)
    messages.append({"role": "system", "content": context})
    messages.extend(history)

    stream = await _client.chat.completions.create(
        model=MODEL,
        messages=messages,
        stream=True,
        temperature=0.3,
        max_tokens=2048,
    )
    async for chunk in stream:
        delta = chunk.choices[0].delta
        if delta and delta.content:
            yield delta.content


# ---------------- Device (Agent) command execution ----------------

DEVICE_SYSTEM_PROMPT = """You are HackerGPT, an elite AI system administrator operating a REAL machine the user owns and has securely linked as a device (via the HackerGPT Agent).

You have exactly ONE tool: run_command. Use it to inspect or change the device.

RULES:
- For ANY request that needs information from the device or a change to it, call run_command with ONE precise, correct, NON-INTERACTIVE shell command appropriate for the device's operating system.
- Pick commands that match the device OS (Linux/macOS use bash; Windows uses cmd/PowerShell syntax).
- Prefer safe, read-only commands when the user only wants information (e.g. df, free, top -b -n1, systemctl status, cat).
- NEVER use interactive/blocking commands (no vim, nano, top without -b, tail -f, ping without a count, etc.).
- Combine steps into a single command with pipes when reasonable.
- Put a short, clear reason in the `explanation` field.
- If the user's message is purely conversational, ambiguous, or you must ask a clarifying question, DO NOT call the tool — reply with plain text instead.
- Never invent output. You will be shown the real command output afterwards to analyze."""

RUN_COMMAND_TOOL = [{
    "type": "function",
    "function": {
        "name": "run_command",
        "description": "Execute a single shell command on the user's linked device to fulfil their request.",
        "parameters": {
            "type": "object",
            "properties": {
                "command": {"type": "string", "description": "The exact, non-interactive shell command to run."},
                "explanation": {"type": "string", "description": "One short sentence: what this command does and why."},
            },
            "required": ["command", "explanation"],
        },
    },
}]


def build_device_context(device_info: dict | None) -> str:
    if not device_info:
        return "LINKED DEVICE: (no system details reported yet — assume a generic Linux host)."
    return (
        "LINKED DEVICE:\n"
        f"- Name: {device_info.get('device_name')}\n"
        f"- Hostname: {device_info.get('hostname')}\n"
        f"- OS: {device_info.get('os')} {device_info.get('os_version')}\n"
        f"- OS detail: {device_info.get('os_full')}\n"
        f"- Arch: {device_info.get('arch')}\n"
        f"- CPU: {device_info.get('cpu')} ({device_info.get('cpu_cores')} cores)\n"
        f"- RAM total: {device_info.get('ram_total_gb')} GB\n"
        f"- Current user: {device_info.get('current_user')}"
    )


async def plan_device_command(history: list[dict], device_info: dict | None) -> dict:
    """Ask the model to either reply with text or propose ONE command via tool call."""
    messages = [
        {"role": "system", "content": DEVICE_SYSTEM_PROMPT},
        {"role": "system", "content": build_device_context(device_info)},
    ]
    messages.extend(history)
    resp = await _client.chat.completions.create(
        model=MODEL,
        messages=messages,
        tools=RUN_COMMAND_TOOL,
        tool_choice="auto",
        temperature=0.2,
        max_tokens=1024,
    )
    msg = resp.choices[0].message
    text = msg.content or ""
    if msg.tool_calls:
        for tc in msg.tool_calls:
            if tc.function and tc.function.name == "run_command":
                try:
                    args = json.loads(tc.function.arguments or "{}")
                except Exception:
                    args = {}
                cmd = (args.get("command") or "").strip()
                if cmd:
                    return {"command": cmd, "explanation": args.get("explanation", ""), "text": text}
    return {"command": None, "explanation": "", "text": text}


async def analyze_device_output(user_request: str, command: str, output: str,
                                exit_code, device_info: dict | None):
    """Stream a human-readable explanation of a command's result."""
    context = build_device_context(device_info)
    truncated = output[-6000:] if output else "(no output produced)"
    prompt = (
        f"The user asked: {user_request}\n\n"
        f"You ran this command on their device:\n$ {command}\n\n"
        f"Exit code: {exit_code}\n\n"
        f"Command output:\n```\n{truncated}\n```\n\n"
        "Now explain the result to the user in clear, concise Markdown: what it means, "
        "whether it succeeded, and any recommended next steps. If it failed, diagnose why. "
        "Do NOT repeat the raw output verbatim."
    )
    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "system", "content": context},
        {"role": "user", "content": prompt},
    ]
    stream = await _client.chat.completions.create(
        model=MODEL, messages=messages, stream=True, temperature=0.3, max_tokens=1200,
    )
    async for chunk in stream:
        delta = chunk.choices[0].delta
        if delta and delta.content:
            yield delta.content
