import io
import threading
import time
from typing import Optional

import paramiko

from crypto_utils import decrypt

_clients: dict[str, dict] = {}
_locks: dict[str, threading.Lock] = {}
_global_lock = threading.Lock()
IDLE_TIMEOUT = 300


def _get_lock(server_id: str) -> threading.Lock:
    with _global_lock:
        if server_id not in _locks:
            _locks[server_id] = threading.Lock()
        return _locks[server_id]


def _build_client(server: dict) -> paramiko.SSHClient:
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    password = decrypt(server.get("password_enc"))
    key_str = decrypt(server.get("ssh_key_enc"))
    pkey = None
    if key_str:
        for cls in (paramiko.RSAKey, paramiko.Ed25519Key, paramiko.ECDSAKey, paramiko.DSSKey):
            try:
                pkey = cls.from_private_key(io.StringIO(key_str))
                break
            except Exception:
                continue
    client.connect(
        hostname=server["host"],
        port=int(server.get("port", 22)),
        username=server["username"],
        password=password,
        pkey=pkey,
        timeout=12,
        banner_timeout=12,
        auth_timeout=12,
        look_for_keys=False,
        allow_agent=False,
    )
    return client


def get_client(server: dict) -> paramiko.SSHClient:
    server_id = str(server["_id"])
    entry = _clients.get(server_id)
    if entry:
        transport = entry["client"].get_transport()
        if transport and transport.is_active():
            entry["last"] = time.time()
            return entry["client"]
        try:
            entry["client"].close()
        except Exception:
            pass
    client = _build_client(server)
    _clients[server_id] = {"client": client, "last": time.time()}
    return client


def close_client(server_id: str):
    entry = _clients.pop(server_id, None)
    if entry:
        try:
            entry["client"].close()
        except Exception:
            pass


def reap_idle():
    now = time.time()
    for sid in list(_clients.keys()):
        if now - _clients[sid]["last"] > IDLE_TIMEOUT:
            close_client(sid)


def test_connection(server: dict) -> tuple[bool, str]:
    try:
        client = _build_client(server)
        client.exec_command("echo ok", timeout=8)
        client.close()
        return True, "Connection successful"
    except Exception as e:
        return False, str(e)


def run_command(server: dict, command: str, timeout: int = 30) -> dict:
    lock = _get_lock(str(server["_id"]))
    with lock:
        client = get_client(server)
        stdin, stdout, stderr = client.exec_command(command, timeout=timeout, get_pty=False)
        out = stdout.read().decode("utf-8", errors="replace")
        err = stderr.read().decode("utf-8", errors="replace")
        code = stdout.channel.recv_exit_status()
    return {"stdout": out, "stderr": err, "exit_code": code}


INFO_CMD = (
    "hostname; echo '<SEP>'; "
    "(. /etc/os-release 2>/dev/null && echo \"$PRETTY_NAME\") || uname -o; echo '<SEP>'; "
    "nproc; echo '<SEP>'; "
    "free -m | awk '/Mem:/{print $3\"/\"$2}'; echo '<SEP>'; "
    "df -h --output=used,size / | tail -1 | tr -s ' '; echo '<SEP>'; "
    "uname -m; echo '<SEP>'; "
    "(hostname -I 2>/dev/null | awk '{print $1}') || echo n/a; echo '<SEP>'; "
    "uptime -p 2>/dev/null || uptime; echo '<SEP>'; "
    "whoami"
)


def get_server_info(server: dict) -> dict:
    res = run_command(server, INFO_CMD, timeout=20)
    parts = [p.strip() for p in res["stdout"].split("<SEP>")]
    while len(parts) < 9:
        parts.append("n/a")
    return {
        "hostname": parts[0] or "n/a",
        "os": parts[1] or "n/a",
        "cpu_cores": parts[2] or "n/a",
        "ram": parts[3] or "n/a",
        "disk": parts[4] or "n/a",
        "arch": parts[5] or "n/a",
        "ip": parts[6] or "n/a",
        "uptime": parts[7] or "n/a",
        "logged_user": parts[8] or "n/a",
    }


MONITOR_CMD = (
    "top -bn1 | grep -i '%Cpu' | head -1; echo '<SEP>'; "
    "free -m | awk '/Mem:/{print $2, $3, $4}'; echo '<SEP>'; "
    "df -m --output=size,used,avail / | tail -1; echo '<SEP>'; "
    "cat /proc/net/dev | awk 'NR>2{rx+=$2; tx+=$10} END{print rx, tx}'; echo '<SEP>'; "
    "ps -eo pid,comm,pcpu,pmem --sort=-pcpu | head -11"
)


def get_metrics(server: dict) -> dict:
    res = run_command(server, MONITOR_CMD, timeout=20)
    parts = res["stdout"].split("<SEP>")
    while len(parts) < 5:
        parts.append("")
    # CPU
    cpu_line = parts[0].strip()
    cpu_used = 0.0
    try:
        for tok in cpu_line.replace(",", " ").split():
            if "id" in tok:
                idx = cpu_line.replace(",", " ").split().index(tok)
                idle = float(cpu_line.replace(",", " ").split()[idx - 1])
                cpu_used = round(100 - idle, 1)
                break
    except Exception:
        cpu_used = 0.0
    # RAM
    ram = {"total": 0, "used": 0, "free": 0}
    try:
        t, u, f = parts[1].split()
        ram = {"total": int(t), "used": int(u), "free": int(f)}
    except Exception:
        pass
    # Disk
    disk = {"total": 0, "used": 0, "free": 0}
    try:
        size, used, avail = parts[2].split()
        disk = {"total": int(size), "used": int(used), "free": int(avail)}
    except Exception:
        pass
    # Network
    net = {"rx": 0, "tx": 0}
    try:
        rx, tx = parts[3].split()
        net = {"rx": int(rx), "tx": int(tx)}
    except Exception:
        pass
    # Processes
    processes = []
    for line in parts[4].strip().splitlines()[1:]:
        cols = line.split(None, 3)
        if len(cols) >= 4:
            processes.append({"pid": cols[0], "name": cols[1], "cpu": cols[2], "mem": cols[3]})
    return {"cpu": cpu_used, "ram": ram, "disk": disk, "net": net, "processes": processes}


# ---------------- SFTP file operations ----------------

def _sftp(server: dict):
    client = get_client(server)
    return client.open_sftp()


def list_dir(server: dict, path: str) -> list[dict]:
    lock = _get_lock(str(server["_id"]))
    with lock:
        sftp = _sftp(server)
        items = []
        for attr in sftp.listdir_attr(path):
            is_dir = bool(attr.st_mode and (attr.st_mode & 0o040000))
            items.append({
                "name": attr.filename,
                "is_dir": is_dir,
                "size": attr.st_size,
                "mtime": attr.st_mtime,
                "mode": oct(attr.st_mode & 0o777) if attr.st_mode else "",
            })
        sftp.close()
    items.sort(key=lambda x: (not x["is_dir"], x["name"].lower()))
    return items


def read_file(server: dict, path: str, max_bytes: int = 500_000) -> str:
    lock = _get_lock(str(server["_id"]))
    with lock:
        sftp = _sftp(server)
        with sftp.open(path, "r") as f:
            data = f.read(max_bytes)
        sftp.close()
    if isinstance(data, bytes):
        return data.decode("utf-8", errors="replace")
    return data


def write_file(server: dict, path: str, content: str):
    lock = _get_lock(str(server["_id"]))
    with lock:
        sftp = _sftp(server)
        with sftp.open(path, "w") as f:
            f.write(content)
        sftp.close()


def delete_path(server: dict, path: str):
    lock = _get_lock(str(server["_id"]))
    with lock:
        sftp = _sftp(server)
        try:
            sftp.remove(path)
        except IOError:
            _rmdir_recursive(sftp, path)
        sftp.close()


def _rmdir_recursive(sftp, path):
    for attr in sftp.listdir_attr(path):
        full = f"{path.rstrip('/')}/{attr.filename}"
        if attr.st_mode and (attr.st_mode & 0o040000):
            _rmdir_recursive(sftp, full)
        else:
            sftp.remove(full)
    sftp.rmdir(path)


def rename_path(server: dict, path: str, new_path: str):
    lock = _get_lock(str(server["_id"]))
    with lock:
        sftp = _sftp(server)
        sftp.rename(path, new_path)
        sftp.close()


def make_dir(server: dict, path: str):
    lock = _get_lock(str(server["_id"]))
    with lock:
        sftp = _sftp(server)
        sftp.mkdir(path)
        sftp.close()


def upload_bytes(server: dict, path: str, data: bytes):
    lock = _get_lock(str(server["_id"]))
    with lock:
        sftp = _sftp(server)
        with sftp.open(path, "wb") as f:
            f.write(data)
        sftp.close()


def download_bytes(server: dict, path: str, max_bytes: int = 20_000_000) -> bytes:
    lock = _get_lock(str(server["_id"]))
    with lock:
        sftp = _sftp(server)
        with sftp.open(path, "rb") as f:
            data = f.read(max_bytes)
        sftp.close()
    return data
