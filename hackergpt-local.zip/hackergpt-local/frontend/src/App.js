import "@/App.css";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { Toaster } from "sonner";
import { AuthProvider, useAuth } from "@/context/AuthContext";
import Landing from "@/pages/Landing";
import Login from "@/pages/Login";
import Register from "@/pages/Register";
import ResetPassword from "@/pages/ResetPassword";
import DashboardLayout from "@/components/DashboardLayout";
import Dashboard from "@/pages/Dashboard";
import Servers from "@/pages/Servers";
import Devices from "@/pages/Devices";
import ManageDevice from "@/pages/ManageDevice";
import Workspace from "@/pages/Workspace";
import FileManager from "@/pages/FileManager";
import Monitor from "@/pages/Monitor";
import Docker from "@/pages/Docker";
import Logs from "@/pages/Logs";
import Admin from "@/pages/Admin";
import AgentDownloads from "@/pages/AgentDownloads";

const LOCAL_MODE = process.env.REACT_APP_LOCAL_MODE === "true";

function Protected({ children, adminOnly }) {
  const { user, loading } = useAuth();
  if (loading)
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-white/20 border-t-accent-ai rounded-full animate-spin" />
      </div>
    );
  if (!user) return <Navigate to="/login" replace />;
  if (adminOnly && user.role !== "admin") return <Navigate to="/app" replace />;
  return children;
}

function App() {
  return (
    <div className="App">
      <AuthProvider>
        <Toaster theme="dark" position="bottom-right" richColors />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={LOCAL_MODE ? <Navigate to="/app" replace /> : <Landing />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/recover" element={<ResetPassword />} />
            <Route
              path="/app"
              element={
                <Protected>
                  <DashboardLayout />
                </Protected>
              }
            >
              <Route index element={<Dashboard />} />
              <Route path="servers" element={<Servers />} />
              <Route path="devices" element={<Devices />} />
              <Route path="devices/:id" element={<ManageDevice />} />
              <Route path="agent-downloads" element={<AgentDownloads />} />
              <Route path="workspace" element={<Workspace />} />
              <Route path="files" element={<FileManager />} />
              <Route path="monitor" element={<Monitor />} />
              <Route path="docker" element={<Docker />} />
              <Route path="logs" element={<Logs />} />
              <Route
                path="admin"
                element={
                  <Protected adminOnly>
                    <Admin />
                  </Protected>
                }
              />
            </Route>
          </Routes>
        </BrowserRouter>
      </AuthProvider>
    </div>
  );
}

export default App;
