import { useEffect, useRef, useState, forwardRef, useImperativeHandle } from "react";
import { Terminal as XTerm } from "@xterm/xterm";
import { FitAddon } from "@xterm/addon-fit";
import "@xterm/xterm/css/xterm.css";
import { toast } from "sonner";
import { Plus, X, Copy, Trash2, RotateCw, Maximize2, Minimize2, TerminalSquare } from "lucide-react";
import { wsUrl, getToken } from "../lib/api";

const THEME = {
  background: "#050505", foreground: "#F8F8F2", cursor: "#22C55E", cursorAccent: "#050505",
  selectionBackground: "#3a1414", black: "#050505", brightBlack: "#6a6a75",
  red: "#EF4444", green: "#22C55E", yellow: "#F59E0B", blue: "#5AC8FA",
  magenta: "#B22222", cyan: "#D4AF37", white: "#F8F8F2", brightGreen: "#22C55E",
};

function Session({ id, serverId, registerApi, active }) {
  const containerRef = useRef(null);
  const termRef = useRef(null);
  const fitRef = useRef(null);
  const wsRef = useRef(null);
  const bufferRef = useRef("");
  const [status, setStatus] = useState("connecting");

  const connect = () => {
    const term = termRef.current;
    const token = getToken();
    const ws = new WebSocket(wsUrl(`/api/ws/terminal/${serverId}?token=${token}`));
    wsRef.current = ws;
    setStatus("connecting");
    ws.onmessage = (e) => {
      try {
        const msg = JSON.parse(e.data);
        if (msg.type === "output" || msg.type === "connected") {
          if (msg.type === "connected") { setStatus("connected"); term.write(`\x1b[36m● ${msg.data}\x1b[0m\r\n`); }
          else { term.write(msg.data); bufferRef.current = (bufferRef.current + msg.data).slice(-6000); }
        } else if (msg.type === "error") {
          setStatus("error"); term.write(`\r\n\x1b[31m✖ ${msg.data}\x1b[0m\r\n`);
        }
      } catch (err) {}
    };
    ws.onclose = () => { setStatus("closed"); term.write("\r\n\x1b[33m● Session closed. Click reconnect.\x1b[0m\r\n"); };
    ws.onerror = () => setStatus("error");
    term.onData((data) => { if (ws.readyState === 1) ws.send(JSON.stringify({ type: "input", data })); });
  };

  useEffect(() => {
    const term = new XTerm({
      fontFamily: "'JetBrains Mono', monospace", fontSize: 13, theme: THEME,
      cursorBlink: true, scrollback: 5000, convertEol: false,
    });
    const fit = new FitAddon();
    term.loadAddon(fit);
    term.open(containerRef.current);
    termRef.current = term; fitRef.current = fit;
    setTimeout(() => { try { fit.fit(); } catch (e) {} }, 50);
    connect();

    const api = {
      runCommand: (cmd) => { if (wsRef.current?.readyState === 1) { wsRef.current.send(JSON.stringify({ type: "input", data: cmd + "\n" })); } },
      getBuffer: () => bufferRef.current,
      clear: () => term.clear(),
      copy: () => { const sel = term.getSelection(); if (sel) { navigator.clipboard.writeText(sel); toast.success("Copied selection"); } else toast.message("Select text to copy"); },
      reconnect: () => { try { wsRef.current?.close(); } catch (e) {} term.write("\r\n\x1b[36m● Reconnecting...\x1b[0m\r\n"); connect(); },
      fit: () => { try { fit.fit(); const dims = fit.proposeDimensions(); if (dims && wsRef.current?.readyState === 1) wsRef.current.send(JSON.stringify({ type: "resize", cols: dims.cols, rows: dims.rows })); } catch (e) {} },
      getStatus: () => status,
    };
    registerApi(id, api);

    const ro = new ResizeObserver(() => { try { fit.fit(); const dims = fit.proposeDimensions(); if (dims && wsRef.current?.readyState === 1) wsRef.current.send(JSON.stringify({ type: "resize", cols: dims.cols, rows: dims.rows })); } catch (e) {} });
    ro.observe(containerRef.current);

    return () => { ro.disconnect(); try { wsRef.current?.close(); } catch (e) {} term.dispose(); registerApi(id, null); };
    // eslint-disable-next-line
  }, [serverId]);

  useEffect(() => { if (active) setTimeout(() => { try { fitRef.current?.fit(); } catch (e) {} }, 30); }, [active]);

  return <div ref={containerRef} className={`absolute inset-0 ${active ? "" : "invisible"}`} data-testid={`terminal-session-${id}`} />;
}

const Terminal = forwardRef(({ serverId, fullscreen, onToggleFullscreen }, ref) => {
  const [tabs, setTabs] = useState([{ id: 1 }]);
  const [activeTab, setActiveTab] = useState(1);
  const [nextId, setNextId] = useState(2);
  const [statusTick, setStatusTick] = useState(0);
  const apisRef = useRef({});

  const registerApi = (id, api) => { if (api) apisRef.current[id] = api; else delete apisRef.current[id]; setStatusTick((t) => t + 1); };
  const activeApi = () => apisRef.current[activeTab];

  useImperativeHandle(ref, () => ({
    runCommand: (cmd) => activeApi()?.runCommand(cmd),
    getBuffer: () => activeApi()?.getBuffer() || "",
  }));

  const addTab = () => { setTabs((t) => [...t, { id: nextId }]); setActiveTab(nextId); setNextId((n) => n + 1); };
  const closeTab = (id, e) => {
    e.stopPropagation();
    if (tabs.length === 1) return;
    setTabs((t) => t.filter((x) => x.id !== id));
    if (activeTab === id) setActiveTab(tabs.find((x) => x.id !== id).id);
  };

  if (!serverId) {
    return <div className="h-full flex items-center justify-center bg-[#050505] text-white/30"><div className="text-center"><TerminalSquare className="w-8 h-8 mx-auto mb-3" /><p className="text-sm">Connect a server to open a terminal</p></div></div>;
  }

  return (
    <div className="h-full flex flex-col bg-[#050505]">
      <div className="flex items-center gap-1 px-2 h-10 border-b border-white/8 shrink-0 bg-black/40">
        <div className="flex items-center gap-1 mr-2"><span className="w-3 h-3 rounded-full bg-[#FF3B30]" /><span className="w-3 h-3 rounded-full bg-[#FFCC00]" /><span className="w-3 h-3 rounded-full bg-[#22C55E]" /></div>
        <div className="flex items-center gap-1 flex-1 overflow-x-auto">
          {tabs.map((t) => (
            <button key={t.id} onClick={() => setActiveTab(t.id)} data-testid={`terminal-tab-${t.id}`}
              className={`group flex items-center gap-2 px-3 h-7 rounded-md text-xs font-mono whitespace-nowrap transition-colors ${activeTab === t.id ? "bg-white/10 text-white" : "text-white/40 hover:text-white/70 hover:bg-white/5"}`}>
              <span className={`w-1.5 h-1.5 rounded-full ${apisRef.current[t.id]?.getStatus?.() === "connected" ? "bg-[#22C55E]" : "bg-white/30"}`} />
              zsh {t.id}
              {tabs.length > 1 && <X onClick={(e) => closeTab(t.id, e)} className="w-3 h-3 opacity-0 group-hover:opacity-100 hover:text-red-400" />}
            </button>
          ))}
          <button onClick={addTab} className="p-1.5 rounded-md text-white/40 hover:text-white hover:bg-white/5" data-testid="terminal-add-tab"><Plus className="w-3.5 h-3.5" /></button>
        </div>
        <div className="flex items-center gap-0.5">
          <IconBtn title="Copy selection" onClick={() => activeApi()?.copy()} testid="terminal-copy"><Copy className="w-3.5 h-3.5" /></IconBtn>
          <IconBtn title="Clear" onClick={() => activeApi()?.clear()} testid="terminal-clear"><Trash2 className="w-3.5 h-3.5" /></IconBtn>
          <IconBtn title="Reconnect" onClick={() => activeApi()?.reconnect()} testid="terminal-reconnect"><RotateCw className="w-3.5 h-3.5" /></IconBtn>
          <IconBtn title="Fullscreen" onClick={onToggleFullscreen} testid="terminal-fullscreen">{fullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}</IconBtn>
        </div>
      </div>
      <div className="flex-1 relative overflow-hidden">
        {tabs.map((t) => (<Session key={t.id} id={t.id} serverId={serverId} registerApi={registerApi} active={activeTab === t.id} />))}
      </div>
    </div>
  );
});

function IconBtn({ children, onClick, title, testid }) {
  return <button title={title} onClick={onClick} data-testid={testid} className="p-1.5 rounded-md text-white/40 hover:text-white hover:bg-white/10 transition-colors">{children}</button>;
}

export default Terminal;
