import { useCallback, useEffect, useRef, useState } from "react";
import { Terminal as XTerm } from "@xterm/xterm";
import { FitAddon } from "@xterm/addon-fit";
import "@xterm/xterm/css/xterm.css";
import { RotateCw, TerminalSquare, Circle } from "lucide-react";
import { wsUrl, getToken } from "../lib/api";

const THEME = { background: "#050505", foreground: "#F8F8F2", cursor: "#22C55E", cursorAccent: "#050505", selectionBackground: "#3a1414", black: "#050505", brightBlack: "#6a6a75", red: "#EF4444", green: "#22C55E", yellow: "#F59E0B", blue: "#5AC8FA", magenta: "#B22222", cyan: "#D4AF37", white: "#F8F8F2", brightGreen: "#22C55E" };

export default function DeviceTerminal({ deviceId, deviceName, onOffline }) {
  const containerRef = useRef(null);
  const termRef = useRef(null);
  const fitRef = useRef(null);
  const wsRef = useRef(null);
  const retryRef = useRef(null);
  const keepaliveRef = useRef(null);
  const stoppedRef = useRef(false);
  const attemptRef = useRef(0);
  const [status, setStatus] = useState("connecting");

  const sendResize = useCallback(() => {
    try {
      fitRef.current?.fit();
      const dims = fitRef.current?.proposeDimensions();
      if (dims && wsRef.current?.readyState === WebSocket.OPEN) wsRef.current.send(JSON.stringify({ type: "resize", cols: dims.cols, rows: dims.rows }));
    } catch { /* noop */ }
  }, []);

  const scheduleReconnect = useCallback(() => {
    if (stoppedRef.current || retryRef.current) return;
    const delay = Math.min(15000, 800 * (2 ** Math.min(attemptRef.current, 4))) + Math.round(Math.random() * 400);
    attemptRef.current += 1;
    setStatus("connecting");
    retryRef.current = window.setTimeout(() => { retryRef.current = null; connect(); }, delay);
    // connect is declared below and is resolved when the reconnect timer fires.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const connect = useCallback(() => {
    if (stoppedRef.current) return;
    try { wsRef.current?.close(); } catch { /* noop */ }
    setStatus("connecting");
    const ws = new WebSocket(wsUrl(`/api/ws/device-terminal/${deviceId}?token=${encodeURIComponent(getToken() || "")}`));
    wsRef.current = ws;
    ws.onopen = () => {
      attemptRef.current = 0;
      if (keepaliveRef.current) clearInterval(keepaliveRef.current);
      keepaliveRef.current = window.setInterval(() => { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ type: "ping" })); }, 20000);
    };
    ws.onmessage = (event) => {
      let msg; try { msg = JSON.parse(event.data); } catch { return; }
      const term = termRef.current;
      if (msg.type === "connected") { setStatus("connected"); term?.write(`\x1b[36m● Secure shell to ${msg.data} established.\x1b[0m\r\n`); setTimeout(sendResize, 60); }
      else if (msg.type === "output" || msg.type === "shell_output") term?.write(msg.data || "");
      else if (msg.type === "offline") { setStatus("offline"); term?.write("\r\n\x1b[31m● Device went offline. Reconnecting…\x1b[0m\r\n"); onOffline?.(); scheduleReconnect(); }
      else if (msg.type === "exit" || msg.type === "shell_exit") { setStatus("closed"); term?.write("\r\n\x1b[33m● Shell exited. Reconnecting…\x1b[0m\r\n"); scheduleReconnect(); }
      else if (msg.type === "error") { setStatus("error"); term?.write(`\r\n\x1b[31m✖ ${msg.data || msg.message}\x1b[0m\r\n`); scheduleReconnect(); }
    };
    ws.onclose = () => { if (keepaliveRef.current) clearInterval(keepaliveRef.current); if (!stoppedRef.current) scheduleReconnect(); };
    ws.onerror = () => { setStatus("error"); scheduleReconnect(); };
  }, [deviceId, onOffline, scheduleReconnect, sendResize]);

  useEffect(() => {
    stoppedRef.current = false;
    const term = new XTerm({ fontFamily: "'JetBrains Mono', monospace", fontSize: 13, theme: THEME, cursorBlink: true, scrollback: 5000, convertEol: false });
    const fit = new FitAddon(); term.loadAddon(fit); term.open(containerRef.current);
    termRef.current = term; fitRef.current = fit;
    setTimeout(() => { try { fit.fit(); } catch { /* noop */ } }, 50);
    const input = term.onData((data) => { if (wsRef.current?.readyState === WebSocket.OPEN) wsRef.current.send(JSON.stringify({ type: "input", data })); });
    const ro = new ResizeObserver(sendResize); ro.observe(containerRef.current);
    connect();
    return () => { stoppedRef.current = true; if (retryRef.current) clearTimeout(retryRef.current); if (keepaliveRef.current) clearInterval(keepaliveRef.current); ro.disconnect(); input.dispose(); try { wsRef.current?.close(); } catch { /* noop */ } term.dispose(); };
  }, [connect, deviceId, sendResize]);

  const reconnect = () => { if (retryRef.current) { clearTimeout(retryRef.current); retryRef.current = null; } attemptRef.current = 0; termRef.current?.write("\r\n\x1b[36m● Reconnecting…\x1b[0m\r\n"); connect(); };
  const dot = status === "connected" ? "text-[#22C55E] fill-[#22C55E]" : status === "offline" || status === "error" ? "text-red-400 fill-red-400" : "text-amber-400 fill-amber-400";
  return <div className="h-full flex flex-col bg-[#050505]" data-testid="device-terminal"><div className="flex items-center gap-2 px-3 h-10 border-b border-white/8 shrink-0 bg-black/40"><div className="flex items-center gap-1 mr-1"><span className="w-3 h-3 rounded-full bg-[#FF3B30]" /><span className="w-3 h-3 rounded-full bg-[#FFCC00]" /><span className="w-3 h-3 rounded-full bg-[#22C55E]" /></div><TerminalSquare className="w-3.5 h-3.5 text-gold" /><span className="text-xs font-mono text-white/70 truncate">{deviceName}</span><span className="flex items-center gap-1 text-[11px] text-white/40 ml-1"><Circle className={`w-1.5 h-1.5 ${dot}`} /> {status}</span><button onClick={reconnect} title="Reconnect" data-testid="device-terminal-reconnect" className="ml-auto p-1.5 rounded-md text-white/40 hover:text-white hover:bg-white/10 transition-colors"><RotateCw className="w-3.5 h-3.5" /></button></div><div className="flex-1 relative overflow-hidden"><div ref={containerRef} className="absolute inset-0 p-1" /></div></div>;
}
