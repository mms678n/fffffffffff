import { Link } from "react-router-dom";
import { LOGO } from "../lib/api";

export function AuthShell({ title, subtitle, children }) {
  return (
    <div className="min-h-screen bg-[#0B0B0D] text-white flex items-center justify-center px-6 relative overflow-hidden">
      <div className="absolute inset-0 grid-bg opacity-40" />
      <div className="orb animate-orb w-[400px] h-[400px] bg-crimson -top-40 -left-20 opacity-30" />
      <div className="orb animate-orb w-[360px] h-[360px] bg-crimson2 bottom-0 right-0 opacity-20" style={{ animationDelay: "3s" }} />
      <div className="relative w-full max-w-md">
        <Link to="/" className="flex items-center gap-2.5 justify-center mb-8" data-testid="auth-logo">
          <img src={LOGO} alt="HackerGPT" className="w-11 h-11 rounded-xl crimson-glow" />
          <span className="font-display font-semibold text-xl tracking-tight">HackerGPT</span>
        </Link>
        <div className="glass-strong rounded-2xl p-8">
          <h1 className="font-display text-2xl font-medium tracking-tight mb-1">{title}</h1>
          <p className="text-white/45 text-sm mb-6">{subtitle}</p>
          {children}
        </div>
      </div>
    </div>
  );
}
