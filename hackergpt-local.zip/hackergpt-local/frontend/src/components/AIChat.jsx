import { useState, useRef, useEffect, useCallback } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import rehypeHighlight from "rehype-highlight";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";
import {
  Send, Bot, User, Copy, RefreshCw, Square, Play, Pencil,
  Sparkles, ChevronRight, Plus, MessageSquare, Trash2,
} from "lucide-react";
import { API, getToken } from "../lib/api";
import { api } from "../lib/api";
import { Button } from "./ui/button";

function CodeBlock({ inline, className, children, terminalRef }) {
  const code = String(children).replace(/\n$/, "");
  const lang = /language-(\w+)/.exec(className || "")?.[1];
  if (inline || !className) return <code className={className}>{children}</code>;
  const runnable = ["bash", "sh", "shell", "zsh", "console"].includes(lang);
  return (
    <div className="relative group my-2">
      <div className="flex items-center justify-between px-3 py-1.5 bg-white/5 border border-white/10 border-b-0 rounded-t-lg">
        <span className="text-[11px] uppercase tracking-wider text-white/40 font-mono">{lang || "code"}</span>
        <div className="flex gap-1">
          <button onClick={() => { navigator.clipboard.writeText(code); toast.success("Copied"); }} className="text-white/40 hover:text-white p-1" data-testid="code-copy"><Copy className="w-3 h-3" /></button>
          {runnable && terminalRef?.current && (
            <button onClick={() => { terminalRef.current.runCommand(code); toast.success("Sent to terminal"); }} className="flex items-center gap-1 text-accent-ai hover:text-white px-1.5 py-0.5 rounded text-[11px] font-medium" data-testid="code-run">
              <Play className="w-3 h-3" /> Run
            </button>
          )}
        </div>
      </div>
      <pre className="!rounded-t-none !mt-0"><code className={className}>{children}</code></pre>
    </div>
  );
}

const SUGGESTIONS = [
  "Check disk space usage",
  "Show memory and top processes",
  "Update all system packages",
  "Analyze recent auth logs",
];

export default function AIChat({ serverId, terminalRef }) {
  const [sessionId, setSessionId] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [streaming, setStreaming] = useState(false);
  const [sessions, setSessions] = useState([]);
  const [showSessions, setShowSessions] = useState(false);
  const abortRef = useRef(null);
  const scrollRef = useRef(null);
  const inputRef = useRef(null);

  const loadSessions = useCallback(() => { api.get("/ai/sessions").then((r) => setSessions(r.data)); }, []);
  useEffect(() => { loadSessions(); }, [loadSessions]);
  useEffect(() => { scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" }); }, [messages]);

  const loadSession = async (id) => {
    const { data } = await api.get(`/ai/sessions/${id}/messages`);
    setMessages(data.map((m) => ({ role: m.role, content: m.content })));
    setSessionId(id);
    setShowSessions(false);
  };

  const newChat = () => { setMessages([]); setSessionId(null); setShowSessions(false); };

  const deleteSession = async (id, e) => {
    e.stopPropagation();
    await api.delete(`/ai/sessions/${id}`);
    if (id === sessionId) newChat();
    loadSessions();
  };

  const runStream = async (text, currentMessages) => {
    setStreaming(true);
    const controller = new AbortController();
    abortRef.current = controller;
    const terminal_context = terminalRef?.current?.getBuffer?.() || null;
    setMessages([...currentMessages, { role: "assistant", content: "" }]);
    try {
      const res = await fetch(`${API}/ai/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${getToken()}` },
        body: JSON.stringify({ session_id: sessionId, server_id: serverId, message: text, terminal_context }),
        signal: controller.signal,
      });
      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let acc = "";
      let newSid = sessionId;
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const parts = buffer.split("\n\n");
        buffer = parts.pop();
        for (const part of parts) {
          const line = part.trim();
          if (!line.startsWith("data:")) continue;
          const evt = JSON.parse(line.slice(5).trim());
          if (evt.type === "session") { newSid = evt.session_id; setSessionId(evt.session_id); }
          else if (evt.type === "delta") { acc += evt.content; setMessages([...currentMessages, { role: "assistant", content: acc }]); }
          else if (evt.type === "error") { toast.error(evt.content); }
        }
      }
      if (!sessionId && newSid) loadSessions();
    } catch (err) {
      if (err.name !== "AbortError") toast.error("Stream error: " + err.message);
    } finally {
      setStreaming(false);
      abortRef.current = null;
    }
  };

  const send = (textArg) => {
    const text = (textArg ?? input).trim();
    if (!text || streaming) return;
    setInput("");
    const updated = [...messages, { role: "user", content: text }];
    setMessages(updated);
    runStream(text, updated);
  };

  const stop = () => { abortRef.current?.abort(); setStreaming(false); };

  const regenerate = () => {
    const lastUser = [...messages].reverse().find((m) => m.role === "user");
    if (!lastUser) return;
    const base = messages[messages.length - 1]?.role === "assistant" ? messages.slice(0, -1) : messages;
    setMessages(base);
    runStream(lastUser.content, base);
  };

  const continueGen = () => send("Please continue.");
  const editMessage = (content) => { setInput(content); inputRef.current?.focus(); };

  return (
    <div className="h-full flex flex-col bg-[#0A0A0B]">
      {/* Header */}
      <div className="flex items-center justify-between px-4 h-12 border-b border-white/8 shrink-0">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-md bg-accent-ai/10 flex items-center justify-center"><Sparkles className="w-3.5 h-3.5 text-accent-ai" /></div>
          <span className="font-display font-medium text-sm">HackerGPT AI</span>
        </div>
        <div className="flex items-center gap-1">
          <button onClick={() => setShowSessions(!showSessions)} className="p-1.5 rounded-md text-white/40 hover:text-white hover:bg-white/5" title="History" data-testid="chat-history-btn"><MessageSquare className="w-4 h-4" /></button>
          <button onClick={newChat} className="p-1.5 rounded-md text-white/40 hover:text-white hover:bg-white/5" title="New chat" data-testid="chat-new-btn"><Plus className="w-4 h-4" /></button>
        </div>
      </div>

      <div className="flex-1 flex min-h-0">
        {/* Sessions drawer */}
        <AnimatePresence>
          {showSessions && (
            <motion.div initial={{ width: 0, opacity: 0 }} animate={{ width: 200, opacity: 1 }} exit={{ width: 0, opacity: 0 }}
              className="border-r border-white/8 overflow-hidden shrink-0">
              <div className="w-[200px] p-2 space-y-1 overflow-y-auto h-full">
                {sessions.length === 0 && <p className="text-xs text-white/30 p-2">No saved chats</p>}
                {sessions.map((s) => (
                  <div key={s.id} onClick={() => loadSession(s.id)} className={`group flex items-center gap-2 px-2 py-2 rounded-lg cursor-pointer text-xs ${sessionId === s.id ? "bg-white/10" : "hover:bg-white/5 text-white/60"}`} data-testid={`session-${s.id}`}>
                    <MessageSquare className="w-3 h-3 shrink-0" /><span className="truncate flex-1">{s.title}</span>
                    <Trash2 onClick={(e) => deleteSession(s.id, e)} className="w-3 h-3 opacity-0 group-hover:opacity-100 hover:text-red-400" />
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Messages */}
        <div className="flex-1 flex flex-col min-w-0">
          <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-5">
            {messages.length === 0 && (
              <div className="h-full flex flex-col items-center justify-center text-center px-4">
                <div className="w-14 h-14 rounded-2xl bg-accent-ai/10 flex items-center justify-center mb-4 ai-glow"><Bot className="w-7 h-7 text-accent-ai" /></div>
                <h3 className="font-display text-xl font-medium">How can I help with your server?</h3>
                <p className="text-white/40 text-sm mt-1 mb-6">{serverId ? "I have full context of your connected server." : "Connect a server for tailored actions."}</p>
                <div className="grid grid-cols-2 gap-2 w-full max-w-md">
                  {SUGGESTIONS.map((s) => (
                    <button key={s} onClick={() => send(s)} className="text-left text-xs p-3 rounded-xl glass hover:border-accent-ai/30 transition-all flex items-center justify-between group" data-testid="chat-suggestion">
                      {s}<ChevronRight className="w-3 h-3 text-white/30 group-hover:text-accent-ai" />
                    </button>
                  ))}
                </div>
              </div>
            )}
            {messages.map((m, i) => (
              <div key={i} className={`flex gap-3 ${m.role === "user" ? "justify-end" : ""}`} data-testid={`chat-message-${m.role}`}>
                {m.role === "assistant" && <div className="w-7 h-7 rounded-lg bg-accent-ai/10 flex items-center justify-center shrink-0 mt-1"><Bot className="w-4 h-4 text-accent-ai" /></div>}
                <div className={`group max-w-[85%] ${m.role === "user" ? "" : "w-full"}`}>
                  {m.role === "user" ? (
                    <div className="rounded-2xl rounded-br-sm bg-white/10 px-4 py-2.5 text-sm">{m.content}
                      <button onClick={() => editMessage(m.content)} className="ml-2 opacity-0 group-hover:opacity-60 hover:opacity-100" data-testid="edit-message"><Pencil className="w-3 h-3 inline" /></button>
                    </div>
                  ) : (
                    <div className="rounded-2xl rounded-bl-sm border border-white/10 px-4 py-3 bg-white/[0.02]">
                      {m.content ? (
                        <div className="md-body">
                          <ReactMarkdown remarkPlugins={[remarkGfm]} rehypePlugins={[rehypeHighlight]}
                            components={{ code: (props) => <CodeBlock {...props} terminalRef={terminalRef} /> }}>
                            {m.content}
                          </ReactMarkdown>
                        </div>
                      ) : (
                        <div className="flex gap-1 py-1"><span className="w-1.5 h-1.5 rounded-full bg-accent-ai animate-bounce" style={{ animationDelay: "0ms" }} /><span className="w-1.5 h-1.5 rounded-full bg-accent-ai animate-bounce" style={{ animationDelay: "150ms" }} /><span className="w-1.5 h-1.5 rounded-full bg-accent-ai animate-bounce" style={{ animationDelay: "300ms" }} /></div>
                      )}
                      {m.content && i === messages.length - 1 && !streaming && (
                        <div className="flex items-center gap-2 mt-3 pt-3 border-t border-white/8">
                          <ActBtn onClick={() => { navigator.clipboard.writeText(m.content); toast.success("Copied"); }} icon={Copy} label="Copy" testid="msg-copy" />
                          <ActBtn onClick={regenerate} icon={RefreshCw} label="Regenerate" testid="msg-regenerate" />
                          <ActBtn onClick={continueGen} icon={ChevronRight} label="Continue" testid="msg-continue" />
                        </div>
                      )}
                    </div>
                  )}
                </div>
                {m.role === "user" && <div className="w-7 h-7 rounded-lg bg-white/10 flex items-center justify-center shrink-0 mt-1"><User className="w-4 h-4" /></div>}
              </div>
            ))}
          </div>

          {/* Input */}
          <div className="p-3 border-t border-white/8">
            <div className="flex items-end gap-2 rounded-2xl glass p-2 focus-within:border-accent-ai/40 transition-colors">
              <textarea ref={inputRef} value={input} onChange={(e) => setInput(e.target.value)} rows={1}
                onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }}
                placeholder="Ask HackerGPT to do something..." data-testid="chat-input"
                className="flex-1 bg-transparent resize-none outline-none text-sm px-2 py-1.5 max-h-32 placeholder:text-white/30" />
              {streaming ? (
                <Button onClick={stop} size="icon" className="rounded-xl bg-white/10 hover:bg-white/20 shrink-0" data-testid="chat-stop"><Square className="w-4 h-4" /></Button>
              ) : (
                <Button onClick={() => send()} disabled={!input.trim()} size="icon" className="rounded-xl btn-crimson shrink-0 disabled:opacity-40" data-testid="chat-send"><Send className="w-4 h-4" /></Button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function ActBtn({ onClick, icon: Icon, label, testid }) {
  return <button onClick={onClick} data-testid={testid} className="flex items-center gap-1 text-xs text-white/40 hover:text-white transition-colors"><Icon className="w-3 h-3" /> {label}</button>;
}
