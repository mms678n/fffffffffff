import { useState, useRef, useEffect, useCallback } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import rehypeHighlight from "rehype-highlight";
import { motion } from "framer-motion";
import { toast } from "sonner";
import {
  Send, Bot, User, Square, Terminal as TerminalIcon, ShieldAlert,
  CheckCircle2, XCircle, Loader2, Play, ShieldCheck, ChevronRight, Plus, MessageSquare, Trash2,
} from "lucide-react";
import { wsUrl, getToken, api } from "../lib/api";
import { Button } from "./ui/button";

const SUGGESTIONS = [
  "Show disk space usage",
  "List the top processes by CPU",
  "Check system uptime and load",
  "Show memory usage",
];

// A single assistant turn can carry a planned command, live output and analysis.
function newAssistantTurn() {
  return {
    role: "assistant", planText: "", command: null, explanation: "",
    needsConfirmation: false, execId: null, output: "", exitCode: null,
    duration: null, analysis: "", phase: "planning", online: true,
  };
}

export default function DeviceChat({ device }) {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [streaming, setStreaming] = useState(false);
  const [awaiting, setAwaiting] = useState(null); // execId awaiting confirmation
  const [sessionId, setSessionId] = useState(null);
  const [sessions, setSessions] = useState([]);
  const [showSessions, setShowSessions] = useState(false);
  const [wsReady, setWsReady] = useState(false);
  const wsRef = useRef(null);
  const scrollRef = useRef(null);
  const sessionRef = useRef(null);
  const online = device.status === "online";

  useEffect(() => { sessionRef.current = sessionId; }, [sessionId]);

  const loadSessions = useCallback(() => {
    api.get(`/devices/${device.id}/sessions`).then((r) => setSessions(r.data)).catch(() => {});
  }, [device.id]);
  useEffect(() => { loadSessions(); }, [loadSessions]);

  // Update the last assistant turn immutably.
  const patchLast = useCallback((patch) => {
    setMessages((prev) => {
      const next = [...prev];
      for (let i = next.length - 1; i >= 0; i--) {
        if (next[i].role === "assistant") {
          next[i] = typeof patch === "function" ? patch(next[i]) : { ...next[i], ...patch };
          break;
        }
      }
      return next;
    });
  }, []);

  const connectWs = useCallback(() => {
    const ws = new WebSocket(wsUrl(`/api/ws/exec/${device.id}?token=${getToken()}`));
    wsRef.current = ws;
    ws.onopen = () => setWsReady(true);
    ws.onclose = () => { setWsReady(false); setStreaming(false); setAwaiting(null); };
    ws.onerror = () => setWsReady(false);
    ws.onmessage = (e) => {
      let evt;
      try { evt = JSON.parse(e.data); } catch { return; }
      switch (evt.type) {
        case "ready": break;
        case "session": setSessionId(evt.session_id); loadSessions(); break;
        case "delta":
          patchLast((t) => t.phase === "analyzing"
            ? { ...t, analysis: t.analysis + evt.content }
            : { ...t, planText: t.planText + evt.content });
          break;
        case "command":
          patchLast({
            command: evt.command, explanation: evt.explanation,
            needsConfirmation: evt.needs_confirmation, execId: evt.exec_id,
            online: evt.online, phase: evt.needs_confirmation ? "awaiting" : "running",
          });
          if (evt.needs_confirmation) setAwaiting(evt.exec_id);
          break;
        case "output":
          patchLast((t) => ({ ...t, output: t.output + evt.data, phase: "running" }));
          break;
        case "exit":
          patchLast({ exitCode: evt.exit_code, duration: evt.duration, phase: "analyzing" });
          break;
        case "cancelled":
          patchLast({ phase: "cancelled" }); setAwaiting(null); break;
        case "error":
          toast.error(evt.message || "Error"); break;
        case "done":
          setStreaming(false); setAwaiting(null); break;
        default: break;
      }
    };
    return ws;
  }, [device.id, patchLast, loadSessions]);

  // (re)connect the socket when device changes.
  useEffect(() => {
    setMessages([]); setSessionId(null); setStreaming(false); setAwaiting(null);
    const ws = connectWs();
    return () => { try { ws.close(); } catch { /* noop */ } };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [device.id]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages]);

  const ensureWs = () => {
    if (wsRef.current && wsRef.current.readyState === 1) return wsRef.current;
    return connectWs();
  };

  const send = (textArg) => {
    const text = (textArg ?? input).trim();
    if (!text || streaming) return;
    if (!online) { toast.error("Device is offline. Start the HackerGPT Agent."); return; }
    const ws = ensureWs();
    setInput("");
    setMessages((prev) => [...prev, { role: "user", content: text }, newAssistantTurn()]);
    setStreaming(true);
    const payload = { type: "chat", message: text, session_id: sessionRef.current };
    const trySend = () => {
      if (ws.readyState === 1) ws.send(JSON.stringify(payload));
      else if (ws.readyState === 0) setTimeout(trySend, 120);
      else { toast.error("Connection lost"); setStreaming(false); }
    };
    trySend();
  };

  const respond = (approved) => {
    const ws = wsRef.current;
    if (ws && ws.readyState === 1 && awaiting) {
      ws.send(JSON.stringify({ type: "confirm", exec_id: awaiting, approved }));
    }
    if (approved) patchLast({ phase: "running" });
    setAwaiting(null);
  };

  const loadSession = async (id) => {
    const { data } = await api.get(`/devices/${device.id}/sessions/${id}/messages`);
    setMessages(data.map((m) => m.role === "user"
      ? { role: "user", content: m.content }
      : { ...newAssistantTurn(), planText: m.content, phase: "done", command: null }));
    setSessionId(id); setShowSessions(false);
  };
  const newChat = () => { setMessages([]); setSessionId(null); setShowSessions(false); };
  const deleteSession = async (id, e) => {
    e.stopPropagation();
    await api.delete(`/ai/sessions/${id}`);
    if (id === sessionId) newChat();
    loadSessions();
  };

  return (
    <div className="flex-1 flex min-h-0" data-testid="device-chat">
      {/* Sessions drawer */}
      {showSessions && (
        <div className="w-[200px] border-r border-white/8 p-2 space-y-1 overflow-y-auto shrink-0">
          {sessions.length === 0 && <p className="text-xs text-white/30 p-2">No saved chats</p>}
          {sessions.map((s) => (
            <div key={s.id} onClick={() => loadSession(s.id)} className={`group flex items-center gap-2 px-2 py-2 rounded-lg cursor-pointer text-xs ${sessionId === s.id ? "bg-white/10" : "hover:bg-white/5 text-white/60"}`} data-testid={`device-session-${s.id}`}>
              <MessageSquare className="w-3 h-3 shrink-0" /><span className="truncate flex-1">{s.title}</span>
              <Trash2 onClick={(e) => deleteSession(s.id, e)} className="w-3 h-3 opacity-0 group-hover:opacity-100 hover:text-red-400" />
            </div>
          ))}
        </div>
      )}

      <div className="flex-1 flex flex-col min-w-0">
        {/* sub-toolbar */}
        <div className="flex items-center justify-between px-4 h-9 border-b border-white/8 shrink-0">
          <span className="text-[11px] uppercase tracking-wider text-white/40 flex items-center gap-1.5">
            <TerminalIcon className="w-3 h-3 text-gold" /> Device execution
          </span>
          <div className="flex items-center gap-1">
            <button onClick={() => setShowSessions(!showSessions)} className="p-1 rounded text-white/40 hover:text-white hover:bg-white/5" title="History" data-testid="device-history-btn"><MessageSquare className="w-3.5 h-3.5" /></button>
            <button onClick={newChat} className="p-1 rounded text-white/40 hover:text-white hover:bg-white/5" title="New chat" data-testid="device-new-chat-btn"><Plus className="w-3.5 h-3.5" /></button>
          </div>
        </div>

        <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-5">
          {messages.length === 0 && (
            <div className="h-full flex flex-col items-center justify-center text-center px-4">
              <div className="w-14 h-14 rounded-2xl bg-gold/10 flex items-center justify-center mb-4"><TerminalIcon className="w-7 h-7 text-gold" /></div>
              <h3 className="font-display text-xl font-medium">Command {device.name} with AI</h3>
              <p className="text-white/40 text-sm mt-1 mb-6">
                {online ? "Ask in plain English — I'll run the right command on this device and explain the result."
                        : "This device is offline. Start the HackerGPT Agent to run commands."}
              </p>
              <div className="grid grid-cols-2 gap-2 w-full max-w-md">
                {SUGGESTIONS.map((s) => (
                  <button key={s} onClick={() => send(s)} disabled={!online} className="text-left text-xs p-3 rounded-xl glass hover:border-gold/30 transition-all flex items-center justify-between group disabled:opacity-40" data-testid="device-suggestion">
                    {s}<ChevronRight className="w-3 h-3 text-white/30 group-hover:text-gold" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {messages.map((m, i) => (
            <div key={i} className={`flex gap-3 ${m.role === "user" ? "justify-end" : ""}`} data-testid={`device-message-${m.role}`}>
              {m.role === "assistant" && <div className="w-7 h-7 rounded-lg bg-gold/10 flex items-center justify-center shrink-0 mt-1"><Bot className="w-4 h-4 text-gold" /></div>}
              <div className={`${m.role === "user" ? "max-w-[85%]" : "w-full"}`}>
                {m.role === "user" ? (
                  <div className="rounded-2xl rounded-br-sm bg-white/10 px-4 py-2.5 text-sm">{m.content}</div>
                ) : (
                  <AssistantTurn turn={m} isLast={i === messages.length - 1} awaiting={awaiting}
                    onConfirm={() => respond(true)} onCancel={() => respond(false)} />
                )}
              </div>
              {m.role === "user" && <div className="w-7 h-7 rounded-lg bg-white/10 flex items-center justify-center shrink-0 mt-1"><User className="w-4 h-4" /></div>}
            </div>
          ))}
        </div>

        {/* Input */}
        <div className="p-3 border-t border-white/8">
          <div className="flex items-end gap-2 rounded-2xl glass p-2 focus-within:border-gold/40 transition-colors">
            <textarea value={input} onChange={(e) => setInput(e.target.value)} rows={1}
              onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }}
              placeholder={online ? `Ask HackerGPT to run something on ${device.name}...` : "Device offline — start the Agent to run commands"}
              disabled={!online || !!awaiting} data-testid="device-chat-input"
              className="flex-1 bg-transparent resize-none outline-none text-sm px-2 py-1.5 max-h-32 placeholder:text-white/30 disabled:opacity-50" />
            {streaming && !awaiting ? (
              <Button size="icon" disabled className="rounded-xl bg-white/10 shrink-0"><Loader2 className="w-4 h-4 animate-spin" /></Button>
            ) : (
              <Button onClick={() => send()} disabled={!input.trim() || !online || !!awaiting} size="icon" className="rounded-xl btn-crimson shrink-0 disabled:opacity-40" data-testid="device-chat-send"><Send className="w-4 h-4" /></Button>
            )}
          </div>
          {!wsReady && online && <p className="text-[11px] text-white/30 mt-1.5 px-1">Connecting secure channel…</p>}
        </div>
      </div>
    </div>
  );
}

function AssistantTurn({ turn, isLast, awaiting, onConfirm, onCancel }) {
  const showConfirm = isLast && turn.phase === "awaiting" && awaiting === turn.execId;
  return (
    <div className="rounded-2xl rounded-bl-sm border border-white/10 px-4 py-3 bg-white/[0.02] space-y-3">
      {turn.planText ? (
        <div className="md-body"><ReactMarkdown remarkPlugins={[remarkGfm]} rehypePlugins={[rehypeHighlight]}>{turn.planText}</ReactMarkdown></div>
      ) : (!turn.command && turn.phase === "planning") ? (
        <Dots />
      ) : null}

      {turn.command && (
        <div className="rounded-xl border border-white/10 overflow-hidden" data-testid="command-card">
          <div className="flex items-center justify-between px-3 py-1.5 bg-white/5 border-b border-white/10">
            <span className="text-[11px] uppercase tracking-wider text-white/40 font-mono">command</span>
            {turn.needsConfirmation ? (
              <span className="flex items-center gap-1 text-[11px] text-amber-400" data-testid="badge-modifies"><ShieldAlert className="w-3 h-3" /> Modifies system</span>
            ) : (
              <span className="flex items-center gap-1 text-[11px] text-[#22C55E]"><ShieldCheck className="w-3 h-3" /> Read-only</span>
            )}
          </div>
          <pre className="!m-0 !rounded-none px-3 py-2 text-[13px]"><code className="language-bash">{turn.command}</code></pre>
          {turn.explanation && <div className="px-3 py-2 text-xs text-white/50 border-t border-white/10">{turn.explanation}</div>}
        </div>
      )}

      {showConfirm && (
        <motion.div initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }}
          className="rounded-xl border border-amber-500/30 bg-amber-500/5 p-3" data-testid="confirm-panel">
          <p className="text-xs text-amber-200/80 flex items-start gap-2 mb-3">
            <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5" />
            This command changes the device. It will run with the Agent's privileges. Review it, then confirm.
          </p>
          <div className="flex gap-2">
            <Button onClick={onConfirm} size="sm" className="rounded-lg bg-amber-500 hover:bg-amber-600 text-black font-medium" data-testid="confirm-run-btn"><Play className="w-3.5 h-3.5 mr-1" /> Run command</Button>
            <Button onClick={onCancel} size="sm" variant="outline" className="rounded-lg border-white/10 bg-white/5 hover:bg-white/10" data-testid="cancel-run-btn">Cancel</Button>
          </div>
        </motion.div>
      )}

      {turn.phase === "cancelled" && (
        <div className="flex items-center gap-1.5 text-xs text-white/40"><XCircle className="w-3.5 h-3.5" /> Cancelled — nothing was executed.</div>
      )}

      {(turn.output || turn.phase === "running" || turn.exitCode != null) && turn.phase !== "cancelled" && (
        <div className="rounded-xl border border-white/10 bg-[#050505] overflow-hidden" data-testid="command-output">
          <div className="flex items-center justify-between px-3 py-1.5 border-b border-white/10">
            <span className="text-[11px] uppercase tracking-wider text-white/40 font-mono flex items-center gap-1.5"><TerminalIcon className="w-3 h-3" /> output</span>
            {turn.exitCode != null ? (
              <span className={`flex items-center gap-1 text-[11px] font-mono ${turn.exitCode === 0 ? "text-[#22C55E]" : "text-red-400"}`} data-testid="exit-badge">
                {turn.exitCode === 0 ? <CheckCircle2 className="w-3 h-3" /> : <XCircle className="w-3 h-3" />}
                exit {turn.exitCode} · {turn.duration}s
              </span>
            ) : (
              <span className="flex items-center gap-1 text-[11px] text-gold"><Loader2 className="w-3 h-3 animate-spin" /> running</span>
            )}
          </div>
          <pre className="!m-0 !rounded-none px-3 py-2 text-[12px] max-h-72 overflow-auto whitespace-pre-wrap text-white/80 font-mono">{turn.output || " "}</pre>
        </div>
      )}

      {turn.phase === "analyzing" && !turn.analysis && <Dots />}
      {turn.analysis && (
        <div className="md-body pt-1 border-t border-white/8"><ReactMarkdown remarkPlugins={[remarkGfm]} rehypePlugins={[rehypeHighlight]}>{turn.analysis}</ReactMarkdown></div>
      )}
    </div>
  );
}

function Dots() {
  return (
    <div className="flex gap-1 py-1">
      <span className="w-1.5 h-1.5 rounded-full bg-gold animate-bounce" style={{ animationDelay: "0ms" }} />
      <span className="w-1.5 h-1.5 rounded-full bg-gold animate-bounce" style={{ animationDelay: "150ms" }} />
      <span className="w-1.5 h-1.5 rounded-full bg-gold animate-bounce" style={{ animationDelay: "300ms" }} />
    </div>
  );
}
