import { useEffect, useState, useCallback } from "react";
import { NavLink, Outlet, useNavigate } from "react-router-dom";
import {
  LayoutDashboard, Server, TerminalSquare, FolderTree, Activity,
  Boxes, ScrollText, Shield, LogOut, Terminal, ChevronDown, Circle, MonitorSmartphone, Download,
} from "lucide-react";
import { api, LOGO } from "../lib/api";
import { useAuth } from "../context/AuthContext";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
  DropdownMenuLabel, DropdownMenuSeparator,
} from "./ui/dropdown-menu";

const NAV = [
  { to: "/app", icon: LayoutDashboard, label: "Dashboard", end: true },
  { to: "/app/servers", icon: Server, label: "Servers" },
  { to: "/app/devices", icon: MonitorSmartphone, label: "Devices" },
  { to: "/app/agent-downloads", icon: Download, label: "Agent Downloads" },
  { to: "/app/workspace", icon: TerminalSquare, label: "Workspace" },
  { to: "/app/files", icon: FolderTree, label: "Files" },
  { to: "/app/monitor", icon: Activity, label: "Monitor" },
  { to: "/app/docker", icon: Boxes, label: "Docker" },
  { to: "/app/logs", icon: ScrollText, label: "Logs" },
];

export default function DashboardLayout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [servers, setServers] = useState([]);
  const [activeServerId, setActiveServerId] = useState(localStorage.getItem("rgpt_active_server") || null);

  const refreshServers = useCallback(async () => {
    const { data } = await api.get("/servers");
    setServers(data);
    if (data.length && !data.find((s) => s.id === localStorage.getItem("rgpt_active_server"))) {
      selectServer(data[0].id);
    }
    return data;
  }, []);

  const selectServer = (id) => {
    setActiveServerId(id);
    if (id) localStorage.setItem("rgpt_active_server", id);
  };

  useEffect(() => { refreshServers(); }, [refreshServers]);

  const activeServer = servers.find((s) => s.id === activeServerId) || null;

  return (
    <div className="min-h-screen bg-black text-white flex">
      {/* Sidebar */}
      <aside className="w-60 shrink-0 border-r border-white/8 bg-black flex flex-col fixed inset-y-0 z-40">
        <div className="h-16 flex items-center px-5 border-b border-white/8">
          <div className="w-8 h-8 rounded-lg bg-white flex items-center justify-center mr-2"><Terminal className="w-5 h-5 text-black" /></div>
          <span className="font-display font-semibold tracking-tight">HackerGPT</span>
        </div>
        <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
          {NAV.map((n) => (
            <NavLink key={n.to} to={n.to} end={n.end} data-testid={`nav-${n.label.toLowerCase()}`}
              className={({ isActive }) => `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-all ${isActive ? "bg-white/8 text-white border border-white/10" : "text-white/50 hover:text-white hover:bg-white/5 border border-transparent"}`}>
              <n.icon className="w-[18px] h-[18px]" /> {n.label}
            </NavLink>
          ))}
          {user?.role === "admin" && (
            <NavLink to="/app/admin" data-testid="nav-admin"
              className={({ isActive }) => `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-all ${isActive ? "bg-accent-ai/10 text-accent-ai border border-accent-ai/20" : "text-accent-ai/70 hover:text-accent-ai hover:bg-accent-ai/5 border border-transparent"}`}>
              <Shield className="w-[18px] h-[18px]" /> Admin Panel
            </NavLink>
          )}
        </nav>
        <div className="p-3 border-t border-white/8">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-white/5 transition-colors" data-testid="user-menu">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-accent-ai to-indigo-500 flex items-center justify-center text-black text-sm font-semibold">{user?.username?.[0]?.toUpperCase()}</div>
                <div className="flex-1 text-left"><div className="text-sm font-medium truncate">{user?.username}</div><div className="text-xs text-white/40">{user?.plan}</div></div>
                <ChevronDown className="w-4 h-4 text-white/40" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-52 bg-[#0A0A0B] border-white/10">
              <DropdownMenuLabel className="text-white/40 text-xs">Signed in as {user?.username}</DropdownMenuLabel>
              <DropdownMenuSeparator className="bg-white/10" />
              <DropdownMenuItem onClick={() => { logout(); navigate("/login"); }} className="text-red-400 focus:text-red-400 focus:bg-red-500/10" data-testid="logout-btn">
                <LogOut className="w-4 h-4 mr-2" /> Log out
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 ml-60 flex flex-col min-w-0">
        <header className="h-16 border-b border-white/8 glass-strong sticky top-0 z-30 flex items-center justify-between px-6">
          <ServerSelector servers={servers} activeServer={activeServer} onSelect={selectServer} />
          <div className="text-xs text-white/40 font-mono hidden sm:block">
            {servers.length} server{servers.length !== 1 ? "s" : ""} · {servers.filter((s) => s.status === "online").length} online
          </div>
        </header>
        <main className="flex-1 min-w-0">
          <Outlet context={{ servers, activeServer, selectServer, refreshServers, setServers }} />
        </main>
      </div>
    </div>
  );
}

function ServerSelector({ servers, activeServer, onSelect }) {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button className="flex items-center gap-3 px-3 py-2 rounded-xl glass hover:border-white/20 transition-all" data-testid="active-server-selector">
          {activeServer ? (
            <>
              <Circle className={`w-2.5 h-2.5 ${activeServer.status === "online" ? "fill-[#22C55E] text-[#22C55E] pulse-dot" : "fill-white/30 text-white/30"}`} />
              <span className="text-sm font-medium">{activeServer.nickname}</span>
              <span className="text-xs text-white/40 font-mono hidden md:inline">{activeServer.host}</span>
            </>
          ) : (
            <span className="text-sm text-white/50">No server selected</span>
          )}
          <ChevronDown className="w-4 h-4 text-white/40" />
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="start" className="w-64 bg-[#0A0A0B] border-white/10">
        <DropdownMenuLabel className="text-white/40 text-xs">Active server</DropdownMenuLabel>
        <DropdownMenuSeparator className="bg-white/10" />
        {servers.length === 0 && <div className="px-2 py-3 text-sm text-white/40">No servers yet</div>}
        {servers.map((s) => (
          <DropdownMenuItem key={s.id} onClick={() => onSelect(s.id)} className="focus:bg-white/10" data-testid={`select-server-${s.id}`}>
            <Circle className={`w-2 h-2 mr-2 ${s.status === "online" ? "fill-[#22C55E] text-[#22C55E]" : "fill-white/30 text-white/30"}`} />
            <span className="flex-1">{s.nickname}</span>
            <span className="text-xs text-white/40 font-mono">{s.host}</span>
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
