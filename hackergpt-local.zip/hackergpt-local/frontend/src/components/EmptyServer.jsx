import { Server, Plug } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "./ui/button";

export function EmptyServer({ feature }) {
  return (
    <div className="p-6 md:p-8 max-w-7xl mx-auto">
      <div className="glass rounded-2xl p-16 text-center">
        <Server className="w-10 h-10 text-white/20 mx-auto mb-4" />
        <h3 className="font-display text-xl">No active server</h3>
        <p className="text-white/40 text-sm mt-1 mb-6">Connect a server to use the {feature}.</p>
        <Link to="/app/servers"><Button className="rounded-full btn-crimson"><Plug className="w-4 h-4 mr-1" /> Go to servers</Button></Link>
      </div>
    </div>
  );
}
