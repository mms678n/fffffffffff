import { createContext, useContext, useEffect, useState } from "react";
import { api } from "../lib/api";

const AuthContext = createContext(null);
const LOCAL_MODE = process.env.REACT_APP_LOCAL_MODE === "true";
const LOCAL_USER = { id: "000000000000000000000001", username: "local-admin", role: "admin", plan: "Local" };

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (LOCAL_MODE) {
      localStorage.setItem("rgpt_token", "local-mode");
      setUser(LOCAL_USER);
      setLoading(false);
      return;
    }
    const token = localStorage.getItem("rgpt_token");
    if (!token) {
      setLoading(false);
      return;
    }
    api
      .get("/auth/me")
      .then((res) => setUser(res.data))
      .catch(() => localStorage.removeItem("rgpt_token"))
      .finally(() => setLoading(false));
  }, []);

  const login = (token, userData) => {
    localStorage.setItem("rgpt_token", token);
    setUser(userData);
  };

  const logout = () => {
    localStorage.removeItem("rgpt_token");
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, setUser, loading, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
