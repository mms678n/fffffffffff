import { useCallback, useEffect, useRef, useState } from "react";
import { getToken, wsUrl } from "../lib/api";

export function useDeviceRealtime() {
  const [devices, setDevices] = useState([]);
  const [connectionStatus, setConnectionStatus] = useState("connecting");
  const wsRef = useRef(null);
  const retryRef = useRef(null);
  const timerRef = useRef(null);
  const stoppedRef = useRef(false);

  const connect = useCallback(() => {
    if (stoppedRef.current) return;
    const token = getToken();
    if (!token) { setConnectionStatus("error"); return; }
    setConnectionStatus("connecting");
    const ws = new WebSocket(wsUrl(`/api/ws/devices?token=${encodeURIComponent(token)}`));
    wsRef.current = ws;
    ws.onopen = () => {
      setConnectionStatus("online");
      if (retryRef.current) { clearTimeout(retryRef.current); retryRef.current = null; }
      timerRef.current = window.setInterval(() => {
        if (ws.readyState === WebSocket.OPEN) ws.send("ping");
      }, 20000);
    };
    ws.onmessage = (event) => {
      try {
        const msg = JSON.parse(event.data);
        if (msg.type === "snapshot" && Array.isArray(msg.devices)) setDevices(msg.devices);
      } catch { /* ignore malformed frames */ }
    };
    ws.onerror = () => setConnectionStatus("error");
    ws.onclose = () => {
      if (timerRef.current) { clearInterval(timerRef.current); timerRef.current = null; }
      if (stoppedRef.current) return;
      setConnectionStatus("connecting");
      const delay = Math.min(15000, 1000 * (2 ** Math.min(4, (ws.retryCount || 0))));
      ws.retryCount = (ws.retryCount || 0) + 1;
      retryRef.current = window.setTimeout(connect, delay);
    };
  }, []);

  useEffect(() => {
    stoppedRef.current = false;
    connect();
    return () => {
      stoppedRef.current = true;
      if (retryRef.current) clearTimeout(retryRef.current);
      if (timerRef.current) clearInterval(timerRef.current);
      try { wsRef.current?.close(); } catch { /* noop */ }
    };
  }, [connect]);

  const refresh = useCallback(() => {
    if (wsRef.current?.readyState === WebSocket.OPEN) wsRef.current.send("refresh");
  }, []);

  return { devices, connectionStatus, refresh };
}
