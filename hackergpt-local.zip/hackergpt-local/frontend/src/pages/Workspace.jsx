import { useRef, useState } from "react";
import { useOutletContext, Link } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import {
  Server, Laptop, Monitor, Cpu, Database, Cloud, Smartphone, HardDrive,
  Circle, ChevronDown, Terminal as TerminalIcon, MonitorX, MousePointerClick,
} from "lucide-react";
import { ResizablePanelGroup, ResizablePanel, ResizableHandle } from "../components/ui/resizable";
import Terminal from "../components/Terminal";
import AIChat from "../components/AIChat";
import DeviceTerminal from "../components/DeviceTerminal";
import DeviceChat from "../components/DeviceChat";
import { useDeviceRealtime } from "../hooks/useDeviceRealtime";

const DEVICE_ICONS = { server: Server, laptop: Laptop, monitor: Monitor, cpu: Cpu, database: Database, cloud: Cloud, smartphone: Smartphone, "hard-drive": HardDrive };

export default function Workspace() {
  const { activeServer } = useOutletContext();
  const terminalRef = useRef(null);
  const [fullscreen, setFullscreen] = useState(false);
  const { devices } = useDeviceRealtime();
  const [selectedId, setSelectedId] = useState(null);
  const [pickerOpen, setPickerOpen] = useState(false);
  const serverId = activeServer?.id;

  const device = devices.find((d) => d.id === selectedId) || null;
  const online = device?.status === "online";

  return (
    <div className="h-[calc(100vh-4rem)] flex flex-col p-3 gap-3">
      {/* Top bar: device selector */}
      <div className="flex items-center gap-3 shrink-0">
        <span className="text-xs uppercase tracking-[0.15em] text-white/30 hidden sm:block">Target device</span>
        <DeviceSelector devices={devices} selected={device} onSelect={(id) => { setSelectedId(id); setPickerOpen(false); }}
          open={pickerOpen} setOpen={setPickerOpen} />
        {device && (
          <span className={`flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-full ${online ? "bg-[#22C55E]/10 text-[#22C55E]" : "bg-red-500/10 text-red-400"}`} data-testid="workspace-device-status">
            <Circle className={`w-2 h-2 ${online ? "fill-[#22C55E] text-[#22C55E] pulse-dot" : "fill-red-400 text-red-400"}`} />
            {online ? "Online" : "Offline"}
          </span>
        )}
      </div>

      {/* Body */}
      <div className="flex-1 min-h-0">
        {device ? (
          online ? (
            fullscreen ? (
              <div className="fixed inset-0 z-50 bg-[#050505]">
                <DeviceTerminal deviceId={device.id} deviceName={device.name} onOffline={() => {}} />
              </div>
            ) : (
              <ResizablePanelGroup direction="horizontal" className="h-full rounded-2xl overflow-hidden border border-white/10" data-testid="device-console">
                <ResizablePanel defaultSize={55} minSize={30}>
                  <DeviceTerminal key={device.id} deviceId={device.id} deviceName={device.name} onOffline={() => {}} />
                </ResizablePanel>
                <ResizableHandle className="w-px bg-white/10 hover:bg-accent-ai/50 transition-colors" />
                <ResizablePanel defaultSize={45} minSize={28}>
                  <div className="h-full flex flex-col bg-[#0A0A0B]">
                    <DeviceChat key={device.id} device={device} />
                  </div>
                </ResizablePanel>
              </ResizablePanelGroup>
            )
          ) : (
            <div className="h-full flex items-center justify-center rounded-2xl border border-white/10">
              <div className="text-center glass rounded-2xl p-12 max-w-md" data-testid="device-offline-state">
                <MonitorX className="w-12 h-12 text-red-400/60 mx-auto mb-4" />
                <h3 className="font-display text-2xl">Device Offline</h3>
                <p className="text-white/40 text-sm mt-2">{device.name} is not connected. Start the HackerGPT Agent on the device to open a terminal and run commands.</p>
                <Link to={`/app/devices/${device.id}`} className="inline-block mt-5 text-xs text-gold hover:underline">Manage device →</Link>
              </div>
            </div>
          )
        ) : serverId ? (
          fullscreen ? (
            <div className="fixed inset-0 z-50 bg-[#050505]">
              <Terminal ref={terminalRef} serverId={serverId} fullscreen onToggleFullscreen={() => setFullscreen(false)} />
            </div>
          ) : (
            <ResizablePanelGroup direction="horizontal" className="h-full rounded-2xl overflow-hidden border border-white/10">
              <ResizablePanel defaultSize={55} minSize={30}>
                <Terminal ref={terminalRef} serverId={serverId} fullscreen={false} onToggleFullscreen={() => setFullscreen(true)} />
              </ResizablePanel>
              <ResizableHandle className="w-px bg-white/10 hover:bg-accent-ai/50 transition-colors" />
              <ResizablePanel defaultSize={45} minSize={28}>
                <AIChat serverId={serverId} terminalRef={terminalRef} />
              </ResizablePanel>
            </ResizablePanelGroup>
          )
        ) : (
          <div className="h-full flex items-center justify-center rounded-2xl border border-white/10">
            <div className="text-center glass rounded-2xl p-12 max-w-md" data-testid="no-device-selected">
              <MousePointerClick className="w-12 h-12 text-white/20 mx-auto mb-4" />
              <h3 className="font-display text-2xl">Please select a connected device</h3>
              <p className="text-white/40 text-sm mt-2">Choose a device above to open a live terminal and let HackerGPT run and explain commands on it.</p>
              <Link to="/app/devices" className="inline-block mt-5 text-xs text-gold hover:underline">Go to devices →</Link>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function DeviceSelector({ devices, selected, onSelect, open, setOpen }) {
  const SelIcon = selected ? (DEVICE_ICONS[selected.icon] || Server) : TerminalIcon;
  return (
    <div className="relative">
      <button onClick={() => setOpen(!open)} data-testid="workspace-device-selector"
        className="flex items-center gap-2 px-3 h-9 rounded-xl text-sm bg-white/5 border border-white/10 hover:border-white/20 transition-colors min-w-[220px]">
        <SelIcon className={`w-4 h-4 shrink-0 ${selected ? "text-gold" : "text-white/40"}`} />
        <span className="truncate flex-1 text-left">{selected ? selected.name : "No Device Selected"}</span>
        {selected && <Circle className={`w-1.5 h-1.5 shrink-0 ${selected.status === "online" ? "fill-[#22C55E] text-[#22C55E]" : "fill-white/30 text-white/30"}`} />}
        <ChevronDown className="w-4 h-4 text-white/40 shrink-0" />
      </button>
      <AnimatePresence>
        {open && (
          <>
            <div className="fixed inset-0 z-40" onClick={() => setOpen(false)} />
            <motion.div initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -4 }}
              className="absolute left-0 top-11 z-50 w-72 rounded-xl border border-white/10 bg-[#16181D] shadow-2xl p-1.5 max-h-96 overflow-y-auto" data-testid="workspace-device-menu">
              <button onClick={() => onSelect(null)} data-testid="workspace-device-none"
                className={`w-full flex items-center gap-2 px-2.5 py-2 rounded-lg text-left text-sm ${!selected ? "bg-white/10" : "hover:bg-white/5"}`}>
                <TerminalIcon className="w-4 h-4 text-white/40 shrink-0" /><span className="flex-1">No Device Selected</span>
              </button>
              <div className="px-2.5 pt-2 pb-1 text-[10px] uppercase tracking-wider text-white/30">Linked devices</div>
              {devices.length === 0 && <p className="px-2.5 py-2 text-xs text-white/30">No devices linked yet.</p>}
              {devices.map((d) => {
                const I = DEVICE_ICONS[d.icon] || Server;
                return (
                  <button key={d.id} onClick={() => onSelect(d.id)} data-testid={`workspace-device-${d.id}`}
                    className={`w-full flex items-center gap-2 px-2.5 py-2 rounded-lg text-left text-sm ${selected?.id === d.id ? "bg-white/10" : "hover:bg-white/5"}`}>
                    <I className="w-4 h-4 text-gold shrink-0" />
                    <span className="flex-1 truncate">{d.name}</span>
                    <span className={`flex items-center gap-1 text-[10px] ${d.status === "online" ? "text-[#22C55E]" : "text-white/40"}`}>
                      <Circle className={`w-1.5 h-1.5 ${d.status === "online" ? "fill-[#22C55E] text-[#22C55E]" : "fill-white/30 text-white/30"}`} />
                      {d.status === "online" ? "Online" : "Offline"}
                    </span>
                  </button>
                );
              })}
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
