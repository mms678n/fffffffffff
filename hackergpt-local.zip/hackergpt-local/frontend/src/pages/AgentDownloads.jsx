import { useEffect, useState } from "react";
import { Download, Monitor, Terminal, Laptop, ShieldCheck, Loader2 } from "lucide-react";
import { api } from "../lib/api";
import { Button } from "../components/ui/button";

const PLATFORMS = [
  { key: "windows", label: "Windows", detail: "Native .exe installer · Windows 10/11", icon: Monitor, file: "HackerGPT-Agent-Setup.exe" },
  { key: "linux", label: "Linux", detail: "Portable binary · Debian · Ubuntu · Fedora", icon: Terminal, file: "HackerGPT-Agent" },
  { key: "macos", label: "macOS", detail: "Intel and Apple Silicon · DMG", icon: Laptop, file: "HackerGPT-Agent.dmg" },
];

export default function AgentDownloads() {
  const [version, setVersion] = useState("—");
  useEffect(() => { api.get("/agent/info").then(({ data }) => setVersion(data.version || "—")).catch(() => {}); }, []);
  return (
    <div className="p-6 md:p-8 max-w-6xl mx-auto">
      <div className="max-w-2xl">
        <div className="flex items-center gap-2 text-gold text-xs uppercase tracking-[0.18em]"><ShieldCheck className="w-4 h-4" /> Secure device link</div>
        <h1 className="font-display text-3xl md:text-4xl font-light tracking-tight mt-3">Download the Agent</h1>
        <p className="text-white/45 mt-2">Install HackerGPT Agent on your own machine to make it available in Workspace, Terminal, Device Manager and Monitoring.</p>
      </div>
      <div className="grid md:grid-cols-3 gap-4 mt-8">
        {PLATFORMS.map(({ key, label, detail, icon: Icon, file }) => (
          <div key={key} className="glass rounded-2xl p-6 flex flex-col" data-testid={`agent-download-${key}`}>
            <div className="w-12 h-12 rounded-2xl bg-gold/10 border border-gold/20 flex items-center justify-center"><Icon className="w-6 h-6 text-gold" /></div>
            <h2 className="font-display text-xl mt-5">{label}</h2>
            <p className="text-sm text-white/40 mt-1 min-h-10">{detail}</p>
            <a className="mt-6" href={`/api/agent/download/${key}`} target="_blank" rel="noreferrer">
              <Button className="w-full rounded-xl btn-crimson"><Download className="w-4 h-4 mr-2" /> Download {label}</Button>
            </a>
            <div className="mt-4 text-xs text-white/30 font-mono">{file}</div>
          </div>
        ))}
      </div>
      <div className="glass rounded-2xl p-6 mt-6">
        <div className="flex flex-wrap items-center justify-between gap-3"><div><h2 className="font-display text-lg">Release notes</h2><p className="text-sm text-white/45 mt-1">Current Agent release and platform support.</p></div><span className="text-xs font-mono text-gold border border-gold/20 bg-gold/5 rounded-full px-3 py-1">v{version}</span></div>
        <ul className="mt-5 grid md:grid-cols-2 gap-2 text-sm text-white/60"><li>• Secure WSS connection with heartbeat and automatic reconnect.</li><li>• Live CPU, RAM, disk, network and uptime metrics.</li><li>• Native terminal sessions with resize support.</li><li>• Windows installer uses PyInstaller windowed mode and official UAC.</li></ul>
      </div>
    </div>
  );
}
