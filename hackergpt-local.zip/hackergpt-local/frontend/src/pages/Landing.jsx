import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import {
  Terminal, Bot, Server, Activity, ShieldCheck, Boxes, FolderTree,
  ArrowRight, Check, Menu, X, Github, Zap, Cpu, ChevronDown,
} from "lucide-react";
import { Button } from "../components/ui/button";
import {
  Accordion, AccordionContent, AccordionItem, AccordionTrigger,
} from "../components/ui/accordion";
import { LOGO } from "../lib/api";

const HERO_BG = "https://images.unsplash.com/photo-1683064325134-3acfdef9c6d7?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjA1OTN8MHwxfHNlYXJjaHw0fHxhYnN0cmFjdCUyMGRhcmslMjBtb2Rlcm4lMjB0ZWNobm9sb2d5JTIwYmFja2dyb3VuZCUyMGxpbmVzfGVufDB8fHx8MTc4Mzg1NTMxMXww&ixlib=rb-4.1.0&q=85";
const IMG_SERVERS = "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjAzNzl8MHwxfHNlYXJjaHwxfHxzZXJ2ZXIlMjByYWNrJTIwZGFyayUyMGJsdWUlMjBkYXRhY2VudGVyfGVufDB8fHx8MTc4Mzg1NTMxMXww&ixlib=rb-4.1.0&q=85";
const IMG_TERMINAL = "https://images.unsplash.com/photo-1518773553398-650c184e0bb3?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NDk1Nzl8MHwxfHNlYXJjaHwxfHxkYXJrJTIwbW9kZSUyMGRhc2hib2FyZCUyMGNvZGluZyUyMHRlcm1pbmFsfGVufDB8fHx8MTc4Mzg1NTMyMXww&ixlib=rb-4.1.0&q=85";
const IMG_MONITOR = "https://images.unsplash.com/photo-1518770660439-4636190af475?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NTY2NzF8MHwxfHNlYXJjaHwxfHxzZXJ2ZXIlMjBtb3RoZXJib2FyZCUyMHRlY2hub2xvZ3l8ZW58MHx8fHwxNzgzODU1MzIxfDA&ixlib=rb-4.1.0&q=85";
const TESTI = [
  { url: "https://images.unsplash.com/photo-1560250097-0b93528c311a?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NDQ2NDJ8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBtYWxlJTIwcG9ydHJhaXQlMjBwcm9mZXNzaW9uYWx8ZW58MHx8fHwxNzgzODU1MzExfDA&ixlib=rb-4.1.0&q=85", name: "Alex Mercer", role: "DevOps Lead, Northwind", text: "HackerGPT replaced three internal tools. I just tell it what I need and watch it execute across our fleet. The audit trail alone sold my security team." },
  { url: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NDk1ODF8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBmZW1hbGUlMjBwb3J0cmFpdHxlbnwwfHx8fDE3ODM4NTUzMTF8MA&ixlib=rb-4.1.0&q=85", name: "Sarah Chen", role: "CTO, Lumen Labs", text: "Onboarding junior engineers used to take weeks. Now they operate production safely because the assistant explains every command before it runs." },
  { url: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NDQ2NDJ8MHwxfHNlYXJjaHwyfHxwcm9mZXNzaW9uYWwlMjBtYWxlJTIwcG9ydHJhaXQlMjBwcm9mZXNzaW9uYWx8ZW58MHx8fHwxNzgzODU1MzExfDA&ixlib=rb-4.1.0&q=85", name: "Marcus Johnson", role: "SysAdmin, Vertex", text: "The split-screen terminal + assistant is the most natural way I've ever managed Linux. Live streaming output and instant analysis. Incredible." },
];

const FEATURES = [
  { icon: Bot, title: "Natural Language Ops", desc: "Just type what you want. HackerGPT translates intent into safe, explained shell commands." },
  { icon: Terminal, title: "Real SSH Terminal", desc: "Full interactive PTY with ANSI colors, live streaming, tabs and history." },
  { icon: Activity, title: "Live System Monitor", desc: "Real-time CPU, RAM, disk, network and process charts with auto-refresh." },
  { icon: Boxes, title: "Docker Control", desc: "Manage containers, images, volumes and networks. Start, stop, inspect logs." },
  { icon: FolderTree, title: "File Manager", desc: "Browse, edit, upload, download and organize files over SFTP." },
  { icon: ShieldCheck, title: "Zero-Trust Security", desc: "Encrypted credentials, per-user isolation, full audit logs, secure sessions." },
];

function Navbar() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  return (
    <header className={`fixed top-0 inset-x-0 z-50 transition-all duration-300 ${scrolled ? "glass-strong" : "bg-transparent"}`} data-testid="landing-navbar">
      <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2.5" data-testid="logo-home">
          <img src={LOGO} alt="HackerGPT" className="w-9 h-9 rounded-xl crimson-glow" />
          <span className="font-display font-semibold text-lg tracking-tight">HackerGPT</span>
        </Link>
        <nav className="hidden md:flex items-center gap-8 text-sm text-white/60">
          <a href="#features" className="hover:text-white transition-colors">Features</a>
          <a href="#preview" className="hover:text-white transition-colors">Preview</a>
          <a href="#pricing" className="hover:text-white transition-colors">Pricing</a>
          <a href="#faq" className="hover:text-white transition-colors">FAQ</a>
        </nav>
        <div className="hidden md:flex items-center gap-3">
          <Link to="/login"><Button variant="ghost" className="rounded-full text-white/80 hover:text-white hover:bg-white/5" data-testid="nav-login-btn">Log in</Button></Link>
          <Link to="/register"><Button className="rounded-full btn-crimson font-medium" data-testid="nav-signup-btn">Get Started <ArrowRight className="w-4 h-4 ml-1" /></Button></Link>
        </div>
        <button className="md:hidden text-white" onClick={() => setOpen(!open)} data-testid="mobile-menu-toggle">{open ? <X /> : <Menu />}</button>
      </div>
      {open && (
        <div className="md:hidden glass-strong border-t border-white/10 px-6 py-4 flex flex-col gap-4">
          <a href="#features" onClick={() => setOpen(false)} className="text-white/70">Features</a>
          <a href="#pricing" onClick={() => setOpen(false)} className="text-white/70">Pricing</a>
          <a href="#faq" onClick={() => setOpen(false)} className="text-white/70">FAQ</a>
          <Link to="/login"><Button variant="outline" className="w-full rounded-full">Log in</Button></Link>
          <Link to="/register"><Button className="w-full rounded-full btn-crimson">Get Started</Button></Link>
        </div>
      )}
    </header>
  );
}

export default function Landing() {
  return (
    <div className="min-h-screen bg-[#0B0B0D] text-white overflow-x-hidden">
      <Navbar />

      {/* HERO */}
      <section className="relative pt-40 pb-28 px-6">
        <div className="absolute inset-0 grid-bg opacity-60" />
        <img src={HERO_BG} alt="" className="absolute inset-0 w-full h-full object-cover opacity-20" />
        <div className="absolute inset-0 bg-gradient-to-b from-[#0B0B0D]/40 via-[#0B0B0D]/60 to-[#0B0B0D]" />
        <div className="orb animate-orb w-[420px] h-[420px] bg-crimson -top-20 -left-20 opacity-40" />
        <div className="orb animate-orb w-[360px] h-[360px] bg-crimson2 top-40 right-0 opacity-30" style={{ animationDelay: "3s" }} />

        <div className="relative max-w-5xl mx-auto text-center">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full glass text-xs text-white/70 mb-8">
            <span className="w-2 h-2 rounded-full bg-[#22C55E] pulse-dot" /> Powered by HackerGPT Local · Real SSH engine
          </motion.div>
          <motion.h1 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, delay: 0.1 }}
            className="font-display text-5xl md:text-7xl font-light tracking-tighter leading-[1.05]">
            Manage your servers<br /> by simply <span className="gradient-text font-semibold">talking</span> to them.
          </motion.h1>
          <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, delay: 0.2 }}
            className="mt-6 text-lg text-white/55 max-w-2xl mx-auto">
            HackerGPT is a local system that administers your real machines over SSH. Describe the task in plain language — it plans, explains, and executes.
          </motion.p>
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, delay: 0.3 }}
            className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link to="/register"><Button size="lg" className="rounded-full btn-crimson font-medium px-8 h-12" data-testid="hero-cta-btn">Start free <ArrowRight className="w-4 h-4 ml-2" /></Button></Link>
            <a href="#preview"><Button size="lg" variant="outline" className="rounded-full border-white/15 bg-white/5 hover:bg-white/10 px-8 h-12">See it live</Button></a>
          </motion.div>
        </div>

        {/* Floating preview */}
        <motion.div initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.4 }}
          className="relative max-w-5xl mx-auto mt-20">
          <div className="glass-strong rounded-2xl overflow-hidden shadow-[0_40px_120px_rgba(139,0,0,0.18)]">
            <div className="flex items-center gap-2 px-4 h-10 border-b border-white/10">
              <span className="w-3 h-3 rounded-full bg-[#EF4444]" /><span className="w-3 h-3 rounded-full bg-[#F59E0B]" /><span className="w-3 h-3 rounded-full bg-[#22C55E]" />
              <span className="ml-3 text-xs text-white/40 font-mono">hackergpt — workspace</span>
            </div>
            <div className="grid md:grid-cols-2">
              <div className="bg-[#050505] p-5 font-mono text-[13px] leading-relaxed min-h-[280px]">
                <p className="text-white/40">demo@prod-01:~$ <span className="text-white">df -h</span></p>
                <p className="text-[#22C55E]">Filesystem      Size  Used Avail Use%</p>
                <p className="text-white/80">/dev/root        95G   17G   79G  18%</p>
                <p className="text-white/40 mt-2">demo@prod-01:~$ <span className="text-white">systemctl restart nginx</span></p>
                <p className="text-[#22C55E]">● nginx.service — active (running)</p>
                <p className="text-white/40 mt-2">demo@prod-01:~$ <span className="cursor-blink">▋</span></p>
              </div>
              <div className="bg-[#0A0A0B] p-5 border-l border-white/10 min-h-[280px]">
                <div className="flex items-center gap-2 mb-4 text-xs text-white/40"><Bot className="w-4 h-4 text-accent-ai" /> HackerGPT</div>
                <div className="rounded-xl rounded-br-none bg-white/10 p-3 text-sm mb-3 ml-8">Restart nginx and confirm it's healthy.</div>
                <div className="rounded-xl rounded-bl-none border border-white/10 p-3 text-sm text-white/80">
                  I'll restart the service and verify status. Running <code className="text-accent-ai">systemctl restart nginx</code> — it's now <span className="text-[#22C55E]">active (running)</span>. Uptime reset, no errors in the log. ✓
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </section>

      {/* LOGOS / STATS */}
      <section className="py-14 border-y border-white/5">
        <div className="max-w-6xl mx-auto px-6 grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          {[["99.99%", "Uptime SLA"], ["<50ms", "Command latency"], ["256-bit", "Credential encryption"], ["∞", "Servers per account"]].map(([n, l], i) => (
            <motion.div key={i} initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }}>
              <div className="font-display text-3xl md:text-4xl font-semibold tracking-tight">{n}</div>
              <div className="text-xs uppercase tracking-[0.2em] text-white/40 mt-2">{l}</div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* FEATURES */}
      <section id="features" className="py-28 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="max-w-2xl mb-14">
            <div className="text-xs uppercase tracking-[0.2em] text-accent-ai mb-4">Capabilities</div>
            <h2 className="font-display text-3xl md:text-5xl font-light tracking-tight">Everything an elite operator needs, in one command center.</h2>
          </div>
          <div className="grid md:grid-cols-3 gap-4">
            {FEATURES.map((f, i) => (
              <motion.div key={i} initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }}
                className="glass rounded-2xl p-7 hover:-translate-y-1 hover:border-white/20 transition-all duration-300 group">
                <div className="w-11 h-11 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center mb-5 group-hover:ai-glow transition-all">
                  <f.icon className="w-5 h-5 text-accent-ai" />
                </div>
                <h3 className="font-display text-lg font-medium mb-2">{f.title}</h3>
                <p className="text-sm text-white/50 leading-relaxed">{f.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* PREVIEW / SCREENSHOTS BENTO */}
      <section id="preview" className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-3 gap-4 auto-rows-[260px]">
            <motion.div initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }}
              className="md:col-span-2 md:row-span-2 relative rounded-2xl overflow-hidden glass group">
              <img src={IMG_TERMINAL} alt="operations terminal" className="absolute inset-0 w-full h-full object-cover opacity-40 group-hover:opacity-50 transition-opacity" />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent" />
              <div className="absolute bottom-0 p-8">
                <div className="flex items-center gap-2 text-accent-ai text-xs uppercase tracking-[0.2em] mb-3"><Zap className="w-4 h-4" /> Operations Workspace</div>
                <h3 className="font-display text-2xl md:text-3xl font-medium">Split-screen terminal & assistant</h3>
                <p className="text-white/50 mt-2 max-w-md text-sm">Stream real command output on the left while the assistant plans and explains on the right.</p>
              </div>
            </motion.div>
            <motion.div initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }} className="relative rounded-2xl overflow-hidden glass group">
              <img src={IMG_SERVERS} alt="Servers" className="absolute inset-0 w-full h-full object-cover opacity-45" />
              <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent" />
              <div className="absolute bottom-0 p-6"><Server className="w-5 h-5 text-accent-ai mb-2" /><h3 className="font-display text-lg font-medium">Unlimited servers</h3></div>
            </motion.div>
            <motion.div initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }} className="relative rounded-2xl overflow-hidden glass group">
              <img src={IMG_MONITOR} alt="Monitor" className="absolute inset-0 w-full h-full object-cover opacity-45" />
              <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent" />
              <div className="absolute bottom-0 p-6"><Cpu className="w-5 h-5 text-accent-ai mb-2" /><h3 className="font-display text-lg font-medium">Live monitoring</h3></div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* PRICING */}
      <section id="pricing" className="py-28 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center max-w-2xl mx-auto mb-14">
            <div className="text-xs uppercase tracking-[0.2em] text-accent-ai mb-4">Pricing</div>
            <h2 className="font-display text-3xl md:text-5xl font-light tracking-tight">Simple plans that scale with your fleet.</h2>
          </div>
          <div className="grid md:grid-cols-3 gap-5 items-start">
            {[
              { name: "Free", price: "$0", period: "/mo", features: ["Up to 2 servers", "Assistant (standard)", "Terminal & file manager", "7-day audit logs"], cta: "Start free", highlight: false },
              { name: "Pro", price: "$19", period: "/mo", features: ["Unlimited servers", "Assistant (priority)", "System monitor & Docker", "90-day audit logs", "Multiple terminal tabs"], cta: "Go Pro", highlight: true },
              { name: "Enterprise", price: "Custom", period: "", features: ["Everything in Pro", "SSO & team roles", "Unlimited audit retention", "Dedicated support", "On-prem deployment"], cta: "Contact sales", highlight: false },
            ].map((p, i) => (
              <motion.div key={i} initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }}
                className={`rounded-2xl p-8 relative ${p.highlight ? "glass-strong ai-glow border-accent-ai/30" : "glass"}`} data-testid={`pricing-${p.name.toLowerCase()}`}>
                {p.highlight && <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full bg-accent-ai text-black text-xs font-medium">Most popular</div>}
                <div className="text-sm text-white/60 mb-3">{p.name}</div>
                <div className="flex items-end gap-1 mb-6"><span className="font-display text-4xl font-semibold">{p.price}</span><span className="text-white/40 mb-1">{p.period}</span></div>
                <ul className="space-y-3 mb-8">
                  {p.features.map((f, j) => (
                    <li key={j} className="flex items-center gap-3 text-sm text-white/70"><Check className="w-4 h-4 text-accent-ai shrink-0" /> {f}</li>
                  ))}
                </ul>
                <Link to="/register"><Button className={`w-full rounded-full ${p.highlight ? "btn-crimson" : "bg-white/5 hover:bg-white/10 border border-white/10"}`}>{p.cta}</Button></Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="py-24 px-6 border-y border-white/5">
        <div className="max-w-6xl mx-auto">
          <h2 className="font-display text-3xl md:text-4xl font-light tracking-tight text-center mb-14">Trusted by operators who ship.</h2>
          <div className="grid md:grid-cols-3 gap-5">
            {TESTI.map((t, i) => (
              <motion.div key={i} initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.06 }}
                className="glass rounded-2xl p-7">
                <p className="text-white/70 text-sm leading-relaxed mb-6">"{t.text}"</p>
                <div className="flex items-center gap-3">
                  <img src={t.url} alt={t.name} className="w-10 h-10 rounded-full object-cover" />
                  <div><div className="text-sm font-medium">{t.name}</div><div className="text-xs text-white/40">{t.role}</div></div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="py-28 px-6">
        <div className="max-w-3xl mx-auto">
          <h2 className="font-display text-3xl md:text-5xl font-light tracking-tight text-center mb-12">Questions, answered.</h2>
          <Accordion type="single" collapsible className="space-y-3">
            {[
              ["Does HackerGPT actually connect to my servers?", "Yes. It opens real SSH sessions to the machines you add. Credentials are encrypted at rest and never exposed in responses."],
              ["Is it safe to let the assistant run commands?", "Sensitive or destructive operations require your explicit confirmation. Every command and automation decision is written to an immutable audit log."],
              ["What provider powers it?", "HackerGPT is powered by a purpose-built local automation engine, tuned with a specialized system-administration prompt and full context of your connected server."],
              ["Do I need to install an agent?", "No agent required. Standard SSH access (password or key) is all you need."],
              ["Can I use SSH keys?", "Absolutely. Add a private key per server, or use password auth. Keys are encrypted with AES."],
            ].map(([q, a], i) => (
              <AccordionItem key={i} value={`item-${i}`} className="glass rounded-xl px-5 border-white/10">
                <AccordionTrigger className="text-left hover:no-underline text-sm md:text-base">{q}</AccordionTrigger>
                <AccordionContent className="text-white/55 text-sm">{a}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 px-6">
        <div className="max-w-4xl mx-auto glass-strong rounded-3xl p-12 md:p-16 text-center relative overflow-hidden">
          <div className="orb animate-orb w-[300px] h-[300px] bg-accent-ai top-0 left-1/4 opacity-20" />
          <h2 className="font-display text-3xl md:text-5xl font-light tracking-tight relative">Ready to command your fleet?</h2>
          <p className="text-white/55 mt-4 relative">Set up your first server in under a minute. No credit card required.</p>
          <Link to="/register" className="inline-block mt-8 relative"><Button size="lg" className="rounded-full btn-crimson px-8 h-12 font-medium" data-testid="cta-bottom-btn">Get started free <ArrowRight className="w-4 h-4 ml-2" /></Button></Link>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="border-t border-white/5 py-12 px-6">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between gap-8">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <img src={LOGO} alt="HackerGPT" className="w-7 h-7 rounded-lg" />
              <span className="font-display font-semibold">HackerGPT</span>
            </div>
            <p className="text-white/40 text-sm max-w-xs">Private remote server management for modern teams.</p>
          </div>
          <div className="flex gap-16 text-sm">
            <div className="space-y-3"><div className="text-white/40 text-xs uppercase tracking-widest">Product</div><a href="#features" className="block text-white/60 hover:text-white">Features</a><a href="#pricing" className="block text-white/60 hover:text-white">Pricing</a></div>
            <div className="space-y-3"><div className="text-white/40 text-xs uppercase tracking-widest">Account</div><Link to="/login" className="block text-white/60 hover:text-white">Log in</Link><Link to="/register" className="block text-white/60 hover:text-white">Sign up</Link></div>
          </div>
        </div>
        <div className="max-w-6xl mx-auto mt-10 pt-6 border-t border-white/5 flex items-center justify-between text-xs text-white/30">
          <span>© 2026 HackerGPT. All rights reserved.</span>
          <Github className="w-4 h-4" />
        </div>
      </footer>
    </div>
  );
}
