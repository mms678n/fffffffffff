import { useEffect, useRef, useState, useCallback } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { toast } from "sonner";
import {
  AreaChart, Area, ResponsiveContainer, YAxis, Tooltip, RadialBarChart, RadialBar,
} from "recharts";
import {
  ArrowLeft, Server, Laptop, Monitor, Cpu, Database, Cloud, Smartphone, HardDrive,
  Circle, RefreshCw, RotateCw, Power, KeyRound, Trash2, Pencil, Check, X,
  MemoryStick, Network, Thermometer, Clock, Activity, Package, ShieldCheck, Copy, Loader2,
} from "lucide-react";
import { api, formatApiError, wsUrl, getToken } from "../lib/api";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from "../components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "../components/ui/alert-dialog";

const ICONS = { server: Server, laptop: Laptop, monitor: Monitor, cpu: Cpu, database: Database, cloud: Cloud, smartphone: Smartphone, "hard-drive": HardDrive };
const ICON_KEYS = Object.keys(ICONS);

export default function ManageDevice() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [device, setDevice] = useState(null);
  const [status, setStatus] = useState("offline");
  const [info, setInfo] = useState(null);
  const [metrics, setMetrics] = useState(null);
  const [history, setHistory] = useState([]);
  const [netRate, setNetRate] = useState({ rx: 0, tx: 0 });
  const lastNet = useRef(null);
  const [editingName, setEditingName] = useState(false);
  const [nameVal, setNameVal] = useState("");
  const [iconOpen, setIconOpen] = useState(false);
  const [rotateResult, setRotateResult] = useState(null);
  const [confirmRemove, setConfirmRemove] = useState(false);
  const [busy, setBusy] = useState(null);

  const loadDevice = useCallback(async () => {
    try {
      const { data } = await api.get(`/devices/${id}`);
      setDevice(data); setNameVal(data.name);
      setStatus(data.status); if (data.info) setInfo(data.info); if (data.metrics) setMetrics(data.metrics);
    } catch (err) { toast.error("Device not found"); navigate("/app/devices"); }
  }, [id, navigate]);

  useEffect(() => { loadDevice(); }, [loadDevice]);

  // Live WebSocket monitor
  useEffect(() => {
    if (!id) return;
    let ws; let closed = false; let retry; let attempt = 0; let keepalive;
    const connect = () => {
      if (closed) return;
      setStatus("connecting");
      ws = new WebSocket(wsUrl(`/api/ws/monitor/${id}?token=${getToken()}`));
      ws.onopen = () => {
        attempt = 0;
        keepalive = setInterval(() => { if (ws.readyState === WebSocket.OPEN) ws.send("ping"); }, 20000);
      };
      ws.onmessage = (e) => {
        const msg = JSON.parse(e.data);
        if (msg.type === "snapshot") { setStatus(msg.status); if (msg.info) setInfo(msg.info); if (msg.metrics) applyMetrics(msg.metrics); }
        else if (msg.type === "status") setStatus(msg.status);
        else if (msg.type === "info") setInfo(msg.data);
        else if (msg.type === "metrics") applyMetrics(msg.data);
      };
      ws.onerror = () => setStatus("error");
      ws.onclose = () => {
        clearInterval(keepalive);
        if (!closed) { setStatus("connecting"); const delay = Math.min(15000, 1000 * (2 ** Math.min(attempt, 4))); attempt += 1; retry = setTimeout(connect, delay); }
      };
    };
    const applyMetrics = (m) => {
      setMetrics(m);
      setHistory((h) => [...h.slice(-29), { cpu: m.cpu ?? 0, ram: m.ram?.pct ?? 0 }]);
      if (lastNet.current) {
        const dt = 5;
        setNetRate({
          rx: Math.max(0, (m.net.rx - lastNet.current.rx) / dt / 1024),
          tx: Math.max(0, (m.net.tx - lastNet.current.tx) / dt / 1024),
        });
      }
      lastNet.current = m.net;
    };
    connect();
    return () => { closed = true; clearTimeout(retry); clearInterval(keepalive); if (ws) ws.close(); };
  }, [id]);

  if (!device) return <div className="p-8"><Loader2 className="w-6 h-6 animate-spin text-white/40" /></div>;

  const online = status === "online";
  const Icon = ICONS[device.icon] || Server;

  const saveName = async () => {
    try { await api.put(`/devices/${id}/rename`, { name: nameVal.trim() }); setEditingName(false); loadDevice(); toast.success("Renamed"); }
    catch (err) { toast.error(formatApiError(err.response?.data?.detail)); }
  };
  const setIcon = async (key) => {
    try { await api.put(`/devices/${id}/icon`, { icon: key }); setIconOpen(false); loadDevice(); }
    catch (err) { toast.error(formatApiError(err.response?.data?.detail)); }
  };
  const command = async (action) => {
    setBusy(action);
    try { await api.post(`/devices/${id}/command/${action}`); toast.success(`${action} sent to agent`); }
    catch (err) { toast.error(formatApiError(err.response?.data?.detail)); }
    finally { setBusy(null); }
  };
  const rotate = async () => {
    setBusy("rotate");
    try { const { data } = await api.post(`/devices/${id}/rotate`); setRotateResult(data); }
    catch (err) { toast.error(formatApiError(err.response?.data?.detail)); }
    finally { setBusy(null); }
  };
  const remove = async () => {
    try { await api.delete(`/devices/${id}`); toast.success("Device removed"); navigate("/app/devices"); }
    catch (err) { toast.error(formatApiError(err.response?.data?.detail)); }
  };

  return (
    <div className="p-6 md:p-8 max-w-7xl mx-auto">
      <button onClick={() => navigate("/app/devices")} className="text-sm text-white/40 flex items-center gap-1 mb-5 hover:text-white" data-testid="back-to-devices"><ArrowLeft className="w-4 h-4" /> All devices</button>

      {/* Header */}
      <div className="glass rounded-2xl p-6 flex flex-wrap items-center gap-4">
        <button onClick={() => setIconOpen(true)} className="w-14 h-14 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center hover:border-gold/40 transition-colors group" data-testid="change-icon-btn">
          <Icon className="w-7 h-7 text-gold" />
        </button>
        <div className="flex-1 min-w-[200px]">
          {editingName ? (
            <div className="flex items-center gap-2">
              <Input value={nameVal} onChange={(e) => setNameVal(e.target.value)} onKeyDown={(e) => e.key === "Enter" && saveName()} autoFocus className="h-9 bg-white/5 border-white/10 rounded-lg max-w-xs" data-testid="rename-input" />
              <button onClick={saveName} className="p-2 rounded-lg bg-gold/10 text-gold" data-testid="rename-save"><Check className="w-4 h-4" /></button>
              <button onClick={() => { setEditingName(false); setNameVal(device.name); }} className="p-2 rounded-lg hover:bg-white/10 text-white/50"><X className="w-4 h-4" /></button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <h1 className="font-display text-2xl md:text-3xl font-light tracking-tight">{device.name}</h1>
              <button onClick={() => setEditingName(true)} className="p-1.5 rounded-lg hover:bg-white/10 text-white/40 hover:text-white" data-testid="edit-name-btn"><Pencil className="w-4 h-4" /></button>
            </div>
          )}
          <div className="flex items-center gap-3 mt-1 text-xs text-white/40 font-mono flex-wrap">
            <span className={`flex items-center gap-1.5 px-2 py-0.5 rounded-full ${online ? "bg-[#22C55E]/10 text-[#22C55E]" : "bg-white/5 text-white/40"}`}><Circle className={`w-2 h-2 ${online ? "fill-[#22C55E] text-[#22C55E] pulse-dot" : "fill-white/30 text-white/30"}`} /> {online ? "Online" : "Offline"}</span>
            <span>{device.device_id}</span>
            <span>Agent v{device.agent_version || "?"}</span>
            {info && <span>{info.os} {info.os_version}</span>}
            {device.last_seen && <span>Last online {new Date(device.last_seen).toLocaleString()}</span>}
          </div>
        </div>
      </div>

      {/* Action buttons */}
      <div className="flex gap-2 mt-4 flex-wrap">
        <Button onClick={() => command("refresh")} disabled={!online || busy} variant="outline" className="rounded-xl border-white/10 bg-white/5 hover:bg-white/10" data-testid="refresh-btn">{busy === "refresh" ? <Loader2 className="w-4 h-4 mr-1 animate-spin" /> : <RefreshCw className="w-4 h-4 mr-1" />} Refresh</Button>
        <Button onClick={() => command("restart")} disabled={!online || busy} variant="outline" className="rounded-xl border-white/10 bg-white/5 hover:bg-white/10" data-testid="restart-agent-btn">{busy === "restart" ? <Loader2 className="w-4 h-4 mr-1 animate-spin" /> : <Power className="w-4 h-4 mr-1" />} Restart Agent</Button>
        <Button onClick={() => command("reconnect")} disabled={!online || busy} variant="outline" className="rounded-xl border-white/10 bg-white/5 hover:bg-white/10" data-testid="reconnect-btn">{busy === "reconnect" ? <Loader2 className="w-4 h-4 mr-1 animate-spin" /> : <RotateCw className="w-4 h-4 mr-1" />} Reconnect</Button>
        <Button onClick={rotate} disabled={busy} variant="outline" className="rounded-xl border-white/10 bg-white/5 hover:bg-white/10" data-testid="rotate-secret-btn">{busy === "rotate" ? <Loader2 className="w-4 h-4 mr-1 animate-spin" /> : <KeyRound className="w-4 h-4 mr-1" />} Rotate Secret</Button>
        <Button onClick={() => setConfirmRemove(true)} variant="outline" className="rounded-xl border-white/10 bg-white/5 hover:bg-red-500/10 hover:text-red-400 ml-auto" data-testid="remove-device-btn"><Trash2 className="w-4 h-4 mr-1" /> Remove</Button>
      </div>

      {!online && <div className="mt-4 text-sm text-white/40 glass rounded-xl p-4">This device is offline. Live metrics and agent controls resume when the Agent reconnects.</div>}

      {/* Live metric cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mt-4">
        <Metric icon={Cpu} label="CPU" value={`${metrics?.cpu ?? 0}%`} color="#D4AF37" />
        <Metric icon={MemoryStick} label="RAM" value={`${metrics?.ram?.pct ?? 0}%`} sub={`${metrics?.ram?.used ?? 0}/${metrics?.ram?.total ?? 0} GB`} color="#22C55E" />
        <Metric icon={Network} label="Network" value={`${netRate.rx.toFixed(0)} KB/s`} sub={`▲ ${netRate.tx.toFixed(0)} KB/s`} color="#B22222" />
        <Metric icon={Thermometer} label="Temp" value={metrics?.temp != null ? `${metrics.temp}°C` : "N/A"} sub={metrics?.uptime ? `up ${metrics.uptime}` : ""} color="#F59E0B" />
      </div>

      <div className="grid lg:grid-cols-3 gap-4 mt-4">
        <Chart title="CPU" color="#D4AF37" data={history} dataKey="cpu" />
        <Chart title="Memory" color="#22C55E" data={history} dataKey="ram" />
        <div className="glass rounded-2xl p-6 flex flex-col items-center">
          <span className="text-xs uppercase tracking-[0.15em] text-white/40 self-start mb-2">Disk Usage</span>
          <ResponsiveContainer width="100%" height={160}>
            <RadialBarChart innerRadius="70%" outerRadius="100%" data={[{ value: metrics?.disk?.pct ?? 0, fill: "#B22222" }]} startAngle={90} endAngle={-270}>
              <RadialBar background={{ fill: "rgba(255,255,255,0.05)" }} dataKey="value" cornerRadius={20} />
            </RadialBarChart>
          </ResponsiveContainer>
          <div className="font-mono text-2xl font-semibold -mt-24">{metrics?.disk?.pct ?? 0}%</div>
          <div className="text-xs text-white/40 mt-16 font-mono">{metrics?.disk?.used ?? 0}/{metrics?.disk?.total ?? 0} GB</div>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-4 mt-4">
        {/* Processes */}
        <div className="glass rounded-2xl p-6">
          <div className="flex items-center gap-2 mb-4"><Activity className="w-4 h-4 text-gold" /><span className="text-xs uppercase tracking-[0.15em] text-white/40">Running Processes</span></div>
          <div className="grid grid-cols-12 text-xs text-white/30 uppercase px-2 pb-2"><span className="col-span-2">PID</span><span className="col-span-6">Name</span><span className="col-span-2 text-right">CPU</span><span className="col-span-2 text-right">MEM</span></div>
          <div className="max-h-64 overflow-y-auto">
            {(metrics?.processes || []).map((p, i) => (
              <div key={i} className="grid grid-cols-12 text-sm font-mono px-2 py-1.5 rounded-lg hover:bg-white/5" data-testid={`process-${p.pid}`}>
                <span className="col-span-2 text-white/40">{p.pid}</span><span className="col-span-6 truncate">{p.name}</span>
                <span className="col-span-2 text-right text-gold">{p.cpu}%</span><span className="col-span-2 text-right text-white/60">{p.mem}%</span>
              </div>
            ))}
            {!metrics?.processes?.length && <div className="text-sm text-white/30 py-6 text-center">No live process data</div>}
          </div>
        </div>

        {/* Full system info */}
        <div className="glass rounded-2xl p-6">
          <div className="flex items-center gap-2 mb-4"><Server className="w-4 h-4 text-gold" /><span className="text-xs uppercase tracking-[0.15em] text-white/40">System Information</span></div>
          {info ? (
            <div className="grid grid-cols-2 gap-x-6 gap-y-2 text-sm">
              <Row label="Hostname" value={info.hostname} /><Row label="OS" value={`${info.os} ${info.os_version}`} />
              <Row label="OS Detail" value={info.os_full} /><Row label="Arch" value={info.arch} />
              <Row label="CPU" value={info.cpu} /><Row label="Cores" value={info.cpu_cores} />
              <Row label="RAM" value={`${info.ram_total_gb} GB`} /><Row label="Disk" value={`${info.disk_used_gb}/${info.disk_total_gb} GB`} />
              <Row label="Internal IP" value={info.internal_ip} /><Row label="Public IP" value={info.public_ip} />
              <Row label="User" value={info.current_user} /><Row label="Agent" value={`v${info.agent_version}`} />
            </div>
          ) : <div className="text-sm text-white/30 py-6 text-center">Waiting for agent…</div>}
        </div>
      </div>

      {/* Installed software */}
      <div className="glass rounded-2xl p-6 mt-4">
        <div className="flex items-center gap-2 mb-4"><Package className="w-4 h-4 text-gold" /><span className="text-xs uppercase tracking-[0.15em] text-white/40">Installed Software {info?.software ? `(${info.software.length})` : ""}</span></div>
        {info?.software?.length ? (
          <div className="grid grid-cols-2 md:grid-cols-3 gap-x-6 gap-y-1 max-h-72 overflow-y-auto text-sm font-mono text-white/70">
            {info.software.map((s, i) => <div key={i} className="truncate" data-testid="software-item">{s}</div>)}
          </div>
        ) : <div className="text-sm text-white/30 py-4">No software list reported yet.</div>}
      </div>

      {/* Icon picker */}
      <Dialog open={iconOpen} onOpenChange={setIconOpen}>
        <DialogContent className="bg-[#16181D] border-white/10 max-w-sm">
          <DialogHeader><DialogTitle>Choose device icon</DialogTitle></DialogHeader>
          <div className="grid grid-cols-4 gap-3">
            {ICON_KEYS.map((key) => {
              const I = ICONS[key];
              return (
                <button key={key} onClick={() => setIcon(key)} data-testid={`icon-${key}`}
                  className={`aspect-square rounded-xl flex items-center justify-center border transition-all ${device.icon === key ? "border-gold/50 bg-gold/10" : "border-white/10 bg-white/5 hover:border-white/25"}`}>
                  <I className="w-6 h-6 text-gold" />
                </button>
              );
            })}
          </div>
        </DialogContent>
      </Dialog>

      {/* Rotate result */}
      <Dialog open={!!rotateResult} onOpenChange={() => setRotateResult(null)}>
        <DialogContent className="bg-[#16181D] border-white/10 max-w-md">
          <DialogHeader><DialogTitle className="flex items-center gap-2"><KeyRound className="w-5 h-5 text-gold" /> New Device Secret</DialogTitle></DialogHeader>
          <p className="text-sm text-white/50">{rotateResult?.delivered_to_agent ? "Delivered securely to the connected Agent — it is already using the new secret." : "The Agent is offline. Enter this new secret in the Agent settings to reconnect."}</p>
          <div className="flex items-start gap-2 p-3 rounded-xl bg-black/50 border border-white/10">
            <code className="text-xs text-gold flex-1 break-all font-mono">{rotateResult?.secret}</code>
            <button onClick={() => { navigator.clipboard.writeText(rotateResult.secret); toast.success("Copied"); }} className="text-white/40 hover:text-white shrink-0"><Copy className="w-3.5 h-3.5" /></button>
          </div>
          <Button onClick={() => setRotateResult(null)} className="w-full rounded-xl btn-crimson mt-2">Done</Button>
        </DialogContent>
      </Dialog>

      <AlertDialog open={confirmRemove} onOpenChange={setConfirmRemove}>
        <AlertDialogContent className="bg-[#16181D] border-white/10">
          <AlertDialogHeader><AlertDialogTitle>Remove device?</AlertDialogTitle><AlertDialogDescription className="text-white/50">The device will be unlinked and its Agent disconnected.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-white/5 border-white/10 hover:bg-white/10">Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={remove} className="bg-red-500 hover:bg-red-600 text-white" data-testid="confirm-remove-device">Remove</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function Metric({ icon: Icon, label, value, sub, color }) {
  return (
    <div className="glass rounded-2xl p-5">
      <div className="flex items-center justify-between mb-3"><span className="text-xs uppercase tracking-[0.15em] text-white/40">{label}</span><Icon className="w-4 h-4" style={{ color }} /></div>
      <div className="font-mono text-3xl font-semibold">{value}</div>
      {sub && <div className="text-xs text-white/40 mt-1 font-mono">{sub}</div>}
    </div>
  );
}

function Chart({ title, color, data, dataKey }) {
  return (
    <div className="glass rounded-2xl p-6">
      <div className="flex items-center justify-between mb-4"><span className="text-xs uppercase tracking-[0.15em] text-white/40">{title}</span><span className="font-mono text-sm" style={{ color }}>{data[data.length - 1]?.[dataKey] ?? 0}%</span></div>
      <ResponsiveContainer width="100%" height={160}>
        <AreaChart data={data}>
          <defs><linearGradient id={`mg-${dataKey}`} x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor={color} stopOpacity={0.4} /><stop offset="100%" stopColor={color} stopOpacity={0} /></linearGradient></defs>
          <YAxis domain={[0, 100]} hide />
          <Tooltip contentStyle={{ background: "#16181D", border: "1px solid #2A2D34", borderRadius: 12, fontSize: 12 }} labelFormatter={() => ""} />
          <Area type="monotone" dataKey={dataKey} stroke={color} strokeWidth={2} fill={`url(#mg-${dataKey})`} isAnimationActive={false} dot={false} />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

function Row({ label, value }) {
  return (<><span className="text-white/40 text-xs">{label}</span><span className="font-mono text-xs text-white/80 truncate text-right">{value}</span></>);
}
