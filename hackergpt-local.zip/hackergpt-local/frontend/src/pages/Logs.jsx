import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import {
  ScrollText, Zap, Server, Terminal, MessageSquare, FolderTree,
  Boxes, Plug, Filter,
} from "lucide-react";
import { api } from "../lib/api";

const CATS = [
  { key: "", label: "All" },
  { key: "auth", label: "Auth" },
  { key: "connection", label: "Connections" },
  { key: "command", label: "Commands" },
  { key: "ai", label: "AI" },
  { key: "file", label: "Files" },
  { key: "docker", label: "Docker" },
  { key: "server", label: "Servers" },
];
const ICON = { auth: Zap, server: Server, connection: Plug, command: Terminal, ai: MessageSquare, file: FolderTree, docker: Boxes };
const COLOR = { auth: "#D4AF37", connection: "#22C55E", command: "#FFCC00", ai: "#BF5AF2", file: "#5AC8FA", docker: "#D4AF37", server: "#fff" };

export default function Logs() {
  const [logs, setLogs] = useState([]);
  const [cat, setCat] = useState("");

  useEffect(() => { api.get("/logs", { params: cat ? { category: cat } : {} }).then((r) => setLogs(r.data)); }, [cat]);

  return (
    <div className="p-6 md:p-8 max-w-7xl mx-auto">
      <div>
        <h1 className="font-display text-3xl md:text-4xl font-light tracking-tight">Audit Logs</h1>
        <p className="text-white/45 mt-1">Every action, connection, command and automation decision — recorded.</p>
      </div>

      <div className="flex items-center gap-2 mt-6 flex-wrap">
        <Filter className="w-4 h-4 text-white/40" />
        {CATS.map((c) => (
          <button key={c.key} onClick={() => setCat(c.key)} data-testid={`log-filter-${c.key || "all"}`}
            className={`px-3 py-1.5 rounded-full text-xs transition-colors ${cat === c.key ? "bg-white text-black" : "glass text-white/60 hover:text-white"}`}>{c.label}</button>
        ))}
      </div>

      <div className="glass rounded-2xl mt-6 overflow-hidden">
        {logs.length === 0 ? (
          <div className="p-12 text-center text-white/30"><ScrollText className="w-8 h-8 mx-auto mb-3" />No log entries</div>
        ) : (
          <div className="divide-y divide-white/5">
            {logs.map((l, i) => {
              const Icon = ICON[l.category] || Zap;
              return (
                <motion.div key={l.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: Math.min(i * 0.01, 0.3) }}
                  className="flex items-center gap-4 px-5 py-3 hover:bg-white/5" data-testid={`log-${l.id}`}>
                  <div className="w-8 h-8 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center shrink-0"><Icon className="w-4 h-4" style={{ color: COLOR[l.category] || "#fff" }} /></div>
                  <div className="flex-1 min-w-0"><div className="text-sm truncate">{l.action}</div>{l.detail && <div className="text-xs text-white/35 font-mono truncate">{l.detail}</div>}</div>
                  <span className="text-[10px] uppercase tracking-wider px-2 py-1 rounded-full bg-white/5 text-white/40 hidden sm:block">{l.category}</span>
                  <span className="text-xs text-white/35 font-mono whitespace-nowrap">{new Date(l.created_at).toLocaleString()}</span>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
