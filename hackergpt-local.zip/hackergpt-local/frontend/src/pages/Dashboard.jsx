import { useEffect, useState } from "react";
import { useOutletContext, useNavigate, Link } from "react-router-dom";
import { motion } from "framer-motion";
import {
  Server, Zap, Terminal, MessageSquare, Plus, ArrowUpRight,
  Circle, Activity, Boxes, FolderTree, ScrollText,
} from "lucide-react";
import { api } from "../lib/api";
import { Button } from "../components/ui/button";

const CATEGORY_ICON = { auth: Zap, server: Server, connection: Server, command: Terminal, ai: MessageSquare, file: FolderTree, docker: Boxes };

export default function Dashboard() {
  const { selectServer } = useOutletContext();
  const [stats, setStats] = useState(null);
  const navigate = useNavigate();

  useEffect(() => { api.get("/dashboard/stats").then((r) => setStats(r.data)); }, []);

  const cards = stats ? [
    { label: "Total Servers", value: stats.total_servers, icon: Server },
    { label: "Online Now", value: stats.online_servers, icon: Circle, accent: true },
    { label: "Commands Run", value: stats.commands_run, icon: Terminal },
    { label: "Assistant Messages", value: stats.ai_messages, icon: MessageSquare },
  ] : [];

  const quickActions = [
    { label: "Open Workspace", icon: Terminal, to: "/app/workspace" },
    { label: "Add Server", icon: Plus, to: "/app/servers" },
    { label: "System Monitor", icon: Activity, to: "/app/monitor" },
    { label: "View Logs", icon: ScrollText, to: "/app/logs" },
  ];

  return (
    <div className="p-6 md:p-8 max-w-7xl mx-auto">
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="font-display text-3xl md:text-4xl font-light tracking-tight">Command Center</h1>
        <p className="text-white/45 mt-1">Your fleet at a glance.</p>
      </motion.div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mt-8">
        {cards.map((c, i) => (
          <motion.div key={c.label} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
            className="glass rounded-2xl p-5" data-testid={`stat-${c.label.toLowerCase().replace(/ /g, "-")}`}>
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs uppercase tracking-[0.15em] text-white/40">{c.label}</span>
              <c.icon className={`w-4 h-4 ${c.accent ? "text-[#22C55E]" : "text-white/40"}`} />
            </div>
            <div className="font-mono text-3xl font-semibold">{c.value}</div>
          </motion.div>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-4 mt-4">
        {/* Quick actions */}
        <div className="glass rounded-2xl p-6">
          <h3 className="font-display text-lg font-medium mb-4">Quick Actions</h3>
          <div className="grid grid-cols-2 gap-3">
            {quickActions.map((a) => (
              <button key={a.label} onClick={() => navigate(a.to)} data-testid={`quick-${a.label.toLowerCase().replace(/ /g, "-")}`}
                className="flex flex-col items-start gap-3 p-4 rounded-xl bg-white/5 border border-white/10 hover:border-accent-ai/30 hover:bg-white/8 transition-all group">
                <a.icon className="w-5 h-5 text-accent-ai" />
                <span className="text-sm font-medium">{a.label}</span>
              </button>
            ))}
          </div>
          <div className="mt-5 rounded-xl border border-white/10 bg-gradient-to-br from-accent-ai/10 to-transparent p-4">
            <div className="text-xs uppercase tracking-widest text-white/40">Subscription</div>
            <div className="font-display text-2xl font-medium mt-1">{stats?.plan || "Free"} plan</div>
            <p className="text-xs text-white/45 mt-1">All core features active.</p>
            <a href="https://t.me/dark_qqp" target="_blank" rel="noopener noreferrer" data-testid="activate-subscription-btn" className="block mt-3">
              <Button className="w-full rounded-full btn-crimson font-medium">Activate Subscription</Button>
            </a>
          </div>
        </div>

        {/* Connected servers */}
        <div className="glass rounded-2xl p-6 lg:col-span-1">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-display text-lg font-medium">Connected Servers</h3>
            <Link to="/app/servers" className="text-xs text-accent-ai flex items-center gap-1 hover:underline">Manage <ArrowUpRight className="w-3 h-3" /></Link>
          </div>
          {stats?.servers?.length ? (
            <div className="space-y-2">
              {stats.servers.map((s) => (
                <div key={s.id} onClick={() => { selectServer(s.id); navigate("/app/workspace"); }}
                  className="flex items-center gap-3 p-3 rounded-xl bg-white/5 hover:bg-white/8 cursor-pointer transition-colors" data-testid={`dash-server-${s.id}`}>
                  <Circle className={`w-2.5 h-2.5 ${s.status === "online" ? "fill-[#22C55E] text-[#22C55E] pulse-dot" : "fill-white/30 text-white/30"}`} />
                  <div className="flex-1 min-w-0"><div className="text-sm font-medium truncate">{s.nickname}</div><div className="text-xs text-white/40 font-mono truncate">{s.username}@{s.host}</div></div>
                  <span className="text-xs text-white/40 capitalize">{s.status}</span>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <Server className="w-8 h-8 text-white/20 mx-auto mb-3" />
              <p className="text-sm text-white/40 mb-4">No servers connected yet.</p>
              <Link to="/app/servers"><Button className="rounded-full btn-crimson"><Plus className="w-4 h-4 mr-1" /> Add server</Button></Link>
            </div>
          )}
        </div>

        {/* Recent activity */}
        <div className="glass rounded-2xl p-6">
          <h3 className="font-display text-lg font-medium mb-4">Recent Activity</h3>
          {stats?.recent_activity?.length ? (
            <div className="space-y-3">
              {stats.recent_activity.map((a, i) => {
                const Icon = CATEGORY_ICON[a.category] || Zap;
                return (
                  <div key={i} className="flex items-start gap-3">
                    <div className="w-7 h-7 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center shrink-0"><Icon className="w-3.5 h-3.5 text-white/50" /></div>
                    <div className="min-w-0"><div className="text-sm truncate">{a.action}</div><div className="text-xs text-white/35">{new Date(a.created_at).toLocaleString()}</div></div>
                  </div>
                );
              })}
            </div>
          ) : <p className="text-sm text-white/40 py-8 text-center">No activity yet.</p>}
        </div>
      </div>
    </div>
  );
}
