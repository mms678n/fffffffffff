import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { api, formatApiError } from "../lib/api";
import { useAuth } from "../context/AuthContext";
import { AuthShell } from "../components/AuthShell";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";

export default function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const { data } = await api.post("/auth/login", { username, password });
      login(data.token, data.user);
      toast.success(`Welcome back, ${data.user.username}`);
      navigate("/app");
    } catch (err) {
      toast.error(formatApiError(err.response?.data?.detail) || err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthShell title="Welcome back" subtitle="Log in to command your servers.">
      <form onSubmit={submit} className="space-y-4" data-testid="login-form">
        <div>
          <Label className="text-xs uppercase tracking-widest text-white/40">Username</Label>
          <Input value={username} onChange={(e) => setUsername(e.target.value)} placeholder="admin" autoFocus
            className="mt-2 bg-white/5 border-white/10 rounded-xl h-11 focus-visible:ring-accent-ai" data-testid="login-username" />
        </div>
        <div>
          <Label className="text-xs uppercase tracking-widest text-white/40">Password</Label>
          <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••"
            className="mt-2 bg-white/5 border-white/10 rounded-xl h-11 focus-visible:ring-accent-ai" data-testid="login-password" />
        </div>
        <Button type="submit" disabled={loading} className="w-full rounded-xl h-11 btn-crimson font-medium" data-testid="login-submit">
          {loading ? "Signing in..." : "Log in"}
        </Button>
      </form>
      <div className="flex justify-between mt-5 text-sm text-white/45">
        <Link to="/recover" className="hover:text-white" data-testid="link-recover">Forgot password?</Link>
        <Link to="/register" className="hover:text-white" data-testid="link-register">Create account</Link>
      </div>
    </AuthShell>
  );
}
