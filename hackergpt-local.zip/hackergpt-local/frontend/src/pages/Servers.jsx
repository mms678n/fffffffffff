import { useEffect, useState } from "react";
import { useOutletContext } from "react-router-dom";
import { motion } from "framer-motion";
import { toast } from "sonner";
import {
  Plus, Server, Trash2, Plug, Wifi, Circle, Cpu, HardDrive,
  MemoryStick, Network, Clock, User, Pencil, Loader2, MonitorSmartphone,
} from "lucide-react";
import { api, formatApiError } from "../lib/api";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Textarea } from "../components/ui/textarea";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "../components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "../components/ui/alert-dialog";

const EMPTY = { nickname: "", host: "", port: 22, username: "", password: "", ssh_key: "", os: "Linux" };

export default function Servers() {
  const { servers, refreshServers } = useOutletContext();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(EMPTY);
  const [editingId, setEditingId] = useState(null);
  const [saving, setSaving] = useState(false);
  const [busy, setBusy] = useState({});
  const [deleteId, setDeleteId] = useState(null);

  const openAdd = () => { setForm(EMPTY); setEditingId(null); setOpen(true); };
  const openEdit = (s) => { setForm({ ...EMPTY, ...s, password: "", ssh_key: "" }); setEditingId(s.id); setOpen(true); };

  const save = async () => {
    setSaving(true);
    try {
      const payload = { ...form, port: Number(form.port) };
      if (editingId) await api.put(`/servers/${editingId}`, payload);
      else await api.post("/servers", payload);
      toast.success(editingId ? "Server updated" : "Server added");
      setOpen(false);
      await refreshServers();
    } catch (err) {
      toast.error(formatApiError(err.response?.data?.detail) || err.message);
    } finally { setSaving(false); }
  };

  const setB = (id, v) => setBusy((p) => ({ ...p, [id]: v }));

  const test = async (s) => {
    setB(s.id, "test");
    try {
      const { data } = await api.post(`/servers/${s.id}/test`);
      data.success ? toast.success(`${s.nickname}: ${data.message}`) : toast.error(`${s.nickname}: ${data.message}`);
      await refreshServers();
    } catch (err) { toast.error(formatApiError(err.response?.data?.detail)); }
    finally { setB(s.id, null); }
  };

  const connect = async (s) => {
    setB(s.id, "connect");
    try {
      await api.post(`/servers/${s.id}/connect`);
      toast.success(`Connected to ${s.nickname}`);
      await refreshServers();
    } catch (err) { toast.error(formatApiError(err.response?.data?.detail)); }
    finally { setB(s.id, null); }
  };

  const doDelete = async () => {
    try {
      await api.delete(`/servers/${deleteId}`);
      toast.success("Server removed");
      await refreshServers();
    } catch (err) { toast.error(formatApiError(err.response?.data?.detail)); }
    finally { setDeleteId(null); }
  };

  return (
    <div className="p-6 md:p-8 max-w-7xl mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-3xl md:text-4xl font-light tracking-tight">Servers</h1>
          <p className="text-white/45 mt-1">Add and manage your isolated machines.</p>
        </div>
        <Button onClick={openAdd} className="rounded-full btn-crimson font-medium" data-testid="add-server-btn"><Plus className="w-4 h-4 mr-1" /> Add server</Button>
      </div>

      {servers.length === 0 ? (
        <div className="glass rounded-2xl p-16 text-center mt-8">
          <Server className="w-10 h-10 text-white/20 mx-auto mb-4" />
          <h3 className="font-display text-xl">No servers yet</h3>
          <p className="text-white/40 text-sm mt-1 mb-6">Connect your first machine to get started. Try the local demo (localhost / demo / demo1234).</p>
          <Button onClick={openAdd} className="rounded-full btn-crimson"><Plus className="w-4 h-4 mr-1" /> Add server</Button>
        </div>
      ) : (
        <div className="grid md:grid-cols-2 gap-4 mt-8">
          {servers.map((s, i) => (
            <motion.div key={s.id} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
              className="glass rounded-2xl p-6" data-testid={`server-card-${s.id}`}>
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center"><Server className="w-5 h-5 text-accent-ai" /></div>
                  <div>
                    <div className="flex items-center gap-2"><h3 className="font-display text-lg font-medium">{s.nickname}</h3><Circle className={`w-2.5 h-2.5 ${s.status === "online" ? "fill-[#22C55E] text-[#22C55E] pulse-dot" : s.status === "offline" ? "fill-[#FF3B30] text-[#FF3B30]" : "fill-white/30 text-white/30"}`} /></div>
                    <div className="text-xs text-white/40 font-mono">{s.username}@{s.host}:{s.port}</div>
                  </div>
                </div>
                <div className="flex gap-1">
                  <button onClick={() => openEdit(s)} className="p-2 rounded-lg hover:bg-white/10 text-white/50 hover:text-white" data-testid={`edit-server-${s.id}`}><Pencil className="w-4 h-4" /></button>
                  <button onClick={() => setDeleteId(s.id)} className="p-2 rounded-lg hover:bg-red-500/10 text-white/50 hover:text-red-400" data-testid={`delete-server-${s.id}`}><Trash2 className="w-4 h-4" /></button>
                </div>
              </div>

              {s.info && (
                <div className="grid grid-cols-2 gap-x-6 gap-y-2 mt-5 p-4 rounded-xl bg-black/40 border border-white/8 text-sm">
                  <InfoRow icon={MonitorSmartphone} label="Host" value={s.info.hostname} />
                  <InfoRow icon={Server} label="OS" value={s.info.os} />
                  <InfoRow icon={Cpu} label="CPU" value={`${s.info.cpu_cores} cores`} />
                  <InfoRow icon={MemoryStick} label="RAM" value={`${s.info.ram} MB`} />
                  <InfoRow icon={HardDrive} label="Disk" value={s.info.disk} />
                  <InfoRow icon={Network} label="IP" value={s.info.ip} />
                  <InfoRow icon={Clock} label="Uptime" value={s.info.uptime} />
                  <InfoRow icon={User} label="User" value={s.info.logged_user} />
                </div>
              )}

              <div className="flex gap-2 mt-5">
                <Button variant="outline" onClick={() => test(s)} disabled={busy[s.id]} className="flex-1 rounded-xl border-white/10 bg-white/5 hover:bg-white/10" data-testid={`test-server-${s.id}`}>
                  {busy[s.id] === "test" ? <Loader2 className="w-4 h-4 mr-1 animate-spin" /> : <Wifi className="w-4 h-4 mr-1" />} Test
                </Button>
                <Button onClick={() => connect(s)} disabled={busy[s.id]} className="flex-1 rounded-xl btn-crimson font-medium" data-testid={`connect-server-${s.id}`}>
                  {busy[s.id] === "connect" ? <Loader2 className="w-4 h-4 mr-1 animate-spin" /> : <Plug className="w-4 h-4 mr-1" />} Connect
                </Button>
              </div>
            </motion.div>
          ))}
        </div>
      )}

      {/* Add/Edit dialog */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="bg-[#0A0A0B] border-white/10 max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle className="font-display text-xl">{editingId ? "Edit server" : "Add server"}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <Field label="Nickname"><Input value={form.nickname} onChange={(e) => setForm({ ...form, nickname: e.target.value })} placeholder="Production DB" className="bg-white/5 border-white/10 rounded-xl focus-visible:ring-accent-ai" data-testid="field-nickname" /></Field>
            <div className="grid grid-cols-3 gap-3">
              <div className="col-span-2"><Field label="Host / IP"><Input value={form.host} onChange={(e) => setForm({ ...form, host: e.target.value })} placeholder="192.168.1.10" className="bg-white/5 border-white/10 rounded-xl focus-visible:ring-accent-ai font-mono" data-testid="field-host" /></Field></div>
              <Field label="Port"><Input type="number" value={form.port} onChange={(e) => setForm({ ...form, port: e.target.value })} className="bg-white/5 border-white/10 rounded-xl focus-visible:ring-accent-ai font-mono" data-testid="field-port" /></Field>
            </div>
            <Field label="Username"><Input value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} placeholder="root" className="bg-white/5 border-white/10 rounded-xl focus-visible:ring-accent-ai font-mono" data-testid="field-username" /></Field>
            <Field label={editingId ? "Password (leave blank to keep)" : "Password"}><Input type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} placeholder="••••••••" className="bg-white/5 border-white/10 rounded-xl focus-visible:ring-accent-ai" data-testid="field-password" /></Field>
            <Field label="SSH Private Key (optional)"><Textarea value={form.ssh_key} onChange={(e) => setForm({ ...form, ssh_key: e.target.value })} placeholder="-----BEGIN OPENSSH PRIVATE KEY-----" rows={3} className="bg-white/5 border-white/10 rounded-xl focus-visible:ring-accent-ai font-mono text-xs" data-testid="field-key" /></Field>
            <Field label="Operating System"><Input value={form.os} onChange={(e) => setForm({ ...form, os: e.target.value })} placeholder="Ubuntu 22.04" className="bg-white/5 border-white/10 rounded-xl focus-visible:ring-accent-ai" data-testid="field-os" /></Field>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={save} disabled={saving || !form.nickname || !form.host || !form.username} className="rounded-xl btn-crimson font-medium" data-testid="save-server-btn">
              {saving ? <Loader2 className="w-4 h-4 mr-1 animate-spin" /> : null}{editingId ? "Save changes" : "Add server"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent className="bg-[#0A0A0B] border-white/10">
          <AlertDialogHeader><AlertDialogTitle>Delete server?</AlertDialogTitle><AlertDialogDescription className="text-white/50">This removes the server and its stored credentials permanently.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-white/5 border-white/10 hover:bg-white/10">Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={doDelete} className="bg-red-500 hover:bg-red-600 text-white" data-testid="confirm-delete-server">Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function Field({ label, children }) {
  return <div><Label className="text-xs uppercase tracking-widest text-white/40 mb-2 block">{label}</Label>{children}</div>;
}

function InfoRow({ icon: Icon, label, value }) {
  return (
    <div className="flex items-center gap-2 min-w-0">
      <Icon className="w-3.5 h-3.5 text-white/30 shrink-0" />
      <span className="text-white/40 text-xs">{label}</span>
      <span className="ml-auto font-mono text-xs text-white/80 truncate">{value}</span>
    </div>
  );
}
