import { useEffect, useState, useCallback } from "react";
import { useOutletContext } from "react-router-dom";
import { toast } from "sonner";
import {
  Folder, File, ChevronRight, Home, Upload, FolderPlus, FilePlus,
  Trash2, Download, Pencil, Save, X, RefreshCw, Loader2, ArrowLeft, Search,
} from "lucide-react";
import { api, formatApiError, API, getToken } from "../lib/api";
import { EmptyServer } from "../components/EmptyServer";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "../components/ui/dialog";

function fmtSize(n) {
  if (n == null) return "";
  if (n < 1024) return n + " B";
  if (n < 1048576) return (n / 1024).toFixed(1) + " KB";
  return (n / 1048576).toFixed(1) + " MB";
}

export default function FileManager() {
  const { activeServer } = useOutletContext();
  const serverId = activeServer?.id;
  const [path, setPath] = useState(".");
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState("");
  const [editor, setEditor] = useState(null); // {path, content}
  const [saving, setSaving] = useState(false);
  const [prompt, setPrompt] = useState(null); // {type, value}

  const load = useCallback(async (p) => {
    if (!serverId) return;
    setLoading(true);
    try {
      const { data } = await api.get(`/servers/${serverId}/files`, { params: { path: p } });
      setItems(data.items);
      setPath(data.path === "." ? "." : data.path);
    } catch (err) { toast.error(formatApiError(err.response?.data?.detail)); }
    finally { setLoading(false); }
  }, [serverId]);

  useEffect(() => { if (serverId) { setPath("."); load("."); } }, [serverId, load]);

  if (!activeServer) return <EmptyServer feature="file manager" />;

  const resolve = (name) => (path === "." ? name : `${path.replace(/\/$/, "")}/${name}`);
  const parent = () => { if (path === "." || path === "/") return; const parts = path.replace(/\/$/, "").split("/"); parts.pop(); load(parts.join("/") || "/"); };

  const openItem = async (item) => {
    const full = resolve(item.name);
    if (item.is_dir) { load(full); return; }
    if (item.size > 500000) { toast.error("File too large to preview"); return; }
    try {
      const { data } = await api.get(`/servers/${serverId}/files/read`, { params: { path: full } });
      setEditor({ path: full, content: data.content });
    } catch (err) { toast.error(formatApiError(err.response?.data?.detail)); }
  };

  const saveFile = async () => {
    setSaving(true);
    try { await api.post(`/servers/${serverId}/files/write`, { path: editor.path, content: editor.content }); toast.success("Saved"); setEditor(null); }
    catch (err) { toast.error(formatApiError(err.response?.data?.detail)); }
    finally { setSaving(false); }
  };

  const del = async (item) => {
    if (!window.confirm(`Delete ${item.name}?`)) return;
    try { await api.post(`/servers/${serverId}/files/delete`, { path: resolve(item.name) }); toast.success("Deleted"); load(path); }
    catch (err) { toast.error(formatApiError(err.response?.data?.detail)); }
  };

  const download = (item) => {
    const url = `${API}/servers/${serverId}/files/download?path=${encodeURIComponent(resolve(item.name))}&token=${getToken()}`;
    window.open(url, "_blank");
  };

  const doPrompt = async () => {
    const { type, value } = prompt;
    try {
      if (type === "folder") await api.post(`/servers/${serverId}/files/mkdir`, { path: resolve(value) });
      else if (type === "file") await api.post(`/servers/${serverId}/files/write`, { path: resolve(value), content: "" });
      else if (type === "rename") await api.post(`/servers/${serverId}/files/rename`, { path: prompt.old, new_path: resolve(value) });
      toast.success("Done"); setPrompt(null); load(path);
    } catch (err) { toast.error(formatApiError(err.response?.data?.detail)); }
  };

  const upload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const fd = new FormData(); fd.append("file", file);
    try {
      await fetch(`${API}/servers/${serverId}/files/upload?path=${encodeURIComponent(path)}`, {
        method: "POST", headers: { Authorization: `Bearer ${getToken()}` }, body: fd,
      }).then((r) => { if (!r.ok) throw new Error("upload failed"); });
      toast.success("Uploaded"); load(path);
    } catch (err) { toast.error("Upload failed"); }
    e.target.value = "";
  };

  const filtered = items.filter((i) => i.name.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="p-6 md:p-8 max-w-7xl mx-auto">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="font-display text-3xl md:text-4xl font-light tracking-tight">Files</h1>
          <p className="text-white/45 mt-1">{activeServer.nickname} — browse over SFTP.</p>
        </div>
        <div className="flex gap-2">
          <label className="cursor-pointer"><input type="file" className="hidden" onChange={upload} data-testid="file-upload-input" /><Button asChild variant="outline" className="rounded-xl border-white/10 bg-white/5 hover:bg-white/10 pointer-events-none"><span><Upload className="w-4 h-4 mr-1" /> Upload</span></Button></label>
          <Button variant="outline" onClick={() => setPrompt({ type: "folder", value: "" })} className="rounded-xl border-white/10 bg-white/5 hover:bg-white/10" data-testid="new-folder-btn"><FolderPlus className="w-4 h-4 mr-1" /> Folder</Button>
          <Button variant="outline" onClick={() => setPrompt({ type: "file", value: "" })} className="rounded-xl border-white/10 bg-white/5 hover:bg-white/10" data-testid="new-file-btn"><FilePlus className="w-4 h-4 mr-1" /> File</Button>
        </div>
      </div>

      <div className="glass rounded-2xl mt-6 overflow-hidden">
        <div className="flex items-center gap-2 px-4 h-12 border-b border-white/8">
          <button onClick={parent} className="p-1.5 rounded-lg hover:bg-white/10 text-white/50" data-testid="file-up-btn"><ArrowLeft className="w-4 h-4" /></button>
          <button onClick={() => load(".")} className="p-1.5 rounded-lg hover:bg-white/10 text-white/50"><Home className="w-4 h-4" /></button>
          <span className="font-mono text-sm text-white/60 truncate flex-1">{path}</span>
          <div className="relative"><Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-white/30" /><Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search" className="h-8 w-40 pl-8 bg-white/5 border-white/10 rounded-lg text-sm" data-testid="file-search" /></div>
          <button onClick={() => load(path)} className="p-1.5 rounded-lg hover:bg-white/10 text-white/50" data-testid="file-refresh"><RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} /></button>
        </div>
        <div className="divide-y divide-white/5 max-h-[60vh] overflow-y-auto">
          {loading && <div className="p-8 text-center text-white/40"><Loader2 className="w-5 h-5 animate-spin mx-auto" /></div>}
          {!loading && filtered.length === 0 && <div className="p-8 text-center text-white/30 text-sm">Empty directory</div>}
          {!loading && filtered.map((item) => (
            <div key={item.name} className="group flex items-center gap-3 px-4 py-2.5 hover:bg-white/5 transition-colors" data-testid={`file-row-${item.name}`}>
              <button onClick={() => openItem(item)} className="flex items-center gap-3 flex-1 min-w-0 text-left">
                {item.is_dir ? <Folder className="w-4 h-4 text-accent-ai shrink-0" /> : <File className="w-4 h-4 text-white/40 shrink-0" />}
                <span className="text-sm truncate">{item.name}</span>
              </button>
              <span className="text-xs text-white/30 font-mono hidden md:block">{item.mode}</span>
              <span className="text-xs text-white/30 font-mono w-20 text-right hidden sm:block">{item.is_dir ? "—" : fmtSize(item.size)}</span>
              <div className="flex gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                {!item.is_dir && <button onClick={() => download(item)} className="p-1.5 rounded hover:bg-white/10 text-white/50" title="Download"><Download className="w-3.5 h-3.5" /></button>}
                <button onClick={() => setPrompt({ type: "rename", value: item.name, old: resolve(item.name) })} className="p-1.5 rounded hover:bg-white/10 text-white/50" title="Rename"><Pencil className="w-3.5 h-3.5" /></button>
                <button onClick={() => del(item)} className="p-1.5 rounded hover:bg-red-500/10 text-white/50 hover:text-red-400" title="Delete"><Trash2 className="w-3.5 h-3.5" /></button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Editor */}
      <Dialog open={!!editor} onOpenChange={() => setEditor(null)}>
        <DialogContent className="bg-[#0A0A0B] border-white/10 max-w-3xl">
          <DialogHeader><DialogTitle className="font-mono text-sm truncate">{editor?.path}</DialogTitle></DialogHeader>
          <textarea value={editor?.content || ""} onChange={(e) => setEditor({ ...editor, content: e.target.value })}
            className="w-full h-[50vh] bg-[#050505] border border-white/10 rounded-xl p-4 font-mono text-sm outline-none focus:border-accent-ai/40 resize-none" data-testid="file-editor" />
          <DialogFooter>
            <Button variant="ghost" onClick={() => setEditor(null)}><X className="w-4 h-4 mr-1" /> Close</Button>
            <Button onClick={saveFile} disabled={saving} className="rounded-xl btn-crimson" data-testid="file-save-btn">{saving ? <Loader2 className="w-4 h-4 mr-1 animate-spin" /> : <Save className="w-4 h-4 mr-1" />} Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Prompt */}
      <Dialog open={!!prompt} onOpenChange={() => setPrompt(null)}>
        <DialogContent className="bg-[#0A0A0B] border-white/10 max-w-sm">
          <DialogHeader><DialogTitle className="capitalize">{prompt?.type === "rename" ? "Rename" : `New ${prompt?.type}`}</DialogTitle></DialogHeader>
          <Input value={prompt?.value || ""} onChange={(e) => setPrompt({ ...prompt, value: e.target.value })} autoFocus
            onKeyDown={(e) => e.key === "Enter" && doPrompt()} placeholder="Name" className="bg-white/5 border-white/10 rounded-xl font-mono" data-testid="prompt-input" />
          <DialogFooter>
            <Button variant="ghost" onClick={() => setPrompt(null)}>Cancel</Button>
            <Button onClick={doPrompt} disabled={!prompt?.value} className="rounded-xl btn-crimson" data-testid="prompt-confirm">Confirm</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
