import { useEffect, useState, useRef } from "react";
import { useOutletContext } from "react-router-dom";
import {
  AreaChart, Area, ResponsiveContainer, YAxis, Tooltip, RadialBarChart, RadialBar,
} from "recharts";
import { Cpu, MemoryStick, HardDrive, Network, Activity, Pause, Play } from "lucide-react";
import { api } from "../lib/api";
import { EmptyServer } from "../components/EmptyServer";

function StatCard({ icon: Icon, label, value, sub, color = "#D4AF37" }) {
  return (
    <div className="glass rounded-2xl p-5">
      <div className="flex items-center justify-between mb-3">
        <span className="text-xs uppercase tracking-[0.15em] text-white/40">{label}</span>
        <Icon className="w-4 h-4" style={{ color }} />
      </div>
      <div className="font-mono text-3xl font-semibold">{value}</div>
      {sub && <div className="text-xs text-white/40 mt-1 font-mono">{sub}</div>}
    </div>
  );
}

export default function Monitor() {
  const { activeServer } = useOutletContext();
  const serverId = activeServer?.id;
  const [metrics, setMetrics] = useState(null);
  const [history, setHistory] = useState([]);
  const [paused, setPaused] = useState(false);
  const lastNet = useRef(null);
  const [netRate, setNetRate] = useState({ rx: 0, tx: 0 });

  useEffect(() => {
    if (!serverId || paused) return;
    let active = true;
    const poll = async () => {
      try {
        const { data } = await api.get(`/servers/${serverId}/metrics`);
        if (!active) return;
        setMetrics(data);
        const ramPct = data.ram.total ? (data.ram.used / data.ram.total) * 100 : 0;
        setHistory((h) => [...h.slice(-29), { t: Date.now(), cpu: data.cpu, ram: Math.round(ramPct) }]);
        if (lastNet.current) {
          const dt = 3;
          setNetRate({
            rx: Math.max(0, ((data.net.rx - lastNet.current.rx) / dt / 1024)),
            tx: Math.max(0, ((data.net.tx - lastNet.current.tx) / dt / 1024)),
          });
        }
        lastNet.current = data.net;
      } catch (e) {}
    };
    poll();
    const id = setInterval(poll, 3000);
    return () => { active = false; clearInterval(id); };
  }, [serverId, paused]);

  if (!activeServer) return <EmptyServer feature="system monitor" />;

  const ramPct = metrics?.ram.total ? Math.round((metrics.ram.used / metrics.ram.total) * 100) : 0;
  const diskPct = metrics?.disk.total ? Math.round((metrics.disk.used / metrics.disk.total) * 100) : 0;

  return (
    <div className="p-6 md:p-8 max-w-7xl mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-3xl md:text-4xl font-light tracking-tight">System Monitor</h1>
          <p className="text-white/45 mt-1">{activeServer.nickname} — live metrics, refreshing every 3s.</p>
        </div>
        <button onClick={() => setPaused(!paused)} className="flex items-center gap-2 px-4 py-2 rounded-full glass hover:border-white/20 text-sm" data-testid="monitor-pause">
          {paused ? <><Play className="w-4 h-4 text-accent-ai" /> Resume</> : <><Pause className="w-4 h-4" /> Pause</>}
        </button>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mt-8">
        <StatCard icon={Cpu} label="CPU Usage" value={`${metrics?.cpu ?? 0}%`} sub={`${activeServer.info?.cpu_cores || "?"} cores`} />
        <StatCard icon={MemoryStick} label="Memory" value={`${ramPct}%`} sub={`${metrics?.ram.used ?? 0} / ${metrics?.ram.total ?? 0} MB`} color="#22C55E" />
        <StatCard icon={HardDrive} label="Disk" value={`${diskPct}%`} sub={`${Math.round((metrics?.disk.used ?? 0) / 1024)} / ${Math.round((metrics?.disk.total ?? 0) / 1024)} GB`} color="#FFCC00" />
        <StatCard icon={Network} label="Network" value={`${netRate.rx.toFixed(0)} KB/s`} sub={`▲ ${netRate.tx.toFixed(0)} KB/s`} color="#BF5AF2" />
      </div>

      <div className="grid lg:grid-cols-2 gap-4 mt-4">
        <ChartCard title="CPU" color="#D4AF37" data={history} dataKey="cpu" />
        <ChartCard title="Memory" color="#22C55E" data={history} dataKey="ram" />
      </div>

      <div className="grid lg:grid-cols-3 gap-4 mt-4">
        <div className="glass rounded-2xl p-6 flex flex-col items-center justify-center">
          <span className="text-xs uppercase tracking-[0.15em] text-white/40 mb-2 self-start">Disk Usage</span>
          <ResponsiveContainer width="100%" height={180}>
            <RadialBarChart innerRadius="70%" outerRadius="100%" data={[{ name: "disk", value: diskPct, fill: "#FFCC00" }]} startAngle={90} endAngle={-270}>
              <RadialBar background={{ fill: "rgba(255,255,255,0.05)" }} dataKey="value" cornerRadius={20} />
            </RadialBarChart>
          </ResponsiveContainer>
          <div className="font-mono text-2xl font-semibold -mt-24">{diskPct}%</div>
          <div className="text-xs text-white/40 mt-16 font-mono">{Math.round((metrics?.disk.free ?? 0) / 1024)} GB free</div>
        </div>

        <div className="glass rounded-2xl p-6 lg:col-span-2">
          <div className="flex items-center gap-2 mb-4"><Activity className="w-4 h-4 text-accent-ai" /><span className="text-xs uppercase tracking-[0.15em] text-white/40">Top Processes</span></div>
          <div className="space-y-1">
            <div className="grid grid-cols-12 text-xs text-white/30 uppercase tracking-wider px-2 pb-2"><span className="col-span-2">PID</span><span className="col-span-6">Command</span><span className="col-span-2 text-right">CPU%</span><span className="col-span-2 text-right">MEM%</span></div>
            {(metrics?.processes || []).map((p, i) => (
              <div key={i} className="grid grid-cols-12 text-sm font-mono px-2 py-1.5 rounded-lg hover:bg-white/5" data-testid={`process-${p.pid}`}>
                <span className="col-span-2 text-white/40">{p.pid}</span>
                <span className="col-span-6 truncate">{p.name}</span>
                <span className="col-span-2 text-right text-accent-ai">{p.cpu}</span>
                <span className="col-span-2 text-right text-white/60">{p.mem}</span>
              </div>
            ))}
            {!metrics?.processes?.length && <div className="text-sm text-white/30 py-6 text-center">Loading processes...</div>}
          </div>
        </div>
      </div>
    </div>
  );
}

function ChartCard({ title, color, data, dataKey }) {
  return (
    <div className="glass rounded-2xl p-6">
      <div className="flex items-center justify-between mb-4">
        <span className="text-xs uppercase tracking-[0.15em] text-white/40">{title} History</span>
        <span className="font-mono text-sm" style={{ color }}>{data[data.length - 1]?.[dataKey] ?? 0}%</span>
      </div>
      <ResponsiveContainer width="100%" height={180}>
        <AreaChart data={data}>
          <defs><linearGradient id={`g-${dataKey}`} x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor={color} stopOpacity={0.4} /><stop offset="100%" stopColor={color} stopOpacity={0} /></linearGradient></defs>
          <YAxis domain={[0, 100]} hide />
          <Tooltip contentStyle={{ background: "#0A0A0B", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 12, fontSize: 12 }} labelFormatter={() => ""} />
          <Area type="monotone" dataKey={dataKey} stroke={color} strokeWidth={2} fill={`url(#g-${dataKey})`} isAnimationActive={false} dot={false} />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
