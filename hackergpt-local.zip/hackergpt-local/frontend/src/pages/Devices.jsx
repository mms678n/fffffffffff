import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";
import {
  Plus, Laptop, Monitor, Terminal as TerminalIcon, Circle, Copy, Trash2,
  Download, ArrowRight, ArrowLeft, Cpu, MemoryStick, HardDrive, Network,
  Clock, User, Server, ShieldCheck, Loader2, MonitorSmartphone,
  Pencil, ExternalLink, CheckCircle2, Wifi, X,
} from "lucide-react";
import { api, formatApiError, API } from "../lib/api";
import { useDeviceRealtime } from "../hooks/useDeviceRealtime";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from "../components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "../components/ui/alert-dialog";

const OS_LIST = [
  { key: "windows", label: "Windows", sub: "64-bit", icon: Monitor,
    cmd: (s) => `iwr "${s}/api/agent/download/windows" -OutFile install.ps1; powershell -ExecutionPolicy Bypass -File .\\install.ps1` },
  { key: "linux", label: "Linux", sub: "Ubuntu · Debian · Kali · Fedora · Arch", icon: TerminalIcon,
    cmd: (s) => `curl -fsSL "${s}/api/agent/download/linux" -o install.sh && bash install.sh` },
  { key: "macos", label: "macOS", sub: "Intel & Apple Silicon", icon: Laptop,
    cmd: (s) => `curl -fsSL "${s}/api/agent/download/macos" -o install.sh && bash install.sh` },
];

const BACKEND = process.env.REACT_APP_BACKEND_URL;

export default function Devices() {
  const navigate = useNavigate();
  const { devices, refresh } = useDeviceRealtime();
  const [open, setOpen] = useState(false);
  const [step, setStep] = useState(1);
  const [os, setOs] = useState(null);
  const [deviceId, setDeviceId] = useState("");
  const [secret, setSecret] = useState("");
  const [saving, setSaving] = useState(false);
  const [deleteId, setDeleteId] = useState(null);
  const [paired, setPaired] = useState(null);
  const [renameTarget, setRenameTarget] = useState(null);
  const [renameValue, setRenameValue] = useState("");
  const [savingRename, setSavingRename] = useState(false);
  const [detail, setDetail] = useState(null);

  const reset = () => { setStep(1); setOs(null); setDeviceId(""); setSecret(""); setPaired(null); };
  const openDialog = () => { reset(); setOpen(true); };

  const register = async () => {
    setSaving(true);
    try {
      const { data } = await api.post("/devices/register", { device_id: deviceId.trim(), device_secret: secret.trim() });
      setPaired(data);
      refresh();
      setStep(4);
    } catch (err) {
      toast.error(formatApiError(err.response?.data?.detail) || err.message);
    } finally { setSaving(false); }
  };

  const remove = async () => {
    try { await api.delete(`/devices/${deleteId}`); toast.success("Device removed"); refresh(); }
    catch (err) { toast.error(formatApiError(err.response?.data?.detail)); }
    finally { setDeleteId(null); }
  };

  const openRename = (d) => { setRenameTarget(d); setRenameValue(d.name); };
  const doRename = async () => {
    setSavingRename(true);
    try {
      await api.put(`/devices/${renameTarget.id}/rename`, { name: renameValue.trim() });
      toast.success("Device renamed");
      setRenameTarget(null);
      refresh();
    } catch (err) { toast.error(formatApiError(err.response?.data?.detail)); }
    finally { setSavingRename(false); }
  };

  const copy = (text, what) => { navigator.clipboard.writeText(text); toast.success(`${what} copied`); };

  return (
    <div className="p-6 md:p-8 max-w-7xl mx-auto">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="font-display text-3xl md:text-4xl font-light tracking-tight">Devices</h1>
          <p className="text-white/45 mt-1">Connect your own machines with the HackerGPT Agent.</p>
        </div>
        <Button onClick={openDialog} className="rounded-full btn-crimson font-medium" data-testid="add-device-btn"><Plus className="w-4 h-4 mr-1" /> Add Device</Button>
      </div>

      {devices.length === 0 ? (
        <div className="glass rounded-2xl p-16 text-center mt-8">
          <MonitorSmartphone className="w-10 h-10 text-white/20 mx-auto mb-4" />
          <h3 className="font-display text-xl">No devices yet</h3>
          <p className="text-white/40 text-sm mt-1 mb-6">Install the HackerGPT Agent on a machine and link it here.</p>
          <Button onClick={openDialog} className="rounded-full btn-crimson"><Plus className="w-4 h-4 mr-1" /> Add Device</Button>
        </div>
      ) : (
        <div className="grid md:grid-cols-2 gap-4 mt-8">
          {devices.map((d, i) => {
            const online = d.status === "online";
            const connecting = d.status === "connecting";
            const error = d.status === "error";
            return (
            <motion.div key={d.id} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
              className="glass rounded-2xl p-6 flex flex-col" data-testid={`device-card-${d.device_id}`}>
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-11 h-11 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center shrink-0"><MonitorSmartphone className="w-5 h-5 text-gold" /></div>
                  <div className="min-w-0">
                    <h3 className="font-display text-lg font-medium truncate">{d.name}</h3>
                    <button onClick={() => copy(d.device_id, "Device ID")} className="text-xs text-white/40 font-mono flex items-center gap-1 hover:text-white" data-testid={`copy-device-id-${d.device_id}`}>{d.device_id} <Copy className="w-3 h-3" /></button>
                  </div>
                </div>
                <span className={`flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-full shrink-0 ${online ? "bg-[#22C55E]/10 text-[#22C55E]" : error ? "bg-red-500/10 text-red-400" : connecting ? "bg-amber-500/10 text-amber-300" : "bg-white/5 text-white/40"}`}>
                  <Circle className={`w-2 h-2 ${online ? "fill-[#22C55E] text-[#22C55E] pulse-dot" : error ? "fill-red-400 text-red-400" : connecting ? "fill-amber-300 text-amber-300" : "fill-white/30 text-white/30"}`} /> {online ? "Online" : connecting ? "Connecting" : error ? "Error" : "Offline"}
                </span>
              </div>

              {d.info ? (
                <div className="grid grid-cols-2 gap-x-6 gap-y-2 mt-5 p-4 rounded-xl bg-black/40 border border-white/8 text-sm">
                  <Info icon={Server} label="OS" value={`${d.info.os} ${d.info.os_version}`} />
                  <Info icon={Cpu} label="CPU" value={`${d.info.cpu_cores} cores · ${d.info.cpu_usage}%`} />
                  <Info icon={MemoryStick} label="RAM" value={`${d.info.ram_used_pct}% of ${d.info.ram_total_gb}GB`} />
                  <Info icon={HardDrive} label="Disk" value={`${d.info.disk_used_gb}/${d.info.disk_total_gb}GB`} />
                  <Info icon={Clock} label="Uptime" value={d.info.uptime} />
                  <Info icon={ShieldCheck} label="Agent" value={`v${d.agent_version || "?"}`} />
                  <Info icon={Network} label="Internal IP" value={d.info.internal_ip} />
                  <Info icon={Network} label="Public IP" value={d.info.public_ip} />
                </div>
              ) : (
                <div className="mt-5 p-4 rounded-xl bg-black/40 border border-white/8 text-sm text-white/40 flex items-center gap-2"><Loader2 className="w-4 h-4 animate-spin" /> Waiting for the Agent to report system information…</div>
              )}
              {d.last_seen && <div className="text-xs text-white/30 mt-3">Last seen {new Date(d.last_seen).toLocaleString()}</div>}

              <div className="flex gap-2 mt-5 pt-4 border-t border-white/8">
                <Button onClick={() => navigate(`/app/devices/${d.id}`)} className="flex-1 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10" data-testid={`open-device-${d.device_id}`}><ExternalLink className="w-4 h-4 mr-1" /> Open</Button>
                <Button onClick={() => openRename(d)} variant="outline" className="rounded-xl border-white/10 bg-white/5 hover:bg-white/10" data-testid={`rename-device-${d.device_id}`}><Pencil className="w-4 h-4" /></Button>
                <Button onClick={() => setDeleteId(d.id)} variant="outline" className="rounded-xl border-white/10 bg-white/5 hover:bg-red-500/10 hover:text-red-400" data-testid={`remove-device-${d.device_id}`}><Trash2 className="w-4 h-4" /></Button>
              </div>
            </motion.div>
          );})}
        </div>
      )}

      {/* Add device dialog */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="bg-[#16181D] border-white/10 max-w-lg">
          <DialogHeader><DialogTitle className="font-display text-xl">Add a device</DialogTitle></DialogHeader>
          <AnimatePresence mode="wait">
            {step === 1 && (
              <motion.div key="s1" initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -10 }}>
                <p className="text-sm text-white/50 mb-4">1. Choose your operating system</p>
                <div className="space-y-2">
                  {OS_LIST.map((o) => (
                    <button key={o.key} onClick={() => { setOs(o); setStep(2); }} data-testid={`os-${o.key}`}
                      className={`w-full flex items-center gap-3 p-4 rounded-xl border text-left transition-all ${os?.key === o.key ? "border-gold/40 bg-gold/5" : "border-white/10 bg-white/5 hover:border-white/20"}`}>
                      <o.icon className="w-5 h-5 text-gold" />
                      <div className="flex-1"><div className="text-sm font-medium">{o.label}</div><div className="text-xs text-white/40">{o.sub}</div></div>
                      <ArrowRight className="w-4 h-4 text-white/30" />
                    </button>
                  ))}
                </div>
                <button onClick={() => setStep(3)} className="text-xs text-gold mt-4 hover:underline" data-testid="already-installed">I already installed the Agent → enter credentials</button>
              </motion.div>
            )}
            {step === 2 && os && (
              <motion.div key="s2" initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -10 }}>
                <button onClick={() => setStep(1)} className="text-xs text-white/40 flex items-center gap-1 mb-4 hover:text-white"><ArrowLeft className="w-3 h-3" /> Back</button>
                <div className="flex flex-col items-center text-center mb-5">
                  <div className="w-14 h-14 rounded-2xl bg-gold/10 border border-gold/20 flex items-center justify-center mb-3"><os.icon className="w-7 h-7 text-gold" /></div>
                  <h3 className="font-display text-lg font-medium">Download the Agent for {os.label}</h3>
                  <p className="text-xs text-white/40 mt-1">{os.sub}</p>
                </div>
                <a href={`${BACKEND}/api/agent/download/${os.key}`} target="_blank" rel="noreferrer">
                  <Button className="w-full rounded-xl btn-crimson font-medium h-12 text-base" data-testid="download-installer"><Download className="w-5 h-5 mr-2" /> Download for {os.label}</Button>
                </a>
                <div className="mt-5 space-y-2.5">
                  {["Download the HackerGPT Agent.", "Install it.", "Launch it.", "Copy your Device ID and Device Secret.", "Return here."].map((t, idx) => (
                    <div key={idx} className="flex items-center gap-3 text-sm text-white/70">
                      <span className="w-5 h-5 rounded-full bg-white/8 border border-white/10 flex items-center justify-center text-[11px] text-gold shrink-0">{idx + 1}</span>{t}
                    </div>
                  ))}
                </div>
                <div className="mt-5 flex items-start gap-2 p-3 rounded-xl bg-black/50 border border-white/10">
                  <code className="text-[11px] text-gold flex-1 break-all font-mono">{os.cmd(BACKEND)}</code>
                  <button onClick={() => copy(os.cmd(BACKEND), "Command")} className="text-white/40 hover:text-white shrink-0"><Copy className="w-3.5 h-3.5" /></button>
                </div>
                <Button onClick={() => setStep(3)} className="w-full rounded-xl mt-5 btn-crimson font-medium" data-testid="goto-register">I've Installed the Agent <ArrowRight className="w-4 h-4 ml-2" /></Button>
              </motion.div>
            )}
            {step === 3 && (
              <motion.div key="s3" initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -10 }}>
                <button onClick={() => setStep(os ? 2 : 1)} className="text-xs text-white/40 flex items-center gap-1 mb-3 hover:text-white"><ArrowLeft className="w-3 h-3" /> Back</button>
                <div className="flex flex-col items-center text-center mb-5">
                  <div className="w-14 h-14 rounded-2xl bg-crimson/15 border border-crimson2/30 flex items-center justify-center mb-3"><ShieldCheck className="w-7 h-7 text-crimson2" /></div>
                  <h3 className="font-display text-lg font-medium">Pair your device</h3>
                  <p className="text-xs text-white/40 mt-1">Paste the values shown in the Agent. No IP address needed.</p>
                </div>
                <div className="space-y-4">
                  <div>
                    <Label className="text-xs uppercase tracking-widest text-white/40 mb-2 block">Device ID</Label>
                    <Input value={deviceId} onChange={(e) => setDeviceId(e.target.value)} placeholder="HG-XXXXXXXX-XXXX" className="bg-white/5 border-white/10 rounded-xl font-mono focus-visible:ring-gold" data-testid="device-id-input" />
                  </div>
                  <div>
                    <Label className="text-xs uppercase tracking-widest text-white/40 mb-2 block">Device Secret</Label>
                    <Input value={secret} onChange={(e) => setSecret(e.target.value)} placeholder="Paste the 64+ character secret" className="bg-white/5 border-white/10 rounded-xl font-mono text-xs focus-visible:ring-gold" data-testid="device-secret-input" />
                  </div>
                </div>
                <div className="flex gap-2 mt-6">
                  <Button onClick={() => setOpen(false)} variant="ghost" className="flex-1 rounded-xl hover:bg-white/5" data-testid="pair-cancel">Cancel</Button>
                  <Button onClick={register} disabled={saving || !deviceId || !secret} className="flex-1 rounded-xl btn-crimson font-medium" data-testid="register-device-btn">
                    {saving ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Pairing…</> : <><ShieldCheck className="w-4 h-4 mr-2" /> Pair Device</>}
                  </Button>
                </div>
              </motion.div>
            )}
            {step === 4 && paired && (
              <motion.div key="s4" initial={{ opacity: 0, scale: 0.96 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }}>
                <div className="flex flex-col items-center text-center py-2">
                  <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring", stiffness: 200, delay: 0.05 }}
                    className="w-16 h-16 rounded-full bg-[#22C55E]/10 border border-[#22C55E]/30 flex items-center justify-center mb-4">
                    <CheckCircle2 className="w-9 h-9 text-[#22C55E]" />
                  </motion.div>
                  <h3 className="font-display text-xl font-medium">Device linked successfully</h3>
                  <p className="text-xs text-white/40 mt-1">The Agent will connect automatically.</p>
                </div>
                <div className="mt-4 p-4 rounded-xl bg-black/40 border border-white/8 space-y-2 text-sm">
                  <Info icon={MonitorSmartphone} label="Device Name" value={paired.name} />
                  <Info icon={Server} label="Operating System" value={paired.info ? `${paired.info.os} ${paired.info.os_version}` : "Discovering…"} />
                  <Info icon={Wifi} label="Connection" value={paired.status === "online" ? "Online" : "Offline"} />
                  <Info icon={Clock} label="Last Seen" value={paired.last_seen ? new Date(paired.last_seen).toLocaleString() : "—"} />
                </div>
                <Button onClick={() => setOpen(false)} className="w-full rounded-xl mt-5 btn-crimson font-medium" data-testid="pair-done">Done</Button>
              </motion.div>
            )}
          </AnimatePresence>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent className="bg-[#16181D] border-white/10">
          <AlertDialogHeader><AlertDialogTitle>Remove device?</AlertDialogTitle><AlertDialogDescription className="text-white/50">The device will be unlinked and its Agent disconnected. It can be re-linked later.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-white/5 border-white/10 hover:bg-white/10">Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={remove} className="bg-red-500 hover:bg-red-600 text-white" data-testid="confirm-remove-device">Remove</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Rename dialog */}
      <Dialog open={!!renameTarget} onOpenChange={() => setRenameTarget(null)}>
        <DialogContent className="bg-[#16181D] border-white/10 max-w-sm">
          <DialogHeader><DialogTitle className="font-display text-lg">Rename device</DialogTitle></DialogHeader>
          <Input value={renameValue} onChange={(e) => setRenameValue(e.target.value)} autoFocus
            onKeyDown={(e) => e.key === "Enter" && renameValue.trim() && doRename()}
            className="bg-white/5 border-white/10 rounded-xl focus-visible:ring-gold" data-testid="rename-input" />
          <div className="flex gap-2 mt-2">
            <Button onClick={() => setRenameTarget(null)} variant="ghost" className="flex-1 rounded-xl hover:bg-white/5">Cancel</Button>
            <Button onClick={doRename} disabled={savingRename || !renameValue.trim()} className="flex-1 rounded-xl btn-crimson font-medium" data-testid="rename-save">
              {savingRename ? <Loader2 className="w-4 h-4 animate-spin" /> : "Save"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Detail (Open) dialog */}
      <Dialog open={!!detail} onOpenChange={() => setDetail(null)}>
        <DialogContent className="bg-[#16181D] border-white/10 max-w-lg">
          <DialogHeader>
            <DialogTitle className="font-display text-xl flex items-center gap-2">
              <MonitorSmartphone className="w-5 h-5 text-gold" /> {detail?.name}
            </DialogTitle>
          </DialogHeader>
          {detail && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <button onClick={() => copy(detail.device_id, "Device ID")} className="text-xs text-white/50 font-mono flex items-center gap-1 hover:text-white">{detail.device_id} <Copy className="w-3 h-3" /></button>
                <span className={`flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-full ${detail.status === "online" ? "bg-[#22C55E]/10 text-[#22C55E]" : "bg-white/5 text-white/40"}`}>
                  <Circle className={`w-2 h-2 ${detail.status === "online" ? "fill-[#22C55E] text-[#22C55E]" : "fill-white/30 text-white/30"}`} /> {detail.status === "online" ? "Online" : "Offline"}
                </span>
              </div>
              {detail.info ? (
                <div className="grid grid-cols-2 gap-x-6 gap-y-2 p-4 rounded-xl bg-black/40 border border-white/8 text-sm">
                  <Info icon={Server} label="OS" value={`${detail.info.os} ${detail.info.os_version}`} />
                  <Info icon={Cpu} label="Arch" value={detail.info.arch} />
                  <Info icon={Cpu} label="CPU" value={`${detail.info.cpu_cores} cores · ${detail.info.cpu_usage}%`} />
                  <Info icon={MemoryStick} label="RAM" value={`${detail.info.ram_used_pct}% of ${detail.info.ram_total_gb}GB`} />
                  <Info icon={HardDrive} label="Disk" value={`${detail.info.disk_used_gb}/${detail.info.disk_total_gb}GB`} />
                  <Info icon={Clock} label="Uptime" value={detail.info.uptime} />
                  <Info icon={Network} label="Internal IP" value={detail.info.internal_ip} />
                  <Info icon={Network} label="Public IP" value={detail.info.public_ip} />
                  <Info icon={User} label="User" value={detail.info.current_user} />
                  <Info icon={ShieldCheck} label="Agent" value={`v${detail.agent_version || "?"}`} />
                </div>
              ) : (
                <div className="p-4 rounded-xl bg-black/40 border border-white/8 text-sm text-white/40 flex items-center gap-2"><Loader2 className="w-4 h-4 animate-spin" /> Waiting for the Agent to report system information…</div>
              )}
              {detail.last_seen && <div className="text-xs text-white/30">Last seen {new Date(detail.last_seen).toLocaleString()}</div>}
              <p className="text-[11px] text-white/30 pt-1">Remote command execution to this device is coming soon — the secure channel is already established.</p>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function Info({ icon: Icon, label, value }) {
  return (
    <div className="flex items-center gap-2 min-w-0">
      <Icon className="w-3.5 h-3.5 text-white/30 shrink-0" />
      <span className="text-white/40 text-xs">{label}</span>
      <span className="ml-auto font-mono text-xs text-white/80 truncate">{value}</span>
    </div>
  );
}
