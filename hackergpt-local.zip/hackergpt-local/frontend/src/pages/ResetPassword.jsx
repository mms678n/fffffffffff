import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { api, formatApiError } from "../lib/api";
import { AuthShell } from "../components/AuthShell";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";

export default function ResetPassword() {
  const [username, setUsername] = useState("");
  const [code, setCode] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const { data } = await api.post("/auth/reset-password", {
        username, recovery_code: code, new_password: newPassword,
      });
      toast.success("Password reset. Save your new recovery code!");
      toast.message("New recovery code", { description: data.recovery_code, duration: 15000 });
      navigate("/login");
    } catch (err) {
      toast.error(formatApiError(err.response?.data?.detail) || err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthShell title="Recover access" subtitle="Enter your username and recovery code to set a new password.">
      <form onSubmit={submit} className="space-y-4" data-testid="recover-form">
        <div>
          <Label className="text-xs uppercase tracking-widest text-white/40">Username</Label>
          <Input value={username} onChange={(e) => setUsername(e.target.value)} className="mt-2 bg-white/5 border-white/10 rounded-xl h-11 focus-visible:ring-accent-ai" data-testid="recover-username" />
        </div>
        <div>
          <Label className="text-xs uppercase tracking-widest text-white/40">Recovery code</Label>
          <Input value={code} onChange={(e) => setCode(e.target.value)} placeholder="XXXX-XXXX-XXXX-XXXX" className="mt-2 bg-white/5 border-white/10 rounded-xl h-11 font-mono focus-visible:ring-accent-ai" data-testid="recover-code" />
        </div>
        <div>
          <Label className="text-xs uppercase tracking-widest text-white/40">New password</Label>
          <Input type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} className="mt-2 bg-white/5 border-white/10 rounded-xl h-11 focus-visible:ring-accent-ai" data-testid="recover-new-password" />
        </div>
        <Button type="submit" disabled={loading} className="w-full rounded-xl h-11 btn-crimson font-medium" data-testid="recover-submit">
          {loading ? "Resetting..." : "Reset password"}
        </Button>
      </form>
      <p className="mt-5 text-sm text-white/45 text-center"><Link to="/login" className="text-white hover:underline">Back to login</Link></p>
    </AuthShell>
  );
}
