import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { Copy, ShieldCheck, ArrowRight } from "lucide-react";
import { api, formatApiError } from "../lib/api";
import { useAuth } from "../context/AuthContext";
import { AuthShell } from "../components/AuthShell";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";

export default function Register() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [recovery, setRecovery] = useState(null);
  const { login } = useAuth();
  const navigate = useNavigate();

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const { data } = await api.post("/auth/register", { username, password });
      setRecovery({ code: data.recovery_code, token: data.token, user: data.user });
    } catch (err) {
      toast.error(formatApiError(err.response?.data?.detail) || err.message);
    } finally {
      setLoading(false);
    }
  };

  const finish = () => {
    login(recovery.token, recovery.user);
    navigate("/app");
  };

  if (recovery) {
    return (
      <AuthShell title="Save your recovery code" subtitle="This is the only way to reset your password. Store it somewhere safe — it won't be shown again.">
        <div className="rounded-xl border border-accent-ai/30 bg-accent-ai/5 p-5 text-center" data-testid="recovery-code-box">
          <ShieldCheck className="w-6 h-6 text-accent-ai mx-auto mb-3" />
          <div className="font-mono text-xl tracking-[0.15em] text-white break-all">{recovery.code}</div>
        </div>
        <Button variant="outline" className="w-full mt-4 rounded-xl border-white/10 bg-white/5 hover:bg-white/10"
          onClick={() => { navigator.clipboard.writeText(recovery.code); toast.success("Recovery code copied"); }} data-testid="copy-recovery">
          <Copy className="w-4 h-4 mr-2" /> Copy code
        </Button>
        <Button className="w-full mt-3 rounded-xl h-11 btn-crimson font-medium" onClick={finish} data-testid="recovery-continue">
          I've saved it — continue <ArrowRight className="w-4 h-4 ml-2" />
        </Button>
      </AuthShell>
    );
  }

  return (
    <AuthShell title="Create your account" subtitle="No email needed. Just a username and password.">
      <form onSubmit={submit} className="space-y-4" data-testid="register-form">
        <div>
          <Label className="text-xs uppercase tracking-widest text-white/40">Username</Label>
          <Input value={username} onChange={(e) => setUsername(e.target.value)} placeholder="Choose a username" autoFocus
            className="mt-2 bg-white/5 border-white/10 rounded-xl h-11 focus-visible:ring-accent-ai" data-testid="register-username" />
        </div>
        <div>
          <Label className="text-xs uppercase tracking-widest text-white/40">Password</Label>
          <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="At least 6 characters"
            className="mt-2 bg-white/5 border-white/10 rounded-xl h-11 focus-visible:ring-accent-ai" data-testid="register-password" />
        </div>
        <Button type="submit" disabled={loading} className="w-full rounded-xl h-11 btn-crimson font-medium" data-testid="register-submit">
          {loading ? "Creating..." : "Create account"}
        </Button>
      </form>
      <p className="mt-5 text-sm text-white/45 text-center">Already have an account? <Link to="/login" className="text-white hover:underline">Log in</Link></p>
    </AuthShell>
  );
}
