import { useEffect, useState } from "react";
import { toast } from "sonner";
import {
  Users, Server, ScrollText, MessageSquare, Trash2, Shield,
  Activity, CheckCircle2, Cpu,
} from "lucide-react";
import { api, formatApiError } from "../lib/api";
import { Button } from "../components/ui/button";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "../components/ui/select";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "../components/ui/alert-dialog";

export default function Admin() {
  const [stats, setStats] = useState(null);
  const [users, setUsers] = useState([]);
  const [logs, setLogs] = useState([]);
  const [tab, setTab] = useState("users");
  const [deleteId, setDeleteId] = useState(null);

  const loadAll = () => {
    api.get("/admin/stats").then((r) => setStats(r.data));
    api.get("/admin/users").then((r) => setUsers(r.data));
    api.get("/admin/logs").then((r) => setLogs(r.data));
  };
  useEffect(loadAll, []);

  const setPlan = async (id, plan) => {
    try { await api.put(`/admin/users/${id}/plan`, null, { params: { plan } }); toast.success("Plan updated"); loadAll(); }
    catch (err) { toast.error(formatApiError(err.response?.data?.detail)); }
  };
  const doDelete = async () => {
    try { await api.delete(`/admin/users/${deleteId}`); toast.success("User deleted"); loadAll(); }
    catch (err) { toast.error(formatApiError(err.response?.data?.detail)); }
    finally { setDeleteId(null); }
  };

  const cards = stats ? [
    { label: "Total Users", value: stats.total_users, icon: Users },
    { label: "Servers", value: stats.total_servers, icon: Server },
    { label: "Chat Sessions", value: stats.total_sessions, icon: MessageSquare },
    { label: "Log Entries", value: stats.total_logs, icon: ScrollText },
  ] : [];

  return (
    <div className="p-6 md:p-8 max-w-7xl mx-auto">
      <div className="flex items-center gap-3">
        <Shield className="w-7 h-7 text-accent-ai" />
        <div><h1 className="font-display text-3xl md:text-4xl font-light tracking-tight">Admin Panel</h1><p className="text-white/45 mt-1">Platform-wide control and health.</p></div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mt-8">
        {cards.map((c) => (
          <div key={c.label} className="glass rounded-2xl p-5">
            <div className="flex items-center justify-between mb-3"><span className="text-xs uppercase tracking-[0.15em] text-white/40">{c.label}</span><c.icon className="w-4 h-4 text-accent-ai" /></div>
            <div className="font-mono text-3xl font-semibold">{c.value}</div>
          </div>
        ))}
      </div>

      {/* Health */}
      <div className="glass rounded-2xl p-6 mt-4">
        <div className="flex items-center gap-2 mb-4"><Activity className="w-4 h-4 text-accent-ai" /><span className="text-xs uppercase tracking-[0.15em] text-white/40">System Health</span></div>
        <div className="grid sm:grid-cols-3 gap-4">
          {stats && Object.entries(stats.system_health).map(([k, v]) => (
            <div key={k} className="flex items-center gap-3 p-4 rounded-xl bg-white/5 border border-white/10">
              <CheckCircle2 className="w-5 h-5 text-[#22C55E]" />
              <div><div className="text-sm capitalize">{k.replace("_", " ")}</div><div className="text-xs text-[#22C55E] capitalize">{v}</div></div>
            </div>
          ))}
        </div>
      </div>

      <div className="flex gap-1 mt-6 p-1 rounded-xl glass w-fit">
        {[["users", "Users"], ["logs", "Audit Logs"]].map(([k, l]) => (
          <button key={k} onClick={() => setTab(k)} data-testid={`admin-tab-${k}`} className={`px-4 py-2 rounded-lg text-sm ${tab === k ? "bg-white/10 text-white" : "text-white/50 hover:text-white"}`}>{l}</button>
        ))}
      </div>

      {tab === "users" && (
        <div className="glass rounded-2xl mt-4 overflow-hidden">
          <div className="grid grid-cols-12 px-5 py-3 text-xs uppercase tracking-wider text-white/30 border-b border-white/8"><span className="col-span-3">Username</span><span className="col-span-2">Role</span><span className="col-span-3">Plan</span><span className="col-span-2">Servers</span><span className="col-span-2 text-right">Actions</span></div>
          {users.map((u) => (
            <div key={u.id} className="grid grid-cols-12 items-center px-5 py-3 hover:bg-white/5 border-b border-white/5" data-testid={`admin-user-${u.id}`}>
              <span className="col-span-3 text-sm font-medium truncate flex items-center gap-2"><span className="w-6 h-6 rounded-full bg-gradient-to-br from-accent-ai to-indigo-500 flex items-center justify-center text-black text-xs font-bold">{u.username[0].toUpperCase()}</span>{u.username}</span>
              <span className="col-span-2"><span className={`text-xs px-2 py-0.5 rounded-full ${u.role === "admin" ? "bg-accent-ai/10 text-accent-ai" : "bg-white/5 text-white/50"}`}>{u.role}</span></span>
              <div className="col-span-3">
                <Select value={u.plan} onValueChange={(v) => setPlan(u.id, v)}>
                  <SelectTrigger className="h-8 w-32 bg-white/5 border-white/10 rounded-lg text-xs" data-testid={`plan-select-${u.id}`}><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-[#0A0A0B] border-white/10">
                    {["Free", "Pro", "Enterprise"].map((p) => <SelectItem key={p} value={p}>{p}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <span className="col-span-2 font-mono text-sm text-white/60">{u.server_count}</span>
              <div className="col-span-2 flex justify-end">
                <button onClick={() => setDeleteId(u.id)} disabled={u.role === "admin"} className="p-2 rounded-lg hover:bg-red-500/10 text-white/40 hover:text-red-400 disabled:opacity-20" data-testid={`admin-delete-${u.id}`}><Trash2 className="w-4 h-4" /></button>
              </div>
            </div>
          ))}
        </div>
      )}

      {tab === "logs" && (
        <div className="glass rounded-2xl mt-4 overflow-hidden divide-y divide-white/5 max-h-[60vh] overflow-y-auto">
          {logs.map((l) => (
            <div key={l.id} className="flex items-center gap-4 px-5 py-2.5 hover:bg-white/5 text-sm">
              <span className="text-[10px] uppercase tracking-wider px-2 py-1 rounded-full bg-white/5 text-white/40 w-24 text-center shrink-0">{l.category}</span>
              <span className="flex-1 truncate">{l.action}</span>
              <span className="text-xs text-white/35 font-mono">{new Date(l.created_at).toLocaleString()}</span>
            </div>
          ))}
        </div>
      )}

      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent className="bg-[#0A0A0B] border-white/10">
          <AlertDialogHeader><AlertDialogTitle>Delete user?</AlertDialogTitle><AlertDialogDescription className="text-white/50">This permanently removes the user and all their servers.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-white/5 border-white/10 hover:bg-white/10">Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={doDelete} className="bg-red-500 hover:bg-red-600 text-white" data-testid="confirm-delete-user">Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
