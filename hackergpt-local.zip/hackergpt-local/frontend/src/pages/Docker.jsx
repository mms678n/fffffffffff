import { useEffect, useState, useCallback } from "react";
import { useOutletContext } from "react-router-dom";
import { toast } from "sonner";
import {
  Box, Play, Square, RotateCw, Trash2, ScrollText, Boxes,
  HardDrive, Network, Image, Loader2, RefreshCw, AlertTriangle,
} from "lucide-react";
import { api, formatApiError } from "../lib/api";
import { EmptyServer } from "../components/EmptyServer";
import { Button } from "../components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "../components/ui/dialog";

const TABS = [
  { key: "containers", label: "Containers", icon: Box },
  { key: "images", label: "Images", icon: Image },
  { key: "volumes", label: "Volumes", icon: HardDrive },
  { key: "networks", label: "Networks", icon: Network },
];

export default function Docker() {
  const { activeServer } = useOutletContext();
  const serverId = activeServer?.id;
  const [tab, setTab] = useState("containers");
  const [state, setState] = useState({ available: true, items: [], error: "" });
  const [loading, setLoading] = useState(false);
  const [busy, setBusy] = useState(null);
  const [logs, setLogs] = useState(null);

  const load = useCallback(async () => {
    if (!serverId) return;
    setLoading(true);
    try {
      const { data } = await api.get(`/servers/${serverId}/docker/${tab}`);
      setState(data);
    } catch (err) { toast.error(formatApiError(err.response?.data?.detail)); }
    finally { setLoading(false); }
  }, [serverId, tab]);

  useEffect(() => { load(); }, [load]);

  if (!activeServer) return <EmptyServer feature="Docker manager" />;

  const action = async (containerId, act) => {
    setBusy(containerId + act);
    try {
      await api.post(`/servers/${serverId}/docker/container/${act}/${containerId}`);
      toast.success(`Container ${act}`);
      load();
    } catch (err) { toast.error(formatApiError(err.response?.data?.detail)); }
    finally { setBusy(null); }
  };

  const showLogs = async (containerId) => {
    setLogs({ id: containerId, text: "Loading..." });
    try { const { data } = await api.get(`/servers/${serverId}/docker/logs/${containerId}`); setLogs({ id: containerId, text: data.logs || "(no output)" }); }
    catch (err) { setLogs({ id: containerId, text: "Failed to load logs" }); }
  };

  return (
    <div className="p-6 md:p-8 max-w-7xl mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-3xl md:text-4xl font-light tracking-tight">Docker</h1>
          <p className="text-white/45 mt-1">{activeServer.nickname} — manage containers & resources.</p>
        </div>
        <Button variant="outline" onClick={load} className="rounded-xl border-white/10 bg-white/5 hover:bg-white/10" data-testid="docker-refresh"><RefreshCw className={`w-4 h-4 mr-1 ${loading ? "animate-spin" : ""}`} /> Refresh</Button>
      </div>

      <div className="flex gap-1 mt-6 p-1 rounded-xl glass w-fit">
        {TABS.map((t) => (
          <button key={t.key} onClick={() => setTab(t.key)} data-testid={`docker-tab-${t.key}`}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm transition-colors ${tab === t.key ? "bg-white/10 text-white" : "text-white/50 hover:text-white"}`}>
            <t.icon className="w-4 h-4" /> {t.label}
          </button>
        ))}
      </div>

      <div className="glass rounded-2xl mt-4 overflow-hidden">
        {loading ? (
          <div className="p-12 text-center text-white/40"><Loader2 className="w-6 h-6 animate-spin mx-auto" /></div>
        ) : !state.available ? (
          <div className="p-12 text-center"><AlertTriangle className="w-8 h-8 text-[#FFCC00] mx-auto mb-3" /><p className="text-white/60">Docker is not available on this server.</p><p className="text-xs text-white/30 mt-1 font-mono">{state.error}</p></div>
        ) : state.items.length === 0 ? (
          <div className="p-12 text-center text-white/30"><Boxes className="w-8 h-8 mx-auto mb-3" />No {tab} found</div>
        ) : (
          <div className="divide-y divide-white/5">
            {tab === "containers" && state.items.map((c) => (
              <div key={c.id} className="flex items-center gap-4 px-5 py-3.5 hover:bg-white/5" data-testid={`container-${c.id}`}>
                <span className={`w-2 h-2 rounded-full ${c.state === "running" ? "bg-[#22C55E] pulse-dot" : "bg-white/30"}`} />
                <div className="flex-1 min-w-0"><div className="text-sm font-medium truncate">{c.name}</div><div className="text-xs text-white/40 font-mono truncate">{c.image}</div></div>
                <span className="text-xs text-white/40 font-mono hidden md:block max-w-[160px] truncate">{c.status}</span>
                <div className="flex gap-1">
                  {c.state === "running"
                    ? <IconAct busy={busy === c.id + "stop"} onClick={() => action(c.id, "stop")} icon={Square} title="Stop" testid={`stop-${c.id}`} />
                    : <IconAct busy={busy === c.id + "start"} onClick={() => action(c.id, "start")} icon={Play} title="Start" color="text-[#22C55E]" testid={`start-${c.id}`} />}
                  <IconAct busy={busy === c.id + "restart"} onClick={() => action(c.id, "restart")} icon={RotateCw} title="Restart" testid={`restart-${c.id}`} />
                  <IconAct onClick={() => showLogs(c.id)} icon={ScrollText} title="Logs" testid={`logs-${c.id}`} />
                  <IconAct busy={busy === c.id + "remove"} onClick={() => action(c.id, "remove")} icon={Trash2} title="Remove" color="hover:text-red-400" testid={`remove-${c.id}`} />
                </div>
              </div>
            ))}
            {tab === "images" && state.items.map((im, i) => (
              <div key={i} className="flex items-center gap-4 px-5 py-3.5 hover:bg-white/5 font-mono text-sm"><Image className="w-4 h-4 text-white/40" /><span className="flex-1 truncate">{im.repository}:{im.tag}</span><span className="text-white/40 text-xs">{im.size}</span><span className="text-white/30 text-xs hidden md:block">{im.id?.slice(0, 12)}</span></div>
            ))}
            {tab === "volumes" && state.items.map((v, i) => (
              <div key={i} className="flex items-center gap-4 px-5 py-3.5 hover:bg-white/5 font-mono text-sm"><HardDrive className="w-4 h-4 text-white/40" /><span className="flex-1 truncate">{v.name}</span><span className="text-white/40 text-xs">{v.driver}</span></div>
            ))}
            {tab === "networks" && state.items.map((n, i) => (
              <div key={i} className="flex items-center gap-4 px-5 py-3.5 hover:bg-white/5 font-mono text-sm"><Network className="w-4 h-4 text-white/40" /><span className="flex-1 truncate">{n.name}</span><span className="text-white/40 text-xs">{n.driver}</span><span className="text-white/30 text-xs">{n.scope}</span></div>
            ))}
          </div>
        )}
      </div>

      <Dialog open={!!logs} onOpenChange={() => setLogs(null)}>
        <DialogContent className="bg-[#0A0A0B] border-white/10 max-w-3xl">
          <DialogHeader><DialogTitle className="font-mono text-sm">Logs · {logs?.id?.slice(0, 12)}</DialogTitle></DialogHeader>
          <pre className="bg-[#050505] border border-white/10 rounded-xl p-4 text-xs font-mono max-h-[60vh] overflow-auto whitespace-pre-wrap">{logs?.text}</pre>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function IconAct({ onClick, icon: Icon, title, color = "", busy, testid }) {
  return <button onClick={onClick} disabled={busy} title={title} data-testid={testid} className={`p-2 rounded-lg hover:bg-white/10 text-white/50 hover:text-white transition-colors ${color}`}>{busy ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Icon className="w-3.5 h-3.5" />}</button>;
}
