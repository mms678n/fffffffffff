export default {
  logoUrl: "https://customer-assets.emergentagent.com/job_ai-server-control/artifacts/ymz8zzyk_logo.jpg",
};
