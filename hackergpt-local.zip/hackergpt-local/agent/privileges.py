"""Elevated-privilege detection and OS-native elevation flow.

Security rules honoured:
- Never elevate silently.
- Always use the OS's official permission mechanism (UAC / sudo).
- If elevation is denied, continue with reduced functionality.
"""
import os
import platform
import re
import sys

ELEVATION_NOTICE = (
    "HackerGPT Agent — Administrator / Root Permissions\n\n"
    "Why elevated privileges are requested:\n"
    "  Advanced administration features require system-level access.\n\n"
    "Features that need elevated privileges:\n"
    "  • Install software and update packages\n"
    "  • Manage, start, stop and restart services\n"
    "  • Modify protected system files\n"
    "  • Manage Docker\n"
    "  • Run administrative maintenance tasks\n\n"
    "What still works WITHOUT elevation:\n"
    "  • View system information\n"
    "  • Monitor CPU / RAM / Disk\n"
    "  • Read permitted logs\n"
    "  • Execute user-level commands\n"
    "  • Maintain the secure connection\n\n"
    "Guarantees:\n"
    "  • The Agent only performs actions initiated by YOU through your own\n"
    "    authenticated HackerGPT account.\n"
    "  • Every action is logged locally and remotely.\n"
    "  • You may decline and continue with limited functionality.\n"
)


def is_elevated() -> bool:
    if platform.system() == "Windows":
        try:
            import ctypes
            return bool(ctypes.windll.shell32.IsUserAnAdmin())
        except Exception:
            return False
    try:
        return os.geteuid() == 0
    except AttributeError:
        return False


def elevation_instructions() -> str:
    system = platform.system()
    if system == "Windows":
        return "Windows will show the official User Account Control (UAC) dialog."
    if system == "Darwin":
        return ("Restart the Agent with elevated rights:\n"
                "  sudo /Applications/HackerGPT\\ Agent.app/Contents/MacOS/agent\n"
                "or run:  sudo python3 agent.py")
    return ("Advanced features require root. Restart the Agent with sudo:\n"
            "  sudo python3 agent.py\n"
            "The Agent will keep running with limited functionality otherwise.")


def request_elevation() -> bool:
    """Attempt to relaunch elevated using the OS-native mechanism.

    Returns True if a relaunch was initiated (Windows), otherwise False
    (POSIX prints instructions; we never elevate silently)."""
    if is_elevated():
        return True
    system = platform.system()
    if system == "Windows":
        try:
            import ctypes
            params = " ".join(f'"{a}"' for a in sys.argv)
            rc = ctypes.windll.shell32.ShellExecuteW(
                None, "runas", sys.executable, params, None, 1)
            return rc > 32  # >32 means success
        except Exception:
            return False
    # POSIX: do not auto-elevate; surface instructions to the user.
    return False


PRIVILEGED_COMMANDS = {
    "sudo", "doas", "su", "systemctl", "service", "apt", "apt-get", "dnf", "yum",
    "zypper", "pacman", "snap", "flatpak", "docker", "mount", "umount", "chown",
    "chmod", "chgrp", "useradd", "userdel", "usermod", "groupadd", "groupdel",
    "passwd", "iptables", "nft", "ufw", "firewall-cmd", "reboot", "shutdown", "poweroff",
    "sc", "netsh", "bcdedit", "diskpart", "takeown", "icacls",
}


def requires_elevation(command: str) -> bool:
    for segment in re.split(r"&&|\|\||;|\||\n", command or ""):
        tokens = segment.strip().split()
        while tokens and (tokens[0] in {"sudo", "doas", "env", "nohup", "time"} or "=" in tokens[0]):
            tokens.pop(0)
        if tokens and tokens[0].split("/")[-1].lower() in PRIVILEGED_COMMANDS:
            return True
    return False
