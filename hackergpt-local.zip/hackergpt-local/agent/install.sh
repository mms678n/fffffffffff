#!/usr/bin/env bash
# HackerGPT Agent — installer for Linux (Ubuntu/Debian/Kali/Fedora/Arch) & macOS
set -euo pipefail

SERVER_URL="${HACKERGPT_SERVER:-https://ai-server-control.preview.emergentagent.com}"
INSTALL_DIR="${HOME}/.hackergpt-agent"
BUNDLE_URL="${SERVER_URL%/}/api/agent/bundle"

echo "=================================================="
echo "  HackerGPT Agent installer"
echo "  Server: ${SERVER_URL}"
echo "=================================================="

# --- prerequisites ---
if ! command -v python3 >/dev/null 2>&1; then
  echo "ERROR: python3 is required. Please install Python 3.9+ and re-run." >&2
  exit 1
fi

mkdir -p "${INSTALL_DIR}"
echo "[1/4] Downloading agent bundle..."
if command -v curl >/dev/null 2>&1; then
  curl -fsSL "${BUNDLE_URL}" -o "${INSTALL_DIR}/agent.tar.gz"
else
  wget -q "${BUNDLE_URL}" -O "${INSTALL_DIR}/agent.tar.gz"
fi

echo "[2/4] Extracting..."
tar -xzf "${INSTALL_DIR}/agent.tar.gz" -C "${INSTALL_DIR}" --strip-components=1
rm -f "${INSTALL_DIR}/agent.tar.gz"

echo "[3/4] Installing Python dependencies (user scope)..."
python3 -m pip install --user -q -r "${INSTALL_DIR}/requirements.txt" || \
  python3 -m pip install --user -q --break-system-packages -r "${INSTALL_DIR}/requirements.txt"

# --- optional: start on boot (Linux systemd user service) ---
if command -v systemctl >/dev/null 2>&1 && [ "$(uname -s)" = "Linux" ]; then
  SVC_DIR="${HOME}/.config/systemd/user"
  mkdir -p "${SVC_DIR}"
  cat > "${SVC_DIR}/hackergpt-agent.service" <<EOF
[Unit]
Description=HackerGPT Agent
After=network-online.target

[Service]
ExecStart=$(command -v python3) ${INSTALL_DIR}/agent.py --headless
Restart=always
RestartSec=5

[Install]
WantedBy=default.target
EOF
  echo "    systemd user service created (auto-restart + auto-reconnect after reboot)."
  echo "    Enable it with:  systemctl --user enable --now hackergpt-agent"
fi

echo "[4/4] Done."
echo "=================================================="
echo "  Launch the Agent:"
echo "    python3 ${INSTALL_DIR}/agent.py           # desktop GUI"
echo "    python3 ${INSTALL_DIR}/agent.py --headless # background service"
echo ""
echo "  NOTE: Advanced administration features require root."
echo "        To enable them, start with:  sudo python3 ${INSTALL_DIR}/agent.py"
echo "=================================================="

# launch GUI if a display is available
if [ -n "${DISPLAY:-}" ] || [ "$(uname -s)" = "Darwin" ]; then
  ( python3 "${INSTALL_DIR}/agent.py" >/dev/null 2>&1 & ) || true
fi
