"""Secure outbound WebSocket connection to the HackerGPT server.

- Connects over WSS (TLS) to /api/ws/agent.
- Authenticates with Device ID + Secret.
- Sends heartbeats every few seconds and periodic system information.
- Automatically reconnects after internet interruption or reboot
  (with exponential backoff).
"""
import json
import random
import threading
import time

try:
    import websocket  # websocket-client
except ImportError:
    websocket = None

import system_info
import privileges
from version import __version__

HEARTBEAT_INTERVAL = 5
INFO_INTERVAL = 30


def _ws_url(server_url: str) -> str:
    url = server_url.rstrip("/")
    if url.startswith("https://"):
        url = "wss://" + url[len("https://"):]
    elif url.startswith("http://"):
        url = "ws://" + url[len("http://"):]
    return url + "/api/ws/agent"


class Connection:
    def __init__(self, cfg: dict, on_status=None, on_log=None):
        self.cfg = cfg
        self.on_status = on_status or (lambda s: None)
        self.on_log = on_log or (lambda m: None)
        self._stop = threading.Event()
        self._hb_stop = threading.Event()
        self._ws = None
        self._thread = None
        self._authed = False
        self._session_ok = False
        self._send_lock = threading.Lock()
        self._shells = {}
        self._last_ack = 0.0
        self._retry_count = 0

    def _send(self, obj):
        ws = self._ws
        if not ws:
            return False
        with self._send_lock:
            try:
                ws.send(json.dumps(obj))
                return True
            except Exception as exc:
                self.on_log(f"Send failed ({obj.get('type', 'message')}): {exc}")
                return False

    # ---- lifecycle ----
    def start(self):
        if websocket is None:
            self.on_log("ERROR: websocket-client not installed. Run: pip install websocket-client")
            self.on_status("disconnected")
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._run_loop, daemon=True)
        self._thread.start()

    def stop(self):
        self._stop.set()
        self._hb_stop.set()
        if self._ws:
            try:
                self._ws.close()
            except Exception:
                pass

    def reconnect(self):
        self.on_log("Manual reconnect requested.")
        if self._ws:
            try:
                self._ws.close()
            except Exception:
                pass

    # ---- internal ----
    def _run_loop(self):
        backoff = 1
        while not self._stop.is_set():
            self._session_ok = False
            self.on_status("connecting")
            self.on_log(f"Connecting to {self.cfg['server_url']} (attempt {self._retry_count + 1}) ...")
            try:
                self._ws = websocket.WebSocketApp(
                    _ws_url(self.cfg["server_url"]),
                    on_open=self._on_open,
                    on_message=self._on_message,
                    on_error=self._on_error,
                    on_close=self._on_close,
                    on_pong=self._on_pong,
                )
                self._ws.run_forever(ping_interval=20, ping_timeout=10, skip_utf8_validation=True)
            except Exception as e:
                self.on_log(f"Connection error ({type(e).__name__}): {e}")
            self._authed = False
            self._hb_stop.set()
            if self._stop.is_set():
                break
            # A healthy session that just dropped should recover fast.
            if self._session_ok:
                backoff = 1
                self._retry_count = 0
            self.on_status("connecting")
            delay = min(backoff, 30) + random.uniform(0, min(1.5, backoff / 3))
            self._retry_count += 1
            self.on_log(f"Connection lost. Reconnecting in {delay:.1f}s (backoff attempt {self._retry_count})...")
            self._stop.wait(delay)  # interruptible sleep
            backoff = min(backoff * 2, 15)
        self.on_status("disconnected")
        self.on_log("Agent stopped.")

    def _on_open(self, ws):
        self.on_log("Socket open. Authenticating...")
        try:
            info = system_info.collect(include_public_ip=True)
        except Exception:
            info = {}
        ws.send(json.dumps({
            "type": "auth",
            "device_id": self.cfg["device_id"],
            "secret": self.cfg["device_secret"],
            "uuid": self.cfg["uuid"],
            "agent_version": __version__,
            "info": info,
            "permissions": {
                "elevated": privileges.is_elevated(),
                "platform": __import__("platform").system(),
                "can_request_elevation": True,
            },
        }))

    def _on_message(self, ws, message):
        try:
            msg = json.loads(message)
        except Exception:
            return
        mtype = msg.get("type")
        if mtype == "authok":
            self._authed = True
            self._session_ok = True
            self._last_ack = time.monotonic()
            self.on_status("online")
            self.on_log("Authenticated. Secure connection established (WSS/TLS).")
            self._start_heartbeat(ws)
        elif mtype == "error":
            self.on_log(f"Server error during session: {msg.get('message')}")
            self.on_status("disconnected")
            try:
                ws.close()
            except Exception:
                pass
        elif mtype == "command":
            self._handle_command(ws, msg)
        elif mtype == "exec":
            self._handle_exec(msg)
        elif mtype == "shell_start":
            self._shell_start(msg)
        elif mtype == "shell_input":
            self._shell_input(msg)
        elif mtype == "shell_resize":
            self._shell_resize(msg)
        elif mtype == "shell_close":
            self._shell_cleanup(msg.get("shell_id"))
        elif mtype == "ack":
            self._last_ack = time.monotonic()
        elif mtype == "pong":
            self._last_ack = time.monotonic()

    # ---- interactive terminal (PTY) ----
    def _shell_start(self, msg):
        import sys
        shell_id = msg.get("shell_id")
        if not shell_id:
            return
        cols = int(msg.get("cols") or 80)
        rows = int(msg.get("rows") or 24)
        try:
            if sys.platform == "win32":
                self._shell_start_win(shell_id)
            else:
                self._shell_start_posix(shell_id, cols, rows)
        except Exception as e:
            self._send({"type": "shell_output", "shell_id": shell_id, "data": f"[agent] failed to start shell: {e}\r\n"})
            self._send({"type": "shell_exit", "shell_id": shell_id})

    def _shell_start_posix(self, shell_id, cols, rows):
        import os
        import pty
        import struct
        import fcntl
        import termios
        import subprocess
        master, slave = pty.openpty()
        try:
            fcntl.ioctl(master, termios.TIOCSWINSZ, struct.pack("HHHH", rows, cols, 0, 0))
        except Exception:
            pass
        shell = os.environ.get("SHELL", "/bin/bash")
        env = {**os.environ, "TERM": "xterm-256color"}
        proc = subprocess.Popen([shell], stdin=slave, stdout=slave, stderr=slave,
                                preexec_fn=os.setsid, env=env, close_fds=True)
        os.close(slave)
        self._shells[shell_id] = {"master": master, "proc": proc, "stop": threading.Event(), "win": False}
        threading.Thread(target=self._shell_reader_posix, args=(shell_id,), daemon=True).start()

    def _shell_reader_posix(self, shell_id):
        import os
        import select
        sh = self._shells.get(shell_id)
        if not sh:
            return
        master = sh["master"]
        stop = sh["stop"]
        while not stop.is_set():
            try:
                r, _, _ = select.select([master], [], [], 0.2)
            except (OSError, ValueError):
                break
            if master in r:
                try:
                    data = os.read(master, 4096)
                except OSError:
                    break
                if not data:
                    break
                self._send({"type": "shell_output", "shell_id": shell_id,
                            "data": data.decode("utf-8", "replace")})
        self._send({"type": "shell_exit", "shell_id": shell_id})
        self._shell_cleanup(shell_id)

    def _shell_start_win(self, shell_id):
        import subprocess
        proc = subprocess.Popen(["cmd.exe"], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, bufsize=0)
        self._shells[shell_id] = {"master": None, "proc": proc, "stop": threading.Event(), "win": True}
        threading.Thread(target=self._shell_reader_win, args=(shell_id,), daemon=True).start()

    def _shell_reader_win(self, shell_id):
        sh = self._shells.get(shell_id)
        if not sh:
            return
        proc = sh["proc"]
        stop = sh["stop"]
        while not stop.is_set():
            data = proc.stdout.read(1)
            if not data:
                break
            self._send({"type": "shell_output", "shell_id": shell_id,
                        "data": data.decode("utf-8", "replace")})
        self._send({"type": "shell_exit", "shell_id": shell_id})
        self._shell_cleanup(shell_id)

    def _shell_input(self, msg):
        sh = self._shells.get(msg.get("shell_id"))
        if not sh:
            return
        data = msg.get("data", "")
        try:
            if sh.get("win"):
                sh["proc"].stdin.write(data.encode("utf-8", "replace"))
                sh["proc"].stdin.flush()
            else:
                import os
                os.write(sh["master"], data.encode("utf-8", "replace"))
        except Exception:
            pass

    def _shell_resize(self, msg):
        sh = self._shells.get(msg.get("shell_id"))
        if not sh or sh.get("win") or sh.get("master") is None:
            return
        import struct
        import fcntl
        import termios
        try:
            fcntl.ioctl(sh["master"], termios.TIOCSWINSZ,
                        struct.pack("HHHH", int(msg.get("rows") or 24), int(msg.get("cols") or 80), 0, 0))
        except Exception:
            pass

    def _shell_cleanup(self, shell_id):
        sh = self._shells.pop(shell_id, None)
        if not sh:
            return
        sh["stop"].set()
        try:
            if sh.get("proc"):
                sh["proc"].terminate()
        except Exception:
            pass
        try:
            if sh.get("master") is not None:
                import os
                os.close(sh["master"])
        except Exception:
            pass

    def _cleanup_all_shells(self):
        for sid in list(self._shells.keys()):
            self._shell_cleanup(sid)

    def _handle_exec(self, msg):
        exec_id = msg.get("exec_id")
        command = msg.get("command", "")
        if not exec_id or not command:
            return
        self.on_log(f"HackerGPT requested command: {command}")
        threading.Thread(target=self._run_exec, args=(exec_id, command), daemon=True).start()

    def _run_exec(self, exec_id, command):
        import subprocess
        import time as _time
        start = _time.time()
        exit_code = 0
        if privileges.requires_elevation(command) and not privileges.is_elevated():
            message = "[agent] privileged command blocked: Agent is not running with Administrator/root permissions.\n"
            self._send({"type": "exec_output", "exec_id": exec_id, "data": message})
            self._send({"type": "exec_done", "exec_id": exec_id, "exit_code": 126, "duration": 0.0})
            self.on_log("Blocked privileged command because elevated permissions are unavailable.")
            return
        try:
            proc = subprocess.Popen(
                command, shell=True,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                bufsize=1, universal_newlines=True,
            )
            for line in iter(proc.stdout.readline, ""):
                if not line:
                    break
                self._send({"type": "exec_output", "exec_id": exec_id, "data": line})
            proc.stdout.close()
            exit_code = proc.wait()
        except Exception as e:
            self._send({"type": "exec_output", "exec_id": exec_id, "data": f"[agent error] {e}\n"})
            exit_code = -1
        duration = round(_time.time() - start, 2)
        self._send({"type": "exec_done", "exec_id": exec_id, "exit_code": exit_code, "duration": duration})
        self.on_log(f"Command finished (exit {exit_code}, {duration}s)")

    def _handle_command(self, ws, msg):
        import os
        import sys
        import config as _cfg
        action = msg.get("action")
        self.on_log(f"Received command from server: {action}")
        if action == "reconnect":
            try:
                ws.close()
            except Exception:
                pass
        elif action == "refresh":
            try:
                info = system_info.collect(include_public_ip=False)
                ws.send(json.dumps({"type": "info", "data": info, "agent_version": __version__}))
            except Exception:
                pass
        elif action == "rotate_secret":
            new_secret = msg.get("secret")
            if new_secret:
                self.cfg["device_secret"] = new_secret
                _cfg.save(self.cfg)
                self.on_log("Device secret rotated and stored securely.")
        elif action == "restart":
            self.on_log("Restarting agent (reload)...")
            self._stop.set()
            self._hb_stop.set()
            try:
                ws.close()
            except Exception:
                pass
            try:
                os.execv(sys.executable, [sys.executable] + sys.argv)
            except Exception as e:
                self.on_log(f"Restart failed: {e}")

    def _on_error(self, ws, error):
        self.on_status("error")
        self.on_log(f"WebSocket error ({type(error).__name__}): {error}")

    def _on_pong(self, _ws, _message):
        self._last_ack = time.monotonic()

    def _on_close(self, ws, code, reason):
        self._authed = False
        self._hb_stop.set()
        self._cleanup_all_shells()
        self.on_status("connecting")
        self.on_log(f"Connection closed ({code}, {reason or 'no reason'}). Automatic reconnect will follow.")

    def _start_heartbeat(self, ws):
        self._hb_stop = threading.Event()

        def loop():
            last_info = 0
            while not self._hb_stop.is_set() and not self._stop.is_set():
                try:
                    now = time.monotonic()
                    if self._last_ack and now - self._last_ack > 35:
                        self.on_log("Heartbeat acknowledgement timed out; forcing a clean reconnect.")
                        try: ws.close()
                        except Exception: pass
                        break
                    self._send({"type": "heartbeat", "ts": time.time()})
                    self._send({"type": "metrics", "data": system_info.collect_metrics()})
                    wall_now = time.time()
                    if wall_now - last_info >= INFO_INTERVAL:
                        info = system_info.collect(include_public_ip=False)
                        self._send({"type": "info", "data": info, "agent_version": __version__})
                        last_info = wall_now
                except Exception as exc:
                    self.on_log(f"Heartbeat loop failed: {exc}")
                    break
                self._hb_stop.wait(HEARTBEAT_INTERVAL)

        threading.Thread(target=loop, daemon=True).start()
