# Building native HackerGPT Agent installers

The Agent ships as **native applications** so end users never need Python.
Because PyInstaller cannot cross-compile and macOS/Windows signing requires the
vendor toolchains, **each platform is built on its own OS** (locally or via the
included GitHub Actions workflow `.github/workflows/build-agent.yml`).

## Windows deliverable
The end-user file for Windows is **`HackerGPT-Agent-Setup.exe`** — a real native
installer (Inno Setup wrapping the PyInstaller `--noconsole` EXE). Users
double-click it; **no Python, no PowerShell, no command prompt** are involved.
It installs like any Windows app: Start Menu shortcut, optional Desktop/startup
shortcuts, a registered uninstaller, HackerGPT icon/branding, all deps bundled.

Since this build sandbox is Linux-only, `HackerGPT-Agent-Setup.exe` is produced by
the **GitHub Actions** workflow and published as a **GitHub Release** asset (push a
tag `agent-v1.0.0`). To make the website's "Download for Windows" button serve it,
set the backend env var
`AGENT_DOWNLOAD_WINDOWS=https://github.com/<owner>/<repo>/releases/latest/download/HackerGPT-Agent-Setup.exe`
— `/api/agent/download/windows` then 302-redirects to it (same for
`AGENT_DOWNLOAD_LINUX` / `AGENT_DOWNLOAD_MACOS`).


| Platform | Output | Tooling |
|----------|--------|---------|
| Windows  | `HackerGPTAgent.exe` (standalone) + `HackerGPTAgent-Setup-1.0.0.exe` (installer) | PyInstaller + Inno Setup |
| Linux    | portable `HackerGPTAgent` binary + `.deb` + `.rpm` | PyInstaller + dpkg-deb + fpm |
| macOS    | `HackerGPT Agent.app` inside `HackerGPTAgent-1.0.0.dmg` (signed/notarized) | PyInstaller + iconutil + create-dmg/hdiutil + codesign/notarytool |

All builds are **windowed** (no console/terminal window remains open) and bundle
every dependency (psutil, websocket-client, Tk).

## Windows (on Windows)
```powershell
# Prereqs: Python 3.9+, Inno Setup 6 (https://jrsoftware.org/isdl.php)
powershell -ExecutionPolicy Bypass -File build\build_windows.ps1
# -> dist\HackerGPTAgent.exe  and  dist\installer\HackerGPTAgent-Setup-1.0.0.exe
```
The installer creates a Start Menu shortcut, an optional Desktop shortcut, an
optional "start with Windows" entry, registers a proper uninstaller, and only
asks for Administrator rights if the user picks a machine-wide install
(`PrivilegesRequired=lowest`). The app itself requests elevation via the native
UAC dialog only when the user opts into advanced features.

## Linux (on Linux)
```bash
sudo apt-get install -y python3-tk        # for the GUI
bash build/build_linux.sh
# -> dist/HackerGPTAgent (portable), dist/hackergpt-agent_1.0.0_amd64.deb, (+ .rpm if fpm/alien present)
sudo dpkg -i dist/hackergpt-agent_1.0.0_amd64.deb   # installs /usr/bin/hackergpt-agent + .desktop entry
```

## macOS (on macOS)
```bash
# Optional signing/notarization:
export HACKERGPT_SIGN_ID="Developer ID Application: Your Name (TEAMID)"
export HACKERGPT_NOTARIZE_PROFILE="notary-profile"
bash build/build_macos.sh
# -> dist/HackerGPTAgent-1.0.0.dmg
```

## Automatic updates
The Agent's `updater.py` checks `/api/agent/info`, downloads the bundle over
TLS, verifies its SHA-256 integrity, and prompts before applying — wired to the
`Check Update` button in the GUI. For fully-managed updates, ship new installer
builds via the CI workflow and bump `version.py`.

## One command, all platforms (CI)
Trigger the **Build HackerGPT Agent** workflow (or push a tag `agent-v1.0.0`).
It builds on `windows-latest`, `ubuntu-latest` and `macos-latest` runners and
uploads the installers as artifacts. Set repo secrets `MAC_SIGN_ID` and
`MAC_NOTARY_PROFILE` to sign & notarize the macOS build.

## Note on this environment
This project's build sandbox is Linux-only, so the **Linux** artifacts are
produced and verified here. The Windows `.exe` and macOS `.dmg` must be produced
on their native OS using the scripts above (or the CI workflow) — this is an
inherent limitation of native packaging + code signing, not of the build config.
