# HackerGPT Agent - installer for Windows (64-bit)
# Run in PowerShell.  It will request Administrator rights via the official UAC dialog.

param(
  [string]$Server = $(if ($env:HACKERGPT_SERVER) { $env:HACKERGPT_SERVER } else { "https://ai-server-control.preview.emergentagent.com" })
)

$ErrorActionPreference = "Stop"
$InstallDir = Join-Path $env:LOCALAPPDATA "HackerGPTAgent\app"
$BundleUrl  = "$($Server.TrimEnd('/'))/api/agent/bundle"

Write-Host "=================================================="
Write-Host "  HackerGPT Agent installer (Windows)"
Write-Host "  Server: $Server"
Write-Host "=================================================="

# --- request elevation (official UAC) ---
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
  Write-Host "Requesting Administrator privileges (UAC)..."
  Start-Process powershell -Verb RunAs -ArgumentList "-ExecutionPolicy Bypass -File `"$PSCommandPath`" -Server `"$Server`""
  exit
}

if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
  Write-Error "Python 3.9+ is required. Install it from python.org and re-run."
  exit 1
}

New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
Write-Host "[1/4] Downloading agent bundle..."
Invoke-WebRequest -Uri $BundleUrl -OutFile "$InstallDir\agent.tar.gz"

Write-Host "[2/4] Extracting..."
tar -xzf "$InstallDir\agent.tar.gz" -C $InstallDir --strip-components=1
Remove-Item "$InstallDir\agent.tar.gz"

Write-Host "[3/4] Installing Python dependencies..."
python -m pip install -q -r "$InstallDir\requirements.txt"

Write-Host "[4/4] Configuring startup..."
# Optional: start with Windows (Startup folder shortcut)
$startup = [Environment]::GetFolderPath("Startup")
$shortcut = Join-Path $startup "HackerGPT Agent.lnk"
$ws = New-Object -ComObject WScript.Shell
$sc = $ws.CreateShortcut($shortcut)
$sc.TargetPath = (Get-Command pythonw).Source
$sc.Arguments  = "`"$InstallDir\agent.py`" --headless"
$sc.WorkingDirectory = $InstallDir
$sc.Save()

Write-Host "=================================================="
Write-Host "  Installed. Launching HackerGPT Agent..."
Write-Host "=================================================="
Start-Process (Get-Command pythonw).Source -ArgumentList "`"$InstallDir\agent.py`""
