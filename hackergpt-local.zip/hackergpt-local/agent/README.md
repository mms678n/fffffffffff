# HackerGPT Agent

The official cross-platform companion application for the **HackerGPT** platform.
It securely connects a machine you own to your HackerGPT account so the platform
can display its live status and system information.

> The Agent only connects when **you** install it and register it with your own
> account. It never connects to a device without explicit installation and
> authorization by the device owner.

## Supported operating systems
- Windows (64-bit)
- Linux (Ubuntu, Debian, Kali, Fedora, Arch)
- macOS (Intel & Apple Silicon)

## How it works
1. On first launch the Agent generates, using a CSPRNG:
   - a permanent **Device UUID** (`uuid4`)
   - a **Device ID** (format `HG-XXXXXXXX-XXXX`)
   - a **Device Secret** (≥ 64 URL-safe characters)
   These are stored locally with restricted permissions (`0600` on POSIX).
2. You open the HackerGPT website → **Devices → Add Device**, pick your OS,
   download the installer, then paste the **Device ID** and **Device Secret**.
3. The device is linked permanently to your account. A device can never appear
   in another account unless it is removed first.
4. The Agent then keeps a secure **outbound WSS/TLS** connection to the server,
   sending a heartbeat every few seconds and periodic system information.
   It reconnects automatically after reboots and network interruptions.

## Install
### Linux / macOS
```bash
curl -fsSL "$SERVER/api/agent/download/linux" -o install-hackergpt-agent.sh
bash install-hackergpt-agent.sh
```
(use `/api/agent/download/macos` on macOS)

### Windows (PowerShell)
```powershell
iwr "$Server/api/agent/download/windows" -OutFile install-hackergpt-agent.ps1
powershell -ExecutionPolicy Bypass -File .\install-hackergpt-agent.ps1
```

## Run
```bash
python3 agent.py            # desktop GUI (dark theme)
python3 agent.py --headless # background service (no GUI)
python3 agent.py --info     # print device credentials and exit
```

## Elevated privileges
Advanced administration (installing software, managing services, editing
protected files, Docker, maintenance) requires elevated privileges. The Agent:
- **never** elevates silently and always uses the OS's official mechanism;
- on **Windows** requests Administrator rights via the UAC dialog;
- on **Linux/macOS** detects whether it runs as root and, if not, explains how
  to restart with `sudo`;
- if elevation is declined, continues safely with **reduced functionality**
  (system info, monitoring, permitted logs, user-level commands, secure link).

## Security
- TLS-encrypted (WSS) outbound-only communication.
- Secrets stored locally with restricted file permissions; secret rotation
  supported (regenerate in Settings, then re-register).
- The Agent only performs actions initiated by the authenticated user through
  their own HackerGPT account. Every action is logged locally and remotely.

## Architecture
| File | Responsibility |
|------|----------------|
| `agent.py` | Entry point; GUI/headless selection, signals |
| `config.py` | Credential generation & secure local storage |
| `system_info.py` | System information via `psutil` |
| `connection.py` | WSS client: auth, heartbeat, info, auto-reconnect |
| `privileges.py` | Elevation detection & OS-native elevation flow |
| `gui.py` | Dark-themed Tkinter desktop window |
| `updater.py` | Update check + integrity (SHA-256) verification |

## Auto update
`Check Update` compares the local version against `/api/agent/info`, downloads
the bundle over TLS, verifies its SHA-256 integrity, and prompts before applying.
