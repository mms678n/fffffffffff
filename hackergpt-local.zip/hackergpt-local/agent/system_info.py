"""Collect system information for the HackerGPT Agent."""
import getpass
import platform
import socket
import time
import urllib.request

try:
    import psutil
except ImportError:
    psutil = None

from version import __version__


def _bytes_to_gb(n: int) -> float:
    return round(n / (1024 ** 3), 1)


def _internal_ip() -> str:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(1)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        try:
            return socket.gethostbyname(socket.gethostname())
        except Exception:
            return "n/a"


def _public_ip() -> str:
    for url in ("https://api.ipify.org", "https://ifconfig.me/ip"):
        try:
            with urllib.request.urlopen(url, timeout=3) as r:
                return r.read().decode().strip()
        except Exception:
            continue
    return "n/a"


def _uptime() -> str:
    if not psutil:
        return "n/a"
    try:
        secs = int(time.time() - psutil.boot_time())
        days, rem = divmod(secs, 86400)
        hours, rem = divmod(rem, 3600)
        mins = rem // 60
        parts = []
        if days:
            parts.append(f"{days}d")
        if hours:
            parts.append(f"{hours}h")
        parts.append(f"{mins}m")
        return " ".join(parts)
    except Exception:
        return "n/a"


def _temperature():
    if not psutil or not hasattr(psutil, "sensors_temperatures"):
        return None
    try:
        temps = psutil.sensors_temperatures()
        for _name, entries in (temps or {}).items():
            for e in entries:
                if e.current:
                    return round(e.current, 1)
    except Exception:
        pass
    return None


_software_cache = None


def installed_software(limit: int = 400):
    global _software_cache
    if _software_cache is not None:
        return _software_cache
    import subprocess
    system = platform.system()
    items = []
    try:
        if system == "Linux":
            try:
                out = subprocess.run(["dpkg-query", "-W", "-f=${Package} ${Version}\n"],
                                     capture_output=True, text=True, timeout=8)
                if out.returncode == 0:
                    items = [l.strip() for l in out.stdout.splitlines() if l.strip()]
            except Exception:
                pass
            if not items:
                try:
                    out = subprocess.run(["rpm", "-qa"], capture_output=True, text=True, timeout=8)
                    if out.returncode == 0:
                        items = [l.strip() for l in out.stdout.splitlines() if l.strip()]
                except Exception:
                    pass
        elif system == "Darwin":
            try:
                out = subprocess.run(["brew", "list", "--versions"], capture_output=True, text=True, timeout=8)
                if out.returncode == 0:
                    items = [l.strip() for l in out.stdout.splitlines() if l.strip()]
            except Exception:
                pass
            try:
                import os as _os
                items += [a[:-4] for a in _os.listdir("/Applications") if a.endswith(".app")]
            except Exception:
                pass
        elif system == "Windows":
            try:
                ps = (r"Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*,"
                      r"HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\* "
                      r"| Select-Object -ExpandProperty DisplayName")
                out = subprocess.run(["powershell", "-NoProfile", "-Command", ps],
                                     capture_output=True, text=True, timeout=15)
                if out.returncode == 0:
                    items = [l.strip() for l in out.stdout.splitlines() if l.strip()]
            except Exception:
                pass
    except Exception:
        pass
    _software_cache = sorted(set(items))[:limit]
    return _software_cache


def collect_metrics() -> dict:
    """Lightweight live metrics for frequent streaming."""
    if not psutil:
        return {}
    system = platform.system()
    vm = psutil.virtual_memory()
    try:
        disk = psutil.disk_usage("C:\\" if system == "Windows" else "/")
    except Exception:
        disk = None
    net = psutil.net_io_counters()
    procs = []
    try:
        for p in psutil.process_iter(["pid", "name", "cpu_percent", "memory_percent"]):
            procs.append(p.info)
        procs = sorted(procs, key=lambda x: (x.get("cpu_percent") or 0), reverse=True)[:8]
        procs = [{"pid": p["pid"], "name": p.get("name") or "?",
                  "cpu": round(p.get("cpu_percent") or 0, 1),
                  "mem": round(p.get("memory_percent") or 0, 1)} for p in procs]
    except Exception:
        procs = []
    return {
        "cpu": psutil.cpu_percent(interval=0.2),
        "ram": {"total": _bytes_to_gb(vm.total), "used": _bytes_to_gb(vm.used), "pct": vm.percent},
        "disk": {"total": _bytes_to_gb(disk.total) if disk else 0,
                 "used": _bytes_to_gb(disk.used) if disk else 0,
                 "pct": disk.percent if disk else 0},
        "net": {"rx": net.bytes_recv, "tx": net.bytes_sent},
        "temp": _temperature(),
        "uptime": _uptime(),
        "processes": procs,
    }


def collect(include_public_ip: bool = True) -> dict:
    system = platform.system()
    cpu_model = platform.processor() or "Unknown CPU"
    cpu_cores = psutil.cpu_count(logical=True) if psutil else "n/a"
    ram_total = _bytes_to_gb(psutil.virtual_memory().total) if psutil else "n/a"
    ram_used_pct = psutil.virtual_memory().percent if psutil else "n/a"
    try:
        disk = psutil.disk_usage("C:\\" if system == "Windows" else "/") if psutil else None
    except Exception:
        disk = None
    disk_total = _bytes_to_gb(disk.total) if disk else "n/a"
    disk_used = _bytes_to_gb(disk.used) if disk else "n/a"
    disk_pct = disk.percent if disk else "n/a"

    return {
        "hostname": platform.node(),
        "os": system,
        "os_version": platform.release(),
        "os_full": platform.platform(),
        "arch": platform.machine(),
        "cpu": cpu_model,
        "cpu_cores": cpu_cores,
        "cpu_usage": psutil.cpu_percent(interval=0.3) if psutil else "n/a",
        "ram_total_gb": ram_total,
        "ram_used_pct": ram_used_pct,
        "disk_total_gb": disk_total,
        "disk_used_gb": disk_used,
        "disk_used_pct": disk_pct,
        "internal_ip": _internal_ip(),
        "public_ip": _public_ip() if include_public_ip else "n/a",
        "current_user": getpass.getuser(),
        "uptime": _uptime(),
        "software": installed_software(),
        "agent_version": __version__,
    }
