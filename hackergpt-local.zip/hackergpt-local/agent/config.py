"""Configuration and secure local storage for the HackerGPT Agent.

Generates a permanent Device UUID, a Device ID and a cryptographically
secure Device Secret on first launch, and persists them to a
platform-appropriate application data directory.
"""
import json
import os
import platform
import secrets
import uuid
from pathlib import Path

APP_DIR_NAME = "HackerGPTAgent"
DEFAULT_SERVER = os.environ.get(
    "HACKERGPT_SERVER",
    "https://ai-server-control.preview.emergentagent.com",
)


def config_dir() -> Path:
    system = platform.system()
    if system == "Windows":
        base = Path(os.environ.get("APPDATA", Path.home() / "AppData/Roaming"))
        d = base / APP_DIR_NAME
    elif system == "Darwin":
        d = Path.home() / "Library" / "Application Support" / APP_DIR_NAME
    else:
        base = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config"))
        d = base / "hackergpt-agent"
    d.mkdir(parents=True, exist_ok=True)
    return d


def config_path() -> Path:
    return config_dir() / "config.json"


def log_path() -> Path:
    return config_dir() / "agent.log"


def _generate_device_id() -> str:
    """HG-XXXXXXXX-XXXX using a CSPRNG."""
    part1 = secrets.token_hex(4).upper()  # 8 hex chars
    part2 = secrets.token_hex(2).upper()  # 4 hex chars
    return f"HG-{part1}-{part2}"


def _generate_secret() -> str:
    """At least 64 URL-safe characters from a CSPRNG."""
    return secrets.token_urlsafe(64)  # ~86 chars


def load_or_create() -> dict:
    path = config_path()
    if path.exists():
        try:
            cfg = json.loads(path.read_text())
        except Exception:
            cfg = {}
    else:
        cfg = {}

    changed = False
    if not cfg.get("uuid"):
        cfg["uuid"] = str(uuid.uuid4())
        changed = True
    if not cfg.get("device_id"):
        cfg["device_id"] = _generate_device_id()
        changed = True
    if not cfg.get("device_secret"):
        cfg["device_secret"] = _generate_secret()
        changed = True
    cfg.setdefault("server_url", DEFAULT_SERVER)
    cfg.setdefault("start_on_boot", False)
    cfg.setdefault("name", platform.node())

    if changed:
        save(cfg)
    return cfg


def save(cfg: dict) -> None:
    path = config_path()
    path.write_text(json.dumps(cfg, indent=2))
    try:
        os.chmod(path, 0o600)  # restrict permissions (best-effort, POSIX)
    except Exception:
        pass


def regenerate_credentials(cfg: dict) -> dict:
    """Rotate the Device ID + Secret (requires re-linking on the website)."""
    cfg["device_id"] = _generate_device_id()
    cfg["device_secret"] = _generate_secret()
    save(cfg)
    return cfg
