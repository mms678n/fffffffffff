"""Auto-update checks for the HackerGPT Agent.

Checks the server for the latest version, verifies integrity of the
downloaded bundle (SHA-256), and prompts before installing. Actual
in-place binary replacement depends on the platform installer.
"""
import hashlib
import json
import urllib.request

from version import __version__


def check_for_update(server_url: str) -> dict:
    url = server_url.rstrip("/") + "/api/agent/info"
    try:
        with urllib.request.urlopen(url, timeout=6) as r:
            data = json.loads(r.read().decode())
        latest = data.get("version", __version__)
        return {
            "current": __version__,
            "latest": latest,
            "update_available": latest != __version__,
        }
    except Exception as e:
        return {"current": __version__, "latest": __version__,
                "update_available": False, "error": str(e)}


def download_and_verify(server_url: str, expected_sha256: str | None = None) -> tuple[bool, str]:
    """Securely download the agent bundle and verify its integrity."""
    url = server_url.rstrip("/") + "/api/agent/bundle"
    try:
        with urllib.request.urlopen(url, timeout=30) as r:
            data = r.read()
        digest = hashlib.sha256(data).hexdigest()
        if expected_sha256 and digest != expected_sha256:
            return False, "Integrity check FAILED — checksum mismatch. Update aborted."
        return True, digest
    except Exception as e:
        return False, f"Download failed: {e}"
