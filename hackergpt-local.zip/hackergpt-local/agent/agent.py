#!/usr/bin/env python3
"""HackerGPT Agent — official companion for the HackerGPT platform.

Runs on the user's own machine, generates a permanent Device UUID plus a
Device ID and cryptographically secure Device Secret, and (once the user
links it on the website) maintains a secure outbound WSS/TLS connection
that reports live system information and heartbeats.

Usage:
    python3 agent.py            # launch desktop GUI (falls back to headless)
    python3 agent.py --headless # run as a background service (no GUI)
    python3 agent.py --info     # print device credentials and exit
"""
import argparse
import os
import signal
import sys
import time

import config as cfg_module
import privileges
from version import __version__


def print_credentials(cfg):
    print("=" * 60)
    print(f"  HackerGPT Agent v{__version__}")
    print("=" * 60)
    print(f"  Device UUID : {cfg['uuid']}")
    print(f"  Device ID   : {cfg['device_id']}")
    print(f"  Device Secret:")
    print(f"    {cfg['device_secret']}")
    print("-" * 60)
    print("  Register these on the HackerGPT website:")
    print("    Devices -> Add Device -> enter Device ID + Device Secret")
    print("=" * 60)


def run_headless(cfg):
    from connection import Connection

    print_credentials(cfg)
    elevated = privileges.is_elevated()
    print(f"[agent] Running {'WITH' if elevated else 'WITHOUT'} elevated privileges.")
    if not elevated:
        print("[agent] " + privileges.elevation_instructions().replace("\n", "\n[agent] "))
        print("[agent] Continuing with LIMITED functionality (this is safe).")

    def on_status(s):
        print(f"[agent] status: {s}")

    def on_log(m):
        print(f"[agent] {m}")

    conn = Connection(cfg, on_status=on_status, on_log=on_log)

    stopping = {"v": False}

    def handle_sig(*_):
        stopping["v"] = True
        print("\n[agent] Stopping...")
        conn.stop()

    signal.signal(signal.SIGINT, handle_sig)
    signal.signal(signal.SIGTERM, handle_sig)

    conn.start()
    while not stopping["v"]:
        time.sleep(1)


def main():
    parser = argparse.ArgumentParser(description="HackerGPT Agent")
    parser.add_argument("--headless", action="store_true", help="Run without GUI")
    parser.add_argument("--info", action="store_true", help="Print credentials and exit")
    args = parser.parse_args()

    cfg = cfg_module.load_or_create()

    if args.info:
        print_credentials(cfg)
        return

    has_display = bool(os.environ.get("DISPLAY")) or sys.platform in ("win32", "darwin")
    if args.headless or not has_display:
        run_headless(cfg)
        return

    try:
        import gui
        gui.launch(cfg)
    except Exception as e:
        print(f"[agent] GUI unavailable ({e}); falling back to headless mode.")
        run_headless(cfg)


if __name__ == "__main__":
    main()
