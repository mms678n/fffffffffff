# -*- mode: python ; coding: utf-8 -*-
# PyInstaller spec for the HackerGPT Agent.
# Build:  pyinstaller hackergpt-agent.spec  (run on the TARGET OS)
import sys
from pathlib import Path
from PyInstaller.utils.hooks import collect_submodules

APP_NAME = "HackerGPT-Agent"

icon = None
if sys.platform.startswith("win"):
    icon = "assets/logo.ico"
elif sys.platform == "darwin":
    icon = "assets/logo.icns" if Path("assets/logo.icns").exists() else None

hiddenimports = (
    collect_submodules("psutil")
    + ["websocket", "tkinter", "tkinter.scrolledtext", "tkinter.messagebox"]
)

datas = [("assets/logo.png", "assets")] if Path("assets/logo.png").exists() else []

block_cipher = None

a = Analysis(
    ["agent.py"],
    pathex=["."],
    binaries=[],
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    runtime_hooks=[],
    excludes=[],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)
pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name=APP_NAME,
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,          # no console window on Windows
    disable_windowed_traceback=False,
    argv_emulation=True,    # macOS: proper argv handling
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=icon,
)

# macOS: wrap the binary into a proper .app bundle
if sys.platform == "darwin":
    app = BUNDLE(
        exe,
        name="HackerGPT Agent.app",
        icon=icon,
        bundle_identifier="com.hackergpt.agent",
        version="1.0.0",
        info_plist={
            "CFBundleName": "HackerGPT Agent",
            "CFBundleDisplayName": "HackerGPT Agent",
            "CFBundleShortVersionString": "1.0.0",
            "CFBundleVersion": "1.0.0",
            "NSHighResolutionCapable": True,
            "LSUIElement": False,
        },
    )
