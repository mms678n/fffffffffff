"""Minimal dark-themed desktop GUI for the HackerGPT Agent (Tkinter)."""
import tkinter as tk
from tkinter import messagebox, scrolledtext
from datetime import datetime

import config as cfg_module
import privileges
import updater
from connection import Connection
from version import __version__

BG = "#0B0B0D"
CARD = "#16181D"
BORDER = "#2A2D34"
CRIMSON = "#8B0000"
CRIMSON2 = "#B22222"
GOLD = "#D4AF37"
TEXT = "#FFFFFF"
MUTED = "#B8BCC7"
GREEN = "#22C55E"
RED = "#EF4444"
AMBER = "#F59E0B"

STATUS_COLORS = {
    "online": GREEN, "offline": MUTED, "connecting": AMBER,
    "disconnected": RED, "updating": GOLD,
}


class AgentGUI:
    def __init__(self, cfg):
        self.cfg = cfg
        self.conn = Connection(cfg, on_status=self._set_status, on_log=self._log)
        self.secret_visible = False

        self.root = tk.Tk()
        self.root.title("HackerGPT Agent")
        self.root.configure(bg=BG)
        self.root.geometry("620x680")
        self.root.minsize(560, 620)

        self._build()
        self.root.after(400, self._first_launch_flow)
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

    # ---------- UI ----------
    def _card(self, parent, **kw):
        return tk.Frame(parent, bg=CARD, highlightbackground=BORDER,
                        highlightthickness=1, **kw)

    def _build(self):
        header = tk.Frame(self.root, bg=BG)
        header.pack(fill="x", padx=24, pady=(22, 10))
        tk.Label(header, text="HackerGPT", bg=BG, fg=TEXT,
                 font=("Helvetica", 20, "bold")).pack(side="left")
        tk.Label(header, text=" Agent", bg=BG, fg=GOLD,
                 font=("Helvetica", 20)).pack(side="left")

        self.status_pill = tk.Label(header, text="● Disconnected", bg=BG, fg=RED,
                                     font=("Helvetica", 12, "bold"))
        self.status_pill.pack(side="right")

        # Device card
        card = self._card(self.root)
        card.pack(fill="x", padx=24, pady=8)
        tk.Label(card, text="DEVICE", bg=CARD, fg=MUTED,
                 font=("Helvetica", 9, "bold")).pack(anchor="w", padx=16, pady=(14, 2))
        self.name_lbl = tk.Label(card, text=self.cfg.get("name", "Unnamed"),
                                 bg=CARD, fg=TEXT, font=("Helvetica", 14, "bold"))
        self.name_lbl.pack(anchor="w", padx=16)

        self._value_row(card, "Device ID", self.cfg["device_id"], self._copy_id)
        self.secret_row_val = tk.StringVar(value=self._masked_secret())
        self._value_row(card, "Device Secret", None, self._copy_secret,
                        textvar=self.secret_row_val, reveal=True)
        tk.Frame(card, bg=CARD, height=12).pack()

        # Register banner
        self.banner = self._card(self.root)
        tk.Label(self.banner, text="① Register this device in HackerGPT",
                 bg=CARD, fg=GOLD, font=("Helvetica", 11, "bold")).pack(anchor="w", padx=16, pady=(12, 2))
        tk.Label(self.banner,
                 text=("Open the HackerGPT website → Devices → Add Device, and enter the\n"
                       "Device ID and Device Secret above to link this machine to your account."),
                 bg=CARD, fg=MUTED, justify="left", font=("Helvetica", 9)).pack(anchor="w", padx=16, pady=(0, 12))
        self.banner.pack(fill="x", padx=24, pady=8)

        # Buttons
        btns = tk.Frame(self.root, bg=BG)
        btns.pack(fill="x", padx=24, pady=6)
        self._btn(btns, "Reconnect", self._reconnect, primary=True).pack(side="left")
        self._btn(btns, "Check Update", self._check_update).pack(side="left", padx=6)
        self._btn(btns, "Settings", self._settings).pack(side="left")
        self._btn(btns, "About", self._about).pack(side="left", padx=6)

        # Logs
        tk.Label(self.root, text="LOGS", bg=BG, fg=MUTED,
                 font=("Helvetica", 9, "bold")).pack(anchor="w", padx=24, pady=(10, 2))
        self.logs = scrolledtext.ScrolledText(
            self.root, bg="#050505", fg="#D8DCE5", insertbackground=GOLD,
            font=("Courier", 9), height=12, relief="flat",
            highlightbackground=BORDER, highlightthickness=1)
        self.logs.pack(fill="both", expand=True, padx=24, pady=(0, 20))
        self.logs.configure(state="disabled")

    def _value_row(self, parent, label, value, copy_cmd, textvar=None, reveal=False):
        row = tk.Frame(parent, bg=CARD)
        row.pack(fill="x", padx=16, pady=6)
        tk.Label(row, text=label, bg=CARD, fg=MUTED, width=13, anchor="w",
                 font=("Helvetica", 9)).pack(side="left")
        if textvar is not None:
            val = tk.Label(row, textvariable=textvar, bg=CARD, fg=GOLD,
                           font=("Courier", 10), anchor="w")
        else:
            val = tk.Label(row, text=value, bg=CARD, fg=GOLD,
                           font=("Courier", 11, "bold"), anchor="w")
        val.pack(side="left", fill="x", expand=True)
        tk.Button(row, text="Copy", command=copy_cmd, bg=BORDER, fg=TEXT,
                  relief="flat", font=("Helvetica", 8), padx=8,
                  activebackground=CRIMSON, cursor="hand2").pack(side="right")
        if reveal:
            tk.Button(row, text="Show", command=self._toggle_secret, bg=BORDER, fg=TEXT,
                      relief="flat", font=("Helvetica", 8), padx=8,
                      activebackground=CRIMSON, cursor="hand2").pack(side="right", padx=4)

    def _btn(self, parent, text, cmd, primary=False):
        return tk.Button(parent, text=text, command=cmd,
                         bg=CRIMSON if primary else CARD, fg=TEXT,
                         activebackground=CRIMSON2, activeforeground=TEXT,
                         relief="flat", font=("Helvetica", 10), padx=14, pady=7,
                         cursor="hand2", highlightbackground=BORDER, highlightthickness=1)

    # ---------- helpers ----------
    def _masked_secret(self):
        s = self.cfg["device_secret"]
        return s if self.secret_visible else "•" * 32

    def _toggle_secret(self):
        self.secret_visible = not self.secret_visible
        self.secret_row_val.set(self._masked_secret())

    def _copy(self, text, what):
        self.root.clipboard_clear()
        self.root.clipboard_append(text)
        self._log(f"{what} copied to clipboard.")

    def _copy_id(self):
        self._copy(self.cfg["device_id"], "Device ID")

    def _copy_secret(self):
        self._copy(self.cfg["device_secret"], "Device Secret")

    def _set_status(self, status):
        color = STATUS_COLORS.get(status, MUTED)
        self.root.after(0, lambda: self.status_pill.config(
            text=f"● {status.capitalize()}", fg=color))
        if status == "online":
            self.root.after(0, self.banner.pack_forget)

    def _log(self, msg):
        stamp = datetime.now().strftime("%H:%M:%S")
        line = f"[{stamp}] {msg}\n"

        def append():
            self.logs.configure(state="normal")
            self.logs.insert("end", line)
            self.logs.see("end")
            self.logs.configure(state="disabled")
        try:
            self.root.after(0, append)
        except Exception:
            pass

    # ---------- actions ----------
    def _first_launch_flow(self):
        elevated = privileges.is_elevated()
        self._log(f"HackerGPT Agent v{__version__} starting.")
        self._log(f"Running {'WITH' if elevated else 'WITHOUT'} elevated privileges.")
        if not elevated:
            self._elevation_dialog()
        self._log("Establishing secure connection...")
        self.conn.start()

    def _elevation_dialog(self):
        win = tk.Toplevel(self.root, bg=BG)
        win.title("Administrator / Root Permissions")
        win.geometry("560x520")
        win.transient(self.root)
        tk.Label(win, text="Elevated Permissions", bg=BG, fg=GOLD,
                 font=("Helvetica", 15, "bold")).pack(anchor="w", padx=20, pady=(18, 6))
        box = scrolledtext.ScrolledText(win, bg=CARD, fg=MUTED, font=("Helvetica", 9),
                                        relief="flat", height=18, wrap="word",
                                        highlightbackground=BORDER, highlightthickness=1)
        box.pack(fill="both", expand=True, padx=20, pady=8)
        box.insert("1.0", privileges.ELEVATION_NOTICE + "\n" + privileges.elevation_instructions())
        box.configure(state="disabled")
        bar = tk.Frame(win, bg=BG)
        bar.pack(fill="x", padx=20, pady=14)

        def cont():
            win.destroy()
            self._log("User accepted elevation prompt.")
            if privileges.request_elevation():
                self._log("Requested OS elevation (UAC). Relaunching elevated...")
            else:
                self._log("Elevation not applied. Continuing with LIMITED functionality.")

        def cancel():
            win.destroy()
            self._log("User declined elevation. Continuing with LIMITED functionality.")

        self._btn(bar, "Continue", cont, primary=True).pack(side="right")
        self._btn(bar, "Cancel", cancel).pack(side="right", padx=8)

    def _reconnect(self):
        self.conn.reconnect()

    def _check_update(self):
        self._log("Checking for updates...")
        res = updater.check_for_update(self.cfg["server_url"])
        if res.get("update_available"):
            if messagebox.askyesno("Update available",
                                    f"A new version ({res['latest']}) is available.\n"
                                    f"You have {res['current']}.\n\nDownload and verify now?"):
                self._set_status("updating")
                ok, info = updater.download_and_verify(self.cfg["server_url"])
                self._log(f"Update {'verified' if ok else 'failed'}: {info}")
                messagebox.showinfo("Update", "Verified. Restart the installer to apply." if ok else info)
                self._set_status("online")
        else:
            self._log(f"Up to date (v{res['current']}).")
            messagebox.showinfo("Up to date", f"HackerGPT Agent v{res['current']} is current.")

    def _settings(self):
        win = tk.Toplevel(self.root, bg=BG)
        win.title("Settings")
        win.geometry("480x300")
        win.transient(self.root)
        tk.Label(win, text="Settings", bg=BG, fg=GOLD, font=("Helvetica", 14, "bold")).pack(anchor="w", padx=20, pady=14)

        tk.Label(win, text="Server URL", bg=BG, fg=MUTED, font=("Helvetica", 9)).pack(anchor="w", padx=20)
        url_var = tk.StringVar(value=self.cfg["server_url"])
        tk.Entry(win, textvariable=url_var, bg=CARD, fg=TEXT, insertbackground=GOLD,
                 relief="flat").pack(fill="x", padx=20, pady=(2, 12))

        boot_var = tk.BooleanVar(value=self.cfg.get("start_on_boot", False))
        tk.Checkbutton(win, text="Start with the operating system", variable=boot_var,
                       bg=BG, fg=TEXT, selectcolor=CARD, activebackground=BG,
                       font=("Helvetica", 10)).pack(anchor="w", padx=18)

        def save():
            self.cfg["server_url"] = url_var.get().strip()
            self.cfg["start_on_boot"] = boot_var.get()
            cfg_module.save(self.cfg)
            self._log("Settings saved. Reconnecting with new settings...")
            self.conn.reconnect()
            win.destroy()

        def regen():
            if messagebox.askyesno("Regenerate credentials",
                                   "This creates a NEW Device ID + Secret and UNLINKS this device.\n"
                                   "You will need to re-register it. Continue?"):
                cfg_module.regenerate_credentials(self.cfg)
                self.name_lbl.config(text=self.cfg.get("name"))
                self.secret_row_val.set(self._masked_secret())
                messagebox.showinfo("Done", f"New Device ID:\n{self.cfg['device_id']}\n\nRe-register on the website.")
                win.destroy()

        bar = tk.Frame(win, bg=BG)
        bar.pack(fill="x", padx=20, pady=16)
        self._btn(bar, "Save", save, primary=True).pack(side="right")
        self._btn(bar, "Regenerate Credentials", regen).pack(side="left")

    def _about(self):
        messagebox.showinfo(
            "About HackerGPT Agent",
            f"HackerGPT Agent v{__version__}\n\n"
            "The official companion for the HackerGPT platform.\n"
            "Secure, outbound-only WSS/TLS connection.\n"
            "The Agent only performs actions you initiate through your own\n"
            "authenticated HackerGPT account. Every action is logged.\n\n"
            f"Device UUID: {self.cfg['uuid']}")

    def _on_close(self):
        self._log("Shutting down agent...")
        self.conn.stop()
        self.root.after(300, self.root.destroy)

    def run(self):
        self.root.mainloop()


def launch(cfg):
    AgentGUI(cfg).run()
